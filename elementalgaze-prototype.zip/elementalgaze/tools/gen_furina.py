"""푸리나(물의 집정관)용 스프라이트 생성기 (임시 아트). 같은 이름 PNG로 덮어쓰면 교체됩니다.
  water_ring / water_ring_b : 유리처럼 투명하고 물결치는 액체 고리 (파랑 -> 청록 테두리, 보랏빛 번짐, 하이라이트)
  hydro_ring                : water_ring 과 같은 계열 (기존 물 원소 공용 고리를 교체)
  star_whale                : 별빛이 흩뿌려진 푸른 고래 (오른쪽을 보고 있음), 금빛 장식 곡선
"""
import math, os, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = sys.argv[1] if len(sys.argv) > 1 else '.'
TEX = f'{ROOT}/src/main/resources/assets/elementalgaze/textures/particle'
os.makedirs(TEX, exist_ok=True)


def smooth(e0, e1, x):
    t = np.clip((x - e0) / (e1 - e0), 0, 1)
    return t * t * (3 - 2 * t)


def water_ring(n, seed):
    rng = np.random.default_rng(seed)
    p = rng.uniform(0, 6.28, 8)
    yy, xx = np.mgrid[0:n, 0:n]
    x = (xx + 0.5) / n * 2 - 1
    y = (yy + 0.5) / n * 2 - 1
    r = np.sqrt(x * x + y * y)
    th = np.arctan2(y, x)
    R = 0.70 + 0.05 * np.sin(2 * th + p[0]) + 0.035 * np.sin(5 * th + p[1])
    T = 0.115 + 0.05 * np.sin(3 * th + p[2]) + 0.022 * np.sin(7 * th + p[3])
    s = (r - R) / T                        # -1..1 단면 좌표
    d = np.abs(s)
    mask = 1 - smooth(0.80, 1.0, d)
    h = np.sqrt(np.clip(1 - d * d, 0, 1))  # 관 단면 높이
    # 색: 중심은 짙은 파랑, 가장자리는 밝은 청록(프레넬)
    deep = np.array([0.10, 0.38, 1.0])
    cyan = np.array([0.30, 0.90, 1.0])
    violet = np.array([0.62, 0.42, 1.0])
    fres = (d ** 2.2)[..., None]
    col = deep + (cyan - deep) * fres
    vmix = (0.5 + 0.5 * np.sin(th * 1.0 + p[4]))[..., None] * (d ** 1.2)[..., None] * 0.65
    col = col * (1 - vmix) + violet * vmix
    # 하이라이트: 관 위쪽(s≈-0.45)에 길게 번지는 빛 + 군데군데 밝은 점
    spec = np.exp(-((s + 0.42) / 0.13) ** 2) * (0.35 + 0.65 * smooth(0.0, 1.0, 0.5 + 0.5 * np.sin(2 * th + p[5])))
    spec2 = np.exp(-((s - 0.55) / 0.08) ** 2) * (0.25 + 0.5 * (0.5 + 0.5 * np.sin(4 * th + p[6])))
    hl = np.clip(spec + spec2 * 0.7, 0, 1)[..., None]
    col = col * (1 - hl * 0.9) + np.array([1.0, 1.0, 1.0]) * hl * 0.9
    # 바깥 테두리를 한 번 더 밝게 (유리 모서리)
    rim = (smooth(0.62, 0.95, d) * mask)[..., None]
    col = col * (1 - 0.45 * rim) + np.array([0.85, 0.97, 1.0]) * 0.45 * rim
    alpha = mask * (0.16 + 0.84 * (d ** 1.8))
    alpha = np.clip(alpha + hl[..., 0] * mask * 0.5, 0, 1)
    rgb = np.clip(col, 0, 1)
    # 물방울 몇 개
    img = np.concatenate([rgb, alpha[..., None]], -1)
    big = Image.fromarray((img * 255).astype(np.uint8), 'RGBA')
    dr = ImageDraw.Draw(big)
    for _ in range(9):
        a = rng.uniform(0, 6.28)
        rr = rng.uniform(0.88, 0.97)
        cx, cy = (rr * math.cos(a) + 1) / 2 * n, (rr * math.sin(a) + 1) / 2 * n
        rad = rng.uniform(0.006, 0.016) * n
        dr.ellipse([cx - rad, cy - rad, cx + rad, cy + rad], fill=(200, 235, 255, 230))
    glow = big.filter(ImageFilter.GaussianBlur(n * 0.012))
    out = Image.alpha_composite(glow, big)
    return out


def star_whale(n=256):
    ss = 4
    S = n * ss
    m = Image.new('L', (S, S), 0)
    d = ImageDraw.Draw(m)

    def P(x, y):
        return ((x + 1) / 2 * S, (1 - (y + 1) / 2) * S)

    # 몸통 중심선(베지어)과 두께
    P0, P1, P2, P3 = (0.90, 0.02), (0.35, -0.16), (-0.25, -0.14), (-0.58, 0.18)

    def bez(t):
        u = 1 - t
        return (u ** 3 * P0[0] + 3 * u * u * t * P1[0] + 3 * u * t * t * P2[0] + t ** 3 * P3[0],
                u ** 3 * P0[1] + 3 * u * u * t * P1[1] + 3 * u * t * t * P2[1] + t ** 3 * P3[1])

    top, bot = [], []
    N = 60
    for i in range(N + 1):
        t = i / N
        cx, cy = bez(t)
        ex, ey = bez(min(1, t + 0.01))
        bx, by = bez(max(0, t - 0.01))
        tx, ty = ex - bx, ey - by
        L = math.hypot(tx, ty) or 1
        nx, ny = -ty / L, tx / L
        w = 0.285 * (math.sin(math.pi * (t ** 0.62)) ** 0.85) * (1 - 0.45 * t) + 0.028 * t
        top.append((cx + nx * w * 0.92, cy + ny * w * 0.92))
        bot.append((cx - nx * w * 1.0, cy - ny * w * 1.0))
    d.polygon([P(*q) for q in top + bot[::-1]], fill=255)
    # 꼬리지느러미 (한 덩어리, 두 갈래)
    d.polygon([P(*q) for q in [(-0.64, 0.10), (-0.80, 0.28), (-0.99, 0.50), (-0.86, 0.52), (-0.70, 0.45), (-0.60, 0.60),
                               (-0.44, 0.66), (-0.47, 0.48), (-0.54, 0.30), (-0.50, 0.10)]], fill=255)
    # 가슴지느러미, 등지느러미
    d.polygon([P(*q) for q in [(0.38, -0.14), (0.10, -0.38), (-0.12, -0.55), (-0.06, -0.30), (0.12, -0.12)]], fill=255)
    d.polygon([P(*q) for q in [(-0.20, -0.02), (-0.30, 0.07), (-0.38, 0.0)]], fill=255)
    mask = m.resize((n, n), Image.LANCZOS)
    M = np.asarray(mask, float) / 255.0

    yy, xx = np.mgrid[0:n, 0:n]
    x = (xx + 0.5) / n * 2 - 1
    y = 1 - (yy + 0.5) / n * 2
    # 색: 머리쪽은 푸른색, 꼬리쪽은 보랏빛, 아래는 연하게
    tcol = np.clip((0.9 - x) / 1.9, 0, 1)[..., None]
    A, B = np.array([0.20, 0.42, 1.0]), np.array([0.58, 0.42, 1.0])
    col = A + (B - A) * tcol
    belly = np.clip((-y + 0.1) * 2.0, 0, 1)[..., None]
    col = col * (1 - 0.5 * belly) + np.array([0.70, 0.88, 1.0]) * 0.5 * belly
    # 몸통 줄무늬(배의 주름)
    rng = np.random.default_rng(11)
    stripes = (0.5 + 0.5 * np.sin(y * 70 + x * 5)) ** 6 * np.clip((x - 0.1) * 2, 0, 1) * np.clip(-y * 5, 0, 1)
    col = col + (np.array([0.9, 0.97, 1.0]) - col) * stripes[..., None] * 0.35
    # 은하 같은 얼룩
    from numpy.random import default_rng
    nz = default_rng(3).normal(size=(n // 8, n // 8))
    nz = np.asarray(Image.fromarray(((nz - nz.min()) / (nz.max() - nz.min()) * 255).astype(np.uint8)).resize((n, n), Image.BICUBIC), float) / 255
    col = col * (0.75 + 0.5 * nz[..., None])
    col = np.clip(col, 0, 1)
    # 별 점
    stars = np.zeros((n, n))
    ys, xs = np.nonzero(M > 0.6)
    idx = rng.choice(len(ys), size=min(170, len(ys)), replace=False)
    for k in idx:
        stars[ys[k], xs[k]] = rng.uniform(0.5, 1.0)
    stars = np.asarray(Image.fromarray((stars * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(1.3)), float) / 255 * 2.4
    # 테두리 빛 + 바깥 글로우
    glow = np.asarray(mask.filter(ImageFilter.GaussianBlur(n * 0.02)), float) / 255
    inner = np.asarray(mask.filter(ImageFilter.MinFilter(3)).filter(ImageFilter.GaussianBlur(1.2)), float) / 255
    rimv = np.clip(M - inner, 0, 1)[..., None]
    rgb = col * (0.80 + 0.2 * nz[..., None])
    rgb = rgb + (np.array([0.92, 0.97, 1.0]) - rgb) * np.clip(rimv * 1.1, 0, 0.8)
    rgb = rgb + (np.array([1.0, 1.0, 1.0]) - rgb) * np.clip(stars, 0, 1)[..., None]
    alpha = np.clip(np.maximum(M * (0.62 + 0.38 * nz), glow * 0.45) + np.clip(stars, 0, 1) * M, 0, 1)
    base = Image.fromarray((np.concatenate([np.clip(rgb, 0, 1), alpha[..., None]], -1) * 255).astype(np.uint8), 'RGBA')

    # 금빛 장식: 머리 옆 소용돌이 + 등 위로 길게 휘날리는 리본
    g = Image.new('RGBA', (S, S), (0, 0, 0, 0))
    gd = ImageDraw.Draw(g)

    def ribbon(pts, w0, w1, col=(255, 228, 170, 255)):
        for i in range(len(pts) - 1):
            t = i / (len(pts) - 1)
            w = (w0 + (w1 - w0) * t) * S
            gd.line([P(*pts[i]), P(*pts[i + 1])], fill=col, width=max(1, int(w)))

    sp = []
    for k in range(40):                     # 눈 옆 소용돌이
        t = k / 39
        a = 3.6 * t * math.pi
        rr = 0.075 * (1 - 0.8 * t)
        sp.append((0.60 + rr * math.cos(a), 0.015 + rr * math.sin(a)))
    ribbon(sp, 0.007, 0.003)
    sp2 = []
    for k in range(40):
        t = k / 39
        a = 3.0 * t * math.pi + 1.0
        rr = 0.055 * (1 - 0.8 * t)
        sp2.append((0.40 + rr * math.cos(a), -0.02 + rr * math.sin(a)))
    ribbon(sp2, 0.006, 0.0025)
    rb = []
    for k in range(60):                     # 등에서 꼬리쪽으로 휘날리는 긴 리본
        t = k / 59
        rb.append((0.42 - 1.15 * t, 0.17 + 0.46 * math.sin(t * math.pi * 0.9) * (1 - 0.25 * t) + 0.06 * math.sin(t * 9)))
    ribbon(rb, 0.007, 0.0015)
    rb2 = []
    for k in range(50):
        t = k / 49
        rb2.append((0.2 - 0.8 * t, 0.12 + 0.30 * math.sin(t * math.pi * 0.95) + 0.04 * math.sin(t * 11 + 1)))
    ribbon(rb2, 0.005, 0.0012, (255, 240, 205, 255))
    g = g.resize((n, n), Image.LANCZOS)
    gl = g.filter(ImageFilter.GaussianBlur(n * 0.006))
    out = Image.alpha_composite(base, gl)
    out = Image.alpha_composite(out, g)
    return out


for name, img in (('water_ring', water_ring(256, 5)), ('water_ring_b', water_ring(256, 21)),
                  ('hydro_ring', water_ring(256, 9)), ('star_whale', star_whale(256))):
    img.save(f'{TEX}/{name}.png')
    print('wrote', name)
