"""원소별 파티클 스프라이트 생성기 (임시 아트). 같은 이름으로 PNG를 덮어쓰면 게임에서 바로 교체됩니다."""
import json, math, os, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = sys.argv[1] if len(sys.argv) > 1 else '.'
TEX = f'{ROOT}/src/main/resources/assets/elementalgaze/textures/particle'
PDEF = f'{ROOT}/src/main/resources/assets/elementalgaze/particles'
os.makedirs(TEX, exist_ok=True); os.makedirs(PDEF, exist_ok=True)

SS = 4  # 슈퍼샘플링
PAL = {  # edge(가장자리), mid(중간), core(중심 밝은 색)
 'pyro':   dict(edge=(0.80, 0.12, 0.04), mid=(1.00, 0.52, 0.10), core=(1.00, 0.96, 0.70)),
 'hydro':  dict(edge=(0.10, 0.32, 0.85), mid=(0.30, 0.70, 1.00), core=(0.92, 1.00, 1.00)),
 'electro':dict(edge=(0.42, 0.18, 0.85), mid=(0.76, 0.50, 1.00), core=(1.00, 0.96, 1.00)),
 'cryo':   dict(edge=(0.42, 0.74, 0.95), mid=(0.76, 0.95, 1.00), core=(1.00, 1.00, 1.00)),
 'anemo':  dict(edge=(0.18, 0.66, 0.58), mid=(0.50, 0.95, 0.80), core=(0.95, 1.00, 0.98)),
 'geo':    dict(edge=(0.62, 0.42, 0.08), mid=(0.96, 0.76, 0.26), core=(1.00, 0.96, 0.72)),
 'dendro': dict(edge=(0.16, 0.50, 0.12), mid=(0.50, 0.86, 0.26), core=(0.92, 1.00, 0.72)),
}
SPECIAL = {'pyro': ('flame', 'ember'), 'hydro': ('drop', 'bubble'), 'electro': ('bolt', 'static'),
           'cryo': ('flake', 'crystal'), 'anemo': ('swirl', 'puff'), 'geo': ('shard', 'gem'), 'dendro': ('leaf', 'spore')}

def grid(size):
    y, x = np.mgrid[0:size, 0:size]
    return (x + 0.5) / size * 2 - 1, (y + 0.5) / size * 2 - 1
def px(pts, size): return [((x + 1) / 2 * size, (y + 1) / 2 * size) for x, y in pts]
def arr(im): return np.asarray(im, float) / 255.0
def mask_poly(pts, size):
    im = Image.new('L', (size, size), 0); ImageDraw.Draw(im).polygon(px(pts, size), fill=255); return arr(im)
def mask_lines(segs, size, width, fills=None):
    im = Image.new('L', (size, size), 0); d = ImageDraw.Draw(im)
    for i, (a, b) in enumerate(segs):
        d.line(px([a, b], size), fill=int(255 * (fills[i] if fills else 1)), width=max(1, int(width * size / 64)))
    return arr(im)
def blur(a, r, size):
    im = Image.fromarray((np.clip(a, 0, 1) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(r * size / 64))
    return arr(im)
def colorize(pal, inten):
    e, m, c = (np.array(pal[k]) for k in ('edge', 'mid', 'core'))
    t = np.clip(inten, 0, 1)[..., None]
    lo = e + (m - e) * np.clip(t * 2, 0, 1)
    hi = m + (c - m) * np.clip(t * 2 - 1, 0, 1)
    return np.where(t < 0.5, lo, hi)
def finish(alpha, inten, pal, n):
    rgb = colorize(pal, inten); a = np.clip(alpha, 0, 1)[..., None]
    im = Image.fromarray((np.concatenate([rgb, a], -1) * 255).astype(np.uint8), 'RGBA')
    return im.resize((n, n), Image.LANCZOS)
def poly_regular(k, r, rot=0.0): return [(r * math.cos(rot + 2 * math.pi * i / k), r * math.sin(rot + 2 * math.pi * i / k)) for i in range(k)]
def ring_mask(x, y, r0, w): return np.exp(-(((np.sqrt(x * x + y * y) - r0) / w) ** 2))

# ---------------- 공통 ----------------
def glow(p, n=64):
    s = n * SS; x, y = grid(s); r = np.sqrt(x * x + y * y)
    a = np.clip(1 - r, 0, 1) ** 2.2
    return finish(a, np.clip(1 - r * 1.1, 0, 1) ** 1.4, p, n)
def spark(p, n=64):
    s = n * SS; x, y = grid(s); r = np.sqrt(x * x + y * y)
    cross = np.exp(-np.abs(x) * np.abs(y) * 40) * np.clip(1 - r, 0, 1) ** 0.8
    core = np.clip(1 - r * 2.2, 0, 1) ** 2
    return finish(cross + core, cross * 0.9 + core, p, n)
def ring(p, n=128):
    s = n * SS; x, y = grid(s); a = ring_mask(x, y, 0.8, 0.05)
    return finish(a, a ** 0.7, p, n)
def sigil(name, p, n=128):
    s = n * SS; x, y = grid(s); r = np.sqrt(x * x + y * y)
    m = np.maximum.reduce([ring_mask(x, y, 0.92, 0.014), ring_mask(x, y, 0.84, 0.008), ring_mask(x, y, 0.46, 0.010)])
    w = 2.2
    if name == 'pyro':
        for i in range(12):
            a0 = 2 * math.pi * i / 12; a1 = a0 + math.pi / 12
            m = np.maximum(m, mask_poly([(0.5 * math.cos(a0 - .12), 0.5 * math.sin(a0 - .12)), (0.82 * math.cos(a1), 0.82 * math.sin(a1)), (0.5 * math.cos(a0 + .35), 0.5 * math.sin(a0 + .35))], s))
    elif name == 'hydro':
        th = np.linspace(0, 2 * math.pi, 240)
        segs = [((0.64 + 0.04 * math.sin(10 * t)) * math.cos(t), (0.64 + 0.04 * math.sin(10 * t)) * math.sin(t)) for t in th]
        m = np.maximum(m, mask_lines(list(zip(segs[:-1], segs[1:])), s, w))
        for i in range(12): m = np.maximum(m, np.exp(-(((x - 0.74 * math.cos(2 * math.pi * i / 12)) ** 2 + (y - 0.74 * math.sin(2 * math.pi * i / 12)) ** 2) / 0.0006)))
    elif name == 'electro':
        pts = poly_regular(8, 0.78, -math.pi / 2)
        m = np.maximum(m, mask_lines([(pts[i], pts[(i + 3) % 8]) for i in range(8)], s, w))
        m = np.maximum(m, mask_lines([((0.84 * math.cos(2 * math.pi * i / 8), 0.84 * math.sin(2 * math.pi * i / 8)), (0.92 * math.cos(2 * math.pi * i / 8), 0.92 * math.sin(2 * math.pi * i / 8))) for i in range(8)], s, w))
    elif name == 'cryo':
        segs = []
        for k in range(6):
            a = k * math.pi / 3; c, sn = math.cos(a), math.sin(a)
            segs.append(((0, 0), (0.8 * c, 0.8 * sn)))
            for f in (0.45, 0.65):
                for sg in (-1, 1):
                    b = a + sg * math.radians(55)
                    segs.append(((f * 0.8 * c, f * 0.8 * sn), (f * 0.8 * c + 0.18 * math.cos(b), f * 0.8 * sn + 0.18 * math.sin(b))))
        m = np.maximum(m, mask_lines(segs, s, w))
        hexp = poly_regular(6, 0.5); m = np.maximum(m, mask_lines([(hexp[i], hexp[(i + 1) % 6]) for i in range(6)], s, w))
    elif name == 'anemo':
        for k in range(3):
            pts = []
            for t in np.linspace(0, 1.4 * math.pi, 60):
                rr = 0.2 + 0.62 * t / (1.4 * math.pi); a = t + k * 2 * math.pi / 3
                pts.append((rr * math.cos(a), rr * math.sin(a)))
            m = np.maximum(m, mask_lines(list(zip(pts[:-1], pts[1:])), s, 3.0))
    elif name == 'geo':
        for pts in (poly_regular(6, 0.78, math.pi / 6), poly_regular(4, 0.78, math.pi / 4), poly_regular(6, 0.4)):
            m = np.maximum(m, mask_lines([(pts[i], pts[(i + 1) % len(pts)]) for i in range(len(pts))], s, w))
    else:  # dendro: 꽃잎 8장
        for i in range(8):
            a = 2 * math.pi * i / 8; c, sn = math.cos(a), math.sin(a); px_, py_ = -sn, c
            pts = [(0.5 * c, 0.5 * sn), (0.62 * c + 0.12 * px_, 0.62 * sn + 0.12 * py_), (0.8 * c, 0.8 * sn), (0.62 * c - 0.12 * px_, 0.62 * sn - 0.12 * py_)]
            m = np.maximum(m, mask_lines([(pts[j], pts[(j + 1) % 4]) for j in range(4)], s, w))
    m = np.clip(blur(m, 0.5, s) * 1.6 + m * 0.4, 0, 1)
    fill = np.clip(1 - r, 0, 1) ** 1.5 * 0.10
    return finish(np.clip(m + fill, 0, 1), np.clip(m + fill, 0, 1), p, n)

# ---------------- 원소별 ----------------
def flame(p, n=64):
    s = n * SS; x, y = grid(s); t = (y + 1) / 2
    wob = 0.07 * np.sin(7 * t + 1.2); w = np.maximum(0.62 * np.sin(np.pi * np.clip(t, 0, 1) ** 0.85) ** 0.9, 1e-3)
    a = np.clip(1 - np.abs(x - wob) / w, 0, 1) ** 0.9
    return finish(a, np.clip(a ** 0.6 * (0.35 + 0.65 * t), 0, 1), p, n)
def ember(p, n=64):
    s = n * SS; x, y = grid(s); r = np.sqrt(x * x + y * y)
    a = np.clip(1 - r / 0.55, 0, 1) ** 1.6; h = np.clip(1 - r, 0, 1) ** 3 * 0.35
    return finish(np.clip(a + h, 0, 1), np.clip(a * 1.2 + h, 0, 1), p, n)
def drop(p, n=64):
    s = n * SS; x, y = grid(s)
    c = (x ** 2 + (y - 0.22) ** 2) <= 0.52 ** 2
    hw = 0.52 * (y + 0.9) / 1.12; k = (y > -0.9) & (y < 0.22) & (np.abs(x) < hw)
    mask = (c | k).astype(float); hl = np.exp(-(((x + 0.18) ** 2 + (y - 0.0) ** 2) / 0.012)) * 0.7
    return finish(mask * 0.9, np.clip(0.45 + 0.3 * (1 - (y + 1) / 2) + hl, 0, 1), p, n)
def bubble(p, n=64):
    s = n * SS; x, y = grid(s); r = np.sqrt(x * x + y * y)
    fill = (r < 0.82) * 0.12; rim = np.exp(-(((r - 0.8) / 0.06) ** 2)) * 0.95; hl = np.exp(-(((x + 0.3) ** 2 + (y + 0.3) ** 2) / 0.012)) * 0.9
    return finish(np.clip(fill + rim + hl * 0.8, 0, 1), np.clip(rim * 0.8 + hl + fill * 0.3, 0, 1), p, n)
def bolt(p, n=64):
    s = n * SS
    pts = [(0.05, -0.95), (-0.25, -0.55), (0.2, -0.25), (-0.2, 0.05), (0.25, 0.35), (-0.1, 0.65), (0.05, 0.95)]
    segs = list(zip(pts[:-1], pts[1:])) + [((-0.2, 0.05), (-0.6, 0.25)), ((0.2, -0.25), (0.55, -0.1))]
    core = mask_lines(segs, s, 3.0); gl = blur(core, 3.0, s)
    return finish(np.clip(core + gl * 1.4, 0, 1), np.clip(core + gl * 0.6, 0, 1), p, n)
def static(p, n=64):
    s = n * SS; x, y = grid(s); r = np.sqrt(x * x + y * y)
    segs = [((0, 0), (0.7, -0.35)), ((0, 0), (-0.55, -0.6)), ((0, 0), (-0.3, 0.75)), ((0, 0), (0.5, 0.55)), ((0.7, -0.35), (0.85, -0.2))]
    core = mask_lines(segs, s, 2.2); gl = blur(core, 2.0, s); cg = np.clip(1 - r * 2.5, 0, 1) ** 2
    return finish(np.clip(core + gl * 1.2 + cg, 0, 1), np.clip(core + gl * 0.5 + cg, 0, 1), p, n)
def flake(p, n=64):
    s = n * SS; segs = []
    for k in range(6):
        a = k * math.pi / 3; c, sn = math.cos(a), math.sin(a)
        segs.append(((0, 0), (0.85 * c, 0.85 * sn)))
        for f in (0.45, 0.7):
            for sg in (-1, 1):
                b = a + sg * math.radians(55)
                segs.append(((f * c, f * sn), (f * c + 0.22 * math.cos(b), f * sn + 0.22 * math.sin(b))))
    core = mask_lines(segs, s, 2.4); gl = blur(core, 1.5, s)
    return finish(np.clip(core + gl * 0.6, 0, 1), np.clip(core * 0.9 + gl * 0.3 + 0.1, 0, 1), p, n)
def crystal(p, n=64):
    s = n * SS; x, y = grid(s)
    m = mask_poly([(0, -0.9), (0.38, -0.35), (0.3, 0.6), (0, 0.9), (-0.3, 0.6), (-0.38, -0.35)], s)
    edge = np.clip(m - blur(m, 1.4, s), 0, 1) * 2.0
    inten = np.where(x > 0, 0.82, 0.5) + np.exp(-(x / 0.05) ** 2) * 0.3 + edge * 0.4
    return finish(m * 0.92, np.clip(inten, 0, 1), p, n)
def swirl(p, n=64):
    s = n * SS; segs, fills = [], []
    th = np.linspace(0, 2.4 * math.pi, 70)
    pts = [((0.1 + 0.8 * t / (2.4 * math.pi)) * math.cos(t), (0.1 + 0.8 * t / (2.4 * math.pi)) * math.sin(t)) for t in th]
    for i in range(len(pts) - 1):
        segs.append((pts[i], pts[i + 1])); fills.append(1 - 0.6 * i / len(pts))
    core = mask_lines(segs, s, 3.2, fills); gl = blur(core, 2.0, s)
    return finish(np.clip(core + gl * 0.8, 0, 1), np.clip(core * 0.9 + 0.2, 0, 1), p, n)
def puff(p, n=64):
    s = n * SS; x, y = grid(s); r = np.sqrt(x * x + y * y); a = np.zeros_like(x)
    for bx, by, br in ((-0.25, 0.1, 0.38), (0.2, 0.15, 0.35), (0.0, -0.2, 0.4), (0.3, -0.1, 0.28), (-0.2, -0.25, 0.3)):
        a += np.exp(-(((x - bx) ** 2 + (y - by) ** 2) / (2 * (br / 1.6) ** 2)))
    return finish(np.clip(a * 0.55, 0, 0.85) * np.clip(1 - r, 0, 1) ** 0.5, np.clip(0.5 + 0.4 * a / (a.max() + 1e-6), 0, 1), p, n)
def shard(p, n=64):
    s = n * SS; x, y = grid(s)
    m = mask_poly([(-0.1, -0.9), (0.5, 0.1), (0.2, 0.85), (-0.45, 0.4)], s)
    edge = np.clip(m - blur(m, 1.4, s), 0, 1) * 2.0
    return finish(m * 0.95, np.clip(0.4 + 0.35 * (x + 1) / 2 + 0.25 * (1 - (y + 1) / 2) + edge * 0.35, 0, 1), p, n)
def gem(p, n=64):
    s = n * SS; x, y = grid(s)
    m = mask_poly([(0, -0.9), (0.65, 0), (0, 0.9), (-0.65, 0)], s)
    inten = np.select([(x >= 0) & (y < 0), (x < 0) & (y < 0), (x >= 0) & (y >= 0)], [0.9, 0.62, 0.45], 0.7)
    edge = np.clip(m - blur(m, 1.4, s), 0, 1) * 2.0; glint = np.exp(-(((x + 0.1) ** 2 + (y + 0.25) ** 2) / 0.01))
    return finish(m * 0.95, np.clip(inten + edge * 0.3 + glint, 0, 1), p, n)
def leaf(p, n=64):
    s = n * SS; x, y = grid(s); a = math.radians(35)
    u = x * math.cos(a) + y * math.sin(a); v = -x * math.sin(a) + y * math.cos(a)
    hw = 0.42 * np.sin(np.pi * np.clip((v + 0.9) / 1.8, 0, 1)) ** 0.8
    m = ((np.abs(u) < hw) & (np.abs(v) < 0.9)).astype(float); vein = ((np.abs(u) < 0.025) & (m > 0)).astype(float)
    return finish(m * 0.95, np.clip(0.38 + 0.32 * (v + 0.9) / 1.8 + vein * 0.4, 0, 1), p, n)
def spore(p, n=64):
    s = n * SS; x, y = grid(s); r = np.sqrt(x * x + y * y)
    a = np.clip(1 - r / 0.7, 0, 1) ** 2; c = np.clip(1 - r / 0.25, 0, 1) ** 1.5
    return finish(np.clip(a * 0.8 + c * 0.6, 0, 1), np.clip(a * 0.6 + c, 0, 1), p, n)

SPR = dict(flame=flame, ember=ember, drop=drop, bubble=bubble, bolt=bolt, static=static, flake=flake,
           crystal=crystal, swirl=swirl, puff=puff, shard=shard, gem=gem, leaf=leaf, spore=spore)
KINDS_COMMON = ['glow', 'spark', 'ring', 'flare', 'sigil']
sheet = {}
for el, pal in PAL.items():
    imgs = {'glow': glow(pal), 'spark': spark(pal), 'ring': ring(pal), 'sigil': sigil(el, pal)}
    for k in SPECIAL[el]: imgs[k] = SPR[k](pal)
    for name, im in imgs.items(): im.save(f'{TEX}/{el}_{name}.png', optimize=True)
    sheet[el] = imgs
    # 파티클 정의 JSON (flare 는 glow 스프라이트를 재사용)
    for k in KINDS_COMMON + list(SPECIAL[el]):
        tex = f'{el}_glow' if k == 'flare' else f'{el}_{k}'
        json.dump({'textures': [f'elementalgaze:{tex}']}, open(f'{PDEF}/{el}_{k}.json', 'w'))

# 미리보기 시트
cols = ['glow', 'spark', 'ring', 'sigil', 'special1', 'special2']
cell = 96; pad = 6; W = len(cols) * (cell + pad) + pad; H = len(PAL) * (cell + pad) + pad
bg = Image.new('RGBA', (W, H), (14, 16, 24, 255))
for r_, (el, imgs) in enumerate(sheet.items()):
    names = ['glow', 'spark', 'ring', 'sigil', SPECIAL[el][0], SPECIAL[el][1]]
    for c_, nm in enumerate(names):
        im = imgs[nm].resize((cell, cell), Image.LANCZOS)
        tile = Image.new('RGBA', (cell, cell), (0, 0, 0, 255)); tile.alpha_composite(im)
        bg.paste(tile, (pad + c_ * (cell + pad), pad + r_ * (cell + pad)))
bg.convert('RGB').save(f'{ROOT}/particle_preview.png')
print('sprites:', len(os.listdir(TEX)), '| descriptors:', len(os.listdir(PDEF)))
