import importlib.util, json, io, base64, math, pickle
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
SP = '/tmp/claude-0/-home-claude/310b0ad9-8ed9-5f21-819a-045a41230432/scratchpad'
spec = importlib.util.spec_from_file_location('cv', SP + '/convert_bb.py'); cv = importlib.util.module_from_spec(spec); spec.loader.exec_module(cv)
R = '/home/claude/elementalgaze/src/main/resources/assets/elementalgaze'
W = H = 128
rng = np.random.default_rng(8)

# ---- 텍스처 영역 (px) ----
BLADE = (0, 0, 28, 104)          # 날 앞/뒤 면 (가로 28 x 세로 104)
GOLD = (32, 0, 48, 16)
FEATH = (48, 0, 64, 32)          # 깃털: 위(끝)=청록, 아래(뿌리)=금
GLOW = (32, 16, 48, 32)          # 밝은 청백 (중심 능선/쉘)
WRAP = (32, 32, 48, 48)          # 손잡이 감개
GEM = (48, 32, 64, 48)
DGOLD = (64, 0, 80, 16)          # 어두운 금 (판)
SHELL = (64, 16, 80, 32)         # 반투명 쉘 색 (하늘색)


def tex():
    im = Image.new('RGBA', (W, H), (0, 0, 0, 0)); px = im.load()
    # 날: 위(끝)는 청백, 아래(자루쪽)는 금빛이 도는 흰색, 가운데는 밝고 가장자리는 푸르게 + 금 테두리 + 룬
    x0, y0, x1, y1 = BLADE
    for y in range(y0, y1):
        t = (y - y0) / (y1 - y0 - 1)
        top = np.array([200, 236, 255]); mid = np.array([236, 246, 255]); bot = np.array([255, 238, 205])
        base = top + (mid - top) * min(1, t * 2) if t < 0.5 else mid + (bot - mid) * (t - 0.5) * 2
        for x in range(x0, x1):
            u = (x - x0) / (x1 - x0 - 1)
            edge = abs(u - 0.5) * 2
            col = base * (1 - 0.30 * edge ** 1.6) + np.array([120, 180, 235]) * 0.30 * edge ** 1.6
            col = col + rng.integers(-5, 6, 3)
            if edge > 0.86:   # 금 테두리
                col = np.array([236, 190, 90]) + rng.integers(-6, 7, 3)
            if abs(u - 0.5) < 0.05:   # 중심 능선
                col = col * 0.7 + np.array([255, 255, 255]) * 0.3
            px[x, y] = tuple(int(max(0, min(255, c))) for c in col) + (255,)
    d = ImageDraw.Draw(im)
    gl = [(210, 160, 70, 255), (190, 140, 60, 255)]
    for k in range(13):   # 룬 문양: 중심선 양옆의 짧은 획
        yy = 10 + k * 7
        cx = 14
        kind = k % 4
        c = gl[k % 2]
        if kind == 0:
            d.line([cx - 4, yy, cx - 4, yy + 4], fill=c); d.line([cx - 4, yy + 2, cx - 1, yy + 2], fill=c)
            d.line([cx + 4, yy, cx + 4, yy + 4], fill=c)
        elif kind == 1:
            d.line([cx - 5, yy + 4, cx - 3, yy], fill=c); d.line([cx - 3, yy, cx - 1, yy + 4], fill=c)
            d.line([cx + 3, yy, cx + 5, yy + 4], fill=c)
        elif kind == 2:
            d.rectangle([cx - 5, yy, cx - 2, yy + 3], outline=c); d.line([cx + 3, yy, cx + 5, yy + 4], fill=c)
        else:
            d.line([cx - 5, yy, cx - 2, yy + 4], fill=c); d.line([cx - 2, yy, cx - 5, yy + 4], fill=c)
            d.line([cx + 3, yy + 2, cx + 6, yy + 2], fill=c)

    def fill(box, c0, c1, noise=6, a=255, horiz=False):
        a0, b0, a1, b1 = box
        for y in range(b0, b1):
            for x in range(a0, a1):
                t = (x - a0) / max(1, a1 - a0 - 1) if horiz else (y - b0) / max(1, b1 - b0 - 1)
                col = [int(c0[i] + (c1[i] - c0[i]) * t + rng.integers(-noise, noise + 1)) for i in range(3)]
                px[x, y] = tuple(max(0, min(255, c)) for c in col) + (a,)
    fill(GOLD, (255, 232, 150), (226, 168, 66), 7)
    for y in range(GOLD[1] + 1, GOLD[3], 4):
        for x in range(GOLD[0], GOLD[2]): px[x, y] = (255, 246, 190, 255)
    fill(FEATH, (96, 224, 220), (240, 196, 92), 8)      # 위: 청록 -> 아래: 금
    for y in range(FEATH[1], FEATH[3]):                  # 깃털 가운데 맥
        px[(FEATH[0] + FEATH[2]) // 2, y] = (255, 246, 200, 255)
    fill(GLOW, (200, 255, 255), (150, 225, 255), 4)
    fill(WRAP, (36, 70, 84), (24, 46, 60), 6)
    for y in range(WRAP[1], WRAP[3], 3):
        for x in range(WRAP[0], WRAP[2]):
            if (x + y) % 6 < 2: px[x, y] = (70, 130, 140, 255)
    fill(GEM, (140, 240, 255), (60, 150, 255), 5)
    fill(DGOLD, (214, 160, 66), (150, 100, 40), 6)
    fill(SHELL, (170, 225, 255), (210, 240, 255), 4)
    return im


def cube(uid, name, frm, to, org, rot, regs, inflate=0.0):
    faces = {}
    for k in ('north', 'east', 'south', 'west', 'up', 'down'):
        r = regs[k] if isinstance(regs, dict) else regs
        faces[k] = {'uv': list(r), 'texture': 0}
    e = {'uuid': uid, 'name': name, 'type': 'cube', 'from': frm, 'to': to, 'origin': org, 'rotation': rot, 'faces': faces}
    if inflate: e['inflate'] = inflate
    return e


els = []
ids = []


def add(name, frm, to, org=None, rot=(0, 0, 0), regs=GOLD, inflate=0.0):
    e = cube(f'e{len(els)}', name, list(frm), list(to), list(org if org is not None else [0, 0, 0]), list(rot), regs, inflate)
    els.append(e); ids.append(e['uuid'])


# ---- 날 (폭 16, 두께 2.2, 길이 위로) : 끝은 여러 단계로 좁아져 뾰족하게 ----
bl = {k: BLADE for k in ('north', 'south')}
bl.update({'east': GOLD, 'west': GOLD, 'up': GOLD, 'down': GOLD})
HW = 8.0
add('blade_main', (-HW, 8, -1.1), (HW, 70, 1.1), regs=bl)
tip = [(70, 75, 7.4), (75, 79, 6.6), (79, 83, 5.6), (83, 87, 4.5), (87, 91, 3.5), (91, 94.5, 2.5), (94.5, 97.5, 1.6), (97.5, 99.5, 0.8), (99.5, 101, 0.3)]
for i, (y0, y1, w) in enumerate(tip):
    t = 0.12 * i
    add(f'blade_tip{i}', (-w, y0, -1.1 + t * 0.6), (w, y1, 1.1 - t * 0.6), regs=bl)
add('ridge', (-0.6, 9, -1.55), (0.6, 94, 1.55), regs=GLOW)
add('trimL', (-HW - 0.9, 8, -1.3), (-HW, 70.5, 1.3), regs=GOLD)
add('trimR', (HW, 8, -1.3), (HW + 0.9, 70.5, 1.3), regs=GOLD)
add('blade_outline', (-HW, 8, -1.1), (HW, 72, 1.1), regs=SHELL, inflate=1.0)
add('tip_outline', (-6.4, 72, -0.9), (6.4, 86, 0.9), regs=SHELL, inflate=0.8)

# ---- 날 아래쪽 척추 판 (용의 등뼈처럼 겹쳐진 금 판) ----
for i, (y, w) in enumerate(((9, 9.4), (14.5, 8.8), (20, 8.2), (25.5, 7.4), (31, 6.4))):
    add(f'plate{i}', (-w, y, -2.1), (w, y + 3.4, 2.1), regs=DGOLD if i % 2 else GOLD)
    add(f'plateTop{i}', (-w + 1.4, y + 3.4, -1.7), (w - 1.4, y + 4.3, 1.7), regs=GOLD)
for i in range(5):
    y = 11 + i * 5.8
    add(f'spike{i}L', (-11.6, y, -0.7), (-9.2, y + 2.2, 0.7), regs=GOLD)
    add(f'spike{i}R', (9.2, y, -0.7), (11.6, y + 2.2, 0.7), regs=GOLD)

# ---- 날밑: 중앙 마름모 + 보석 + 곡선 깃털 날개 ----
add('guardCore', (-7.0, 2.0, -2.8), (7.0, 8.0, 2.8), regs=GOLD)
add('guardCap', (-4.6, 8.0, -2.4), (4.6, 9.6, 2.4), regs=DGOLD)
add('gem', (-2.4, 3.2, -3.2), (2.4, 7.8, 3.2), org=(0, 5.5, 0), rot=(0, 0, 45), regs=GEM)
add('gemGlow', (-3.6, 2.1, -3.6), (3.6, 8.9, 3.6), org=(0, 5.5, 0), rot=(0, 0, 45), regs=GLOW, inflate=0.2)
els[-1]['name'] = 'gem_outline'


def feather(name, base, length, width, az, curve, bz_off=0.0, thick=0.9, segs=3):
    """곡선 깃털: segs 개의 조각이 이어지며 각도가 curve 만큼씩 더 꺾인다 (XY 평면, z 로 겹쳐 입체감)"""
    x, y, z = base
    ang = az
    per = length / segs
    for i in range(segs):
        w = width * (1.0 - 0.28 * i)
        th = thick * (1.0 - 0.15 * i)
        add(f'{name}{i}', (x - w / 2, y, z + bz_off - th / 2), (x + w / 2, y + per, z + bz_off + th / 2), org=(x, y, z + bz_off), rot=(0, 0, ang), regs=FEATH)
        r = math.radians(ang)
        x, y = x - math.sin(r) * per, y + math.cos(r) * per
        ang += curve


for side, sgn in (('L', 1), ('R', -1)):
    layers = ((24, 46, 5.4, 10, 0.0), (42, 42, 5.2, 11, 0.9), (60, 37, 5.0, 12, -0.9), (78, 31, 4.6, 12, 0.7), (98, 25, 4.2, 10, -0.7), (120, 19, 3.6, 8, 0.5))
    for i, (ang, ln, wd, cv_, zo) in enumerate(layers):
        feather(f'wing{side}{i}', (sgn * -5.0, 6.0, 0), ln, wd, sgn * ang, sgn * cv_, zo)
    for i, (ang, ln, wd, cv_, zo) in enumerate(((33, 34, 4.0, 9, 1.8), (52, 30, 3.8, 10, -1.8), (72, 25, 3.6, 10, 1.6), (92, 20, 3.2, 8, -1.6))):
        feather(f'wingB{side}{i}', (sgn * -4.5, 5.0, 0), ln, wd, sgn * ang, sgn * cv_, zo, 0.7)
feather('plumeL', (-8.8, 38, 0), 36, 3.4, 10, 6, 0.0, 0.8)
feather('plumeR', (8.8, 38, 0), 36, 3.4, -10, -6, 0.0, 0.8)

# ---- 손잡이와 자루머리 ----
add('grip', (-1.7, -26, -1.7), (1.7, 2.0, 1.7), regs=WRAP)
for i in range(4):
    add(f'ring{i}', (-2.1, -24 + i * 6.5, -2.1), (2.1, -22.4 + i * 6.5, 2.1), regs=GOLD)
add('pommel', (-3.2, -31, -3.2), (3.2, -26, 3.2), regs=GOLD)
add('pommelGem', (-1.8, -34.5, -1.8), (1.8, -30.5, 1.8), org=(0, -32.5, 0), rot=(0, 0, 45), regs=GEM)
feather('tailL', (-2.0, -30, 0), 24, 3.2, 168, 8, 0.0, 0.7)
feather('tailR', (2.0, -30, 0), 24, 3.2, -168, -8, 0.0, 0.7)

root = {'uuid': 'g_sword', 'name': 'sword', 'origin': [0, 0, 0], 'rotation': [0, 0, 0], 'children': ids}
buf = io.BytesIO(); tex().save(buf, 'PNG')
model = {'resolution': {'width': W, 'height': H}, 'elements': els, 'outliner': [root], 'animations': [],
         'textures': [{'name': 'phainon_sword', 'uv_width': W, 'uv_height': H, 'source': 'data:image/png;base64,' + base64.b64encode(buf.getvalue()).decode()}]}
json.dump(model, open(SP + '/phainon_sword.bbmodel', 'w'))
data, img = cv.convert(model, f'{R}/summon_models/phainon_sword.json', f'{R}/textures/entity/summon/phainon_sword.png', 'phainon_sword')
print('bones', len(data['bones']), 'quads', sum(len(b['q']) for b in data['bones']), 'size', data['size'], 'center', data['center'])
m = pickle.load(open(SP + '/models.pkl', 'rb')); m['phainon_sword'] = data; pickle.dump(m, open(SP + '/models.pkl', 'wb'))
