"""아나스타샤(얼음 여왕 + 아르테미스) 파티클 스프라이트 생성기 (임시 아트). 같은 이름 PNG로 덮어쓰면 교체됩니다.
  moon_circle : 하늘에 뜨는 달·별자리 마법진 (달의 위상 고리, 활과 화살 별자리, 8개 화살촉)
  star_glyph  : 땅에 깔리는 별 문양 (예고/착탄)
  frost_band  : 기둥을 감싸는 얼음 왕관 모양 띠
  star4       : 황금빛 네 갈래 별
"""
import math, os, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = sys.argv[1] if len(sys.argv) > 1 else '.'
TEX = f'{ROOT}/src/main/resources/assets/elementalgaze/textures/particle'
os.makedirs(TEX, exist_ok=True)
src = open(os.path.join(HERE, 'gen_aztec.py'), encoding='utf-8').read()
ns = {'__file__': os.path.join(HERE, 'gen_aztec.py'), '__name__': 'gen_aztec_lib'}
sys.argv = [sys.argv[0], ROOT]
exec(compile(src[:src.index('def sun_stone')], 'gen_aztec_lib', 'exec'), ns)
Canvas = ns['Canvas']
ICE = (np.array([0.20, 0.45, 0.90]), np.array([0.62, 0.88, 1.0]), np.array([1.0, 1.0, 1.0]))
GOLD = (np.array([0.80, 0.45, 0.08]), np.array([1.0, 0.82, 0.35]), np.array([1.0, 1.0, 0.88]))
def use(p): ns['EDGE'], ns['MID'], ns['CORE'] = p

def star(c, cx, cy, R, r, k=4, rot=-math.pi / 2, v=255):
    pts = []
    for i in range(2 * k):
        a = rot + math.pi * i / k
        rad = R if i % 2 == 0 else r
        pts.append((cx + rad * math.cos(a), cy + rad * math.sin(a)))
    c.poly(pts, v)

def crescent(c, cx, cy, R, phase):
    """phase 0=초승달 ... 1=보름달"""
    c.disc(cx, cy, R)
    if phase < 0.98:
        c.disc(cx + R * (1.15 - phase * 0.9) * (1 if phase < 0.5 else -1) * (1 if phase < 0.5 else 0.3), cy - R * 0.1, R * (0.95 if phase < 0.5 else 0.5), 0)

def line(c, a, b, w=0.012):
    c.d.line([c.P(*a), c.P(*b)], fill=255, width=max(1, int(w * c.s / 2)))

def moon_circle(n=256):
    use(ICE); c = Canvas(n)
    c.ring(0.955, 0.985); c.ring(0.87, 0.885)
    for i in range(48):                                      # 눈금
        a = 2 * math.pi * i / 48
        r0, r1 = (0.90, 0.945) if i % 4 == 0 else (0.915, 0.94)
        line(c, (r0 * math.cos(a), r0 * math.sin(a)), (r1 * math.cos(a), r1 * math.sin(a)), 0.008)
    for i in range(12):                                      # 달의 위상 12개
        a = 2 * math.pi * i / 12 - math.pi / 2
        crescent(c, 0.775 * math.cos(a), 0.775 * math.sin(a), 0.062, i / 11.0)
    c.ring(0.655, 0.67)
    # 8개의 화살촉(창끝) : 마법진 밖으로 길게
    for i in range(8):
        a = 2 * math.pi * i / 8 + math.pi / 8
        ca, sa = math.cos(a), math.sin(a)
        tip = (1.0 * ca, 1.0 * sa)
        base = 0.66
        w = 0.07
        c.poly([tip, (base * ca - w * sa, base * sa + w * ca), (base * ca + w * sa, base * sa - w * ca)])
        c.poly([(0.93 * ca, 0.93 * sa), (0.70 * ca - w * 0.4 * sa, 0.70 * sa + w * 0.4 * ca), (0.70 * ca + w * 0.4 * sa, 0.70 * sa - w * 0.4 * ca)], 0)
    c.ring(0.50, 0.515)
    # 활과 화살 별자리 (중앙)
    bow = [(-0.30 * math.cos(t) + 0.0, -0.30 * math.sin(t)) for t in np.linspace(-1.25, 1.25, 9)]
    bow = [(-0.12 + 0.30 * math.cos(t) * -1 * -1 * 0 + (-0.30) * (1 - math.cos(t)) * -1, 0.30 * math.sin(t)) for t in np.linspace(-1.25, 1.25, 9)]
    pts = [(-0.22 + 0.34 * math.cos(t) - 0.34 + 0.0, 0.34 * math.sin(t)) for t in np.linspace(-1.2, 1.2, 9)]
    pts = [(x + 0.30, y) for x, y in pts]
    for a, b in zip(pts[:-1], pts[1:]): line(c, a, b, 0.012)
    line(c, pts[0], pts[-1], 0.006)                          # 시위
    line(c, (-0.30, 0.0), (0.40, 0.0), 0.010)                # 화살대
    c.poly([(0.46, 0.0), (0.36, -0.04), (0.36, 0.04)])       # 화살촉
    c.poly([(-0.30, 0.0), (-0.36, -0.045), (-0.33, 0.0), (-0.36, 0.045)])   # 깃
    for p in pts[::2]: star(c, p[0], p[1], 0.036, 0.011)
    star(c, 0.40, 0.0, 0.05, 0.015)
    crescent(c, 0.0, -0.33, 0.075, 0.25)                     # 달
    for (x, y) in ((-0.2, 0.30), (0.12, 0.34), (-0.34, -0.12), (0.30, -0.22)):
        star(c, x, y, 0.03, 0.009)
    return c.finish()

def star_glyph(n=128):
    use(ICE); c = Canvas(n)
    c.ring(0.90, 0.975); c.ring(0.70, 0.72)
    for i in range(4):                                       # 네 갈래 큰 별
        pass
    star(c, 0, 0, 0.98, 0.20, 4, -math.pi / 2)
    star(c, 0, 0, 0.62, 0.15, 4, -math.pi / 4)
    c.disc(0, 0, 0.26, 0); c.ring(0.17, 0.22)
    crescent(c, 0, 0, 0.11, 0.2)
    for i in range(16):
        a = 2 * math.pi * i / 16
        c.disc(0.81 * math.cos(a), 0.81 * math.sin(a), 0.022)
    return c.finish()

def frost_band(n=128):
    use(ICE); c = Canvas(n)
    c.ring(0.60, 0.64); c.ring(0.80, 0.83)
    for i in range(16):                                      # 얼음 왕관 가시
        a = 2 * math.pi * (i + 0.5) / 16
        ca, sa = math.cos(a), math.sin(a)
        L = 0.99 if i % 2 == 0 else 0.92
        w = 0.085 if i % 2 == 0 else 0.06
        c.poly([(L * ca, L * sa), (0.80 * ca - w * sa, 0.80 * sa + w * ca), (0.80 * ca + w * sa, 0.80 * sa - w * ca)])
        c.poly([((L - 0.07) * ca, (L - 0.07) * sa), (0.82 * ca - w * 0.4 * sa, 0.82 * sa + w * 0.4 * ca), (0.82 * ca + w * 0.4 * sa, 0.82 * sa - w * 0.4 * ca)], 0)
    for i in range(16):
        a = 2 * math.pi * i / 16
        c.disc(0.70 * math.cos(a), 0.70 * math.sin(a), 0.02)
    return c.finish()

def star4(n=64):
    use(GOLD); c = Canvas(n, ss=6)
    star(c, 0, 0, 0.98, 0.17, 4)
    star(c, 0, 0, 0.52, 0.2, 4, -math.pi / 4)
    c.disc(0, 0, 0.14)
    return c.finish()

for name, fn in (('moon_circle', moon_circle), ('star_glyph', star_glyph), ('frost_band', frost_band), ('star4', star4)):
    fn().save(f'{TEX}/{name}.png'); print('wrote', name)
