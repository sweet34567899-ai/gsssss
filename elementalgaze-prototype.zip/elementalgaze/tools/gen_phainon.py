"""파이논용 스프라이트 생성기 (임시 아트). 같은 이름 PNG로 덮어쓰면 교체됩니다.
  dawn_slash  : 금빛 흰 심 + 하늘빛 + 은은한 분홍/청록 번짐의 횡베기 초승달 검기 (fire_slash 와 같은 방향 규약)
  dawn_circle : 태양(금색 광선)과 새벽(하늘색 꽃잎/깃털)이 섞인 화려한 하늘 마법진
  giant_sword : 대각으로 떨어지는 거대한 빛의 검 (끝이 오른쪽 아래)
  chain_a/b   : 검붉은 사슬 고리 (정면 / 측면)
  orb_rim     : 검은 구체를 감싸는 선홍빛 테두리 고리
"""
import math, os, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = sys.argv[1] if len(sys.argv) > 1 else '.'
TEX = f'{ROOT}/src/main/resources/assets/elementalgaze/textures/particle'
os.makedirs(TEX, exist_ok=True)
rng = np.random.default_rng(42)

GOLD = np.array([1.0, 0.80, 0.30]); GOLD_HI = np.array([1.0, 0.96, 0.72])
SKY = np.array([0.45, 0.74, 1.0]); SKY_HI = np.array([0.85, 0.95, 1.0])
PINK = np.array([1.0, 0.65, 0.85]); TEAL = np.array([0.35, 1.0, 0.9])


def blur(a, r):
    return np.asarray(Image.fromarray((np.clip(a, 0, 1) * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(r)), float) / 255.0


def to_img(rgb, alpha):
    return Image.fromarray((np.concatenate([np.clip(rgb, 0, 1), np.clip(alpha, 0, 1)[..., None]], -1) * 255).astype(np.uint8), 'RGBA')


def grid(n):
    yy, xx = np.mgrid[0:n, 0:n]
    return (xx + 0.5) / n * 2 - 1, (yy + 0.5) / n * 2 - 1


# ----------------------------------------------------------------- 횡베기 (사용자가 준 참고 이미지 1번 칸을 투명 PNG 로 변환)
def dawn_slash(n=512):
    src = Image.open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'src_slash_ref.png')).convert('RGB')
    c = src.crop((75, 30, 460, 235))
    a = np.asarray(c).astype(float)
    bg = np.asarray(c.filter(ImageFilter.MinFilter(21)).filter(ImageFilter.GaussianBlur(30))).astype(float)
    m = np.clip(a - bg - 26, 0, None).max(2)
    alpha = np.clip(m / 90, 0, 1)
    h, w = alpha.shape
    yy, xx = np.mgrid[0:h, 0:w]
    alpha *= np.clip(np.minimum(np.minimum(xx, w - 1 - xx), np.minimum(yy, h - 1 - yy)) / 12, 0, 1)
    # 가운데 실루엣(캐릭터 그림자)과 얼룩을 지운다
    d = np.sqrt(((xx - w * 0.54) / (w * 0.22)) ** 2 + ((yy - h * 0.66) / (h * 0.27)) ** 2)
    alpha *= np.clip((d - 0.9) / 0.35, 0, 1)
    rgb = np.clip(a / 255 * 1.2, 0, 1)
    # 청록을 하늘빛 쪽으로 살짝 옮기고 금빛 가장자리는 유지
    warm = np.clip((rgb[..., 0] - rgb[..., 2]) * 4, 0, 1)                      # 따뜻한 하이라이트는 금빛으로
    rgb = np.stack([rgb[..., 0], rgb[..., 1] * (0.88 + 0.06 * warm), np.clip(rgb[..., 2] * (1.08 - 0.62 * warm), 0, 1)], -1)
    I = Image.fromarray((np.concatenate([np.clip(rgb, 0, 1), alpha[..., None]], -1) * 255).astype(np.uint8), 'RGBA')
    I = I.resize((w, int(h * 1.85)), Image.LANCZOS)      # 비스듬히 본 그림을 위에서 본 모양으로 펴 준다
    w, h = I.size
    sq = max(w, h)
    out = Image.new('RGBA', (sq, sq), (0, 0, 0, 0))
    out.paste(I, ((sq - w) // 2, (sq - h) // 2))
    return out.resize((n, n), Image.LANCZOS)


# ----------------------------------------------------------------- 하늘 마법진 (태양 + 새벽)
def dawn_circle(n=512):
    ss = 3
    S = n * ss
    gold = Image.new('L', (S, S), 0); blue = Image.new('L', (S, S), 0); white = Image.new('L', (S, S), 0)
    G, B, W = ImageDraw.Draw(gold), ImageDraw.Draw(blue), ImageDraw.Draw(white)

    def P(px, py):
        return ((px + 1) / 2 * S, (py + 1) / 2 * S)

    def ring(D, r0, r1, v=255):
        D.ellipse([*P(-r1, -r1), *P(r1, r1)], fill=v)
        D.ellipse([*P(-r0, -r0), *P(r0, r0)], fill=0)

    def line(D, a, b, w, v=255):
        D.line([P(*a), P(*b)], fill=v, width=max(1, int(w * S / 2)))

    def poly(D, pts, v=255):
        D.polygon([P(*p) for p in pts], fill=v)

    def pol(r, a):
        return (r * math.cos(a), r * math.sin(a))

    # 바깥 이중 고리와 눈금
    ring(B, 0.965, 0.990); ring(B, 0.915, 0.928); ring(G, 0.890, 0.898, 200)
    for i in range(96):
        a = 2 * math.pi * i / 96
        r0 = 0.935 if i % 4 else 0.925
        line(B, pol(r0, a), pol(0.958, a), 0.004 if i % 4 else 0.007)
    for i in range(24):                                     # 룬 대신 작은 다이아몬드
        a = 2 * math.pi * (i + 0.5) / 24
        c = pol(0.903, a)
        poly(G, [(c[0] + 0.02 * math.cos(a), c[1] + 0.02 * math.sin(a)), (c[0] - 0.015 * math.sin(a), c[1] + 0.015 * math.cos(a)),
                 (c[0] - 0.02 * math.cos(a), c[1] - 0.02 * math.sin(a)), (c[0] + 0.015 * math.sin(a), c[1] - 0.015 * math.cos(a))])
    # 태양 광선: 길고 뾰족한 금빛 12개 + 짧은 12개 (새벽 햇살)
    for i in range(12):
        a = 2 * math.pi * i / 12
        poly(G, [pol(0.58, a - 0.075), pol(0.885, a), pol(0.58, a + 0.075)])
        poly(W, [pol(0.64, a - 0.03), pol(0.80, a), pol(0.64, a + 0.03)], 255)
        b = a + math.pi / 12
        poly(G, [pol(0.60, b - 0.045), pol(0.78, b), pol(0.60, b + 0.045)], 190)
    # 물결 모양 햇살 (곡선 광선)
    for i in range(12):
        a = 2 * math.pi * i / 12 + math.pi / 24
        pts = [pol(0.50 + 0.36 * t, a + 0.10 * math.sin(t * math.pi * 2)) for t in np.linspace(0, 1, 18)]
        for p, q in zip(pts[:-1], pts[1:]):
            line(G, p, q, 0.006, 170)
    # 새벽의 꽃잎/깃털 고리 (하늘색): 16장 바깥 + 16장 안쪽
    for i in range(16):
        a = 2 * math.pi * i / 16
        pts = []
        for t in np.linspace(0, 1, 14):
            wdt = 0.085 * math.sin(math.pi * t) ** 0.9
            pts.append(pol(0.36 + 0.26 * t, a + wdt / (0.36 + 0.26 * t) * 1.0))
        pts2 = [pol(0.36 + 0.26 * t, a - 0.085 * math.sin(math.pi * t) ** 0.9 / (0.36 + 0.26 * t)) for t in np.linspace(1, 0, 14)]
        pp = pts + pts2
        for p, q in zip(pp, pp[1:] + pp[:1]):
            line(B, p, q, 0.006)
        line(B, pol(0.37, a), pol(0.60, a), 0.004, 200)
    for i in range(16):
        a = 2 * math.pi * (i + 0.5) / 16
        pts = [pol(0.34 + 0.18 * t, a + 0.06 * math.sin(math.pi * t) / (0.34 + 0.18 * t) * 1.2) for t in np.linspace(0, 1, 10)]
        pts += [pol(0.34 + 0.18 * t, a - 0.06 * math.sin(math.pi * t) / (0.34 + 0.18 * t) * 1.2) for t in np.linspace(1, 0, 10)]
        for p, q in zip(pts, pts[1:] + pts[:1]):
            line(G, p, q, 0.005, 210)
    # 별 문양 {8/3} 와 안쪽 고리
    ring(B, 0.335, 0.345); ring(G, 0.285, 0.293, 220); ring(B, 0.205, 0.213)
    pts = [pol(0.33, 2 * math.pi * k / 8) for k in range(8)]
    for k in range(8):
        line(G, pts[k], pts[(k + 3) % 8], 0.006, 230)
    # 중앙 태양: 원반 + 16 광선
    for i in range(16):
        a = 2 * math.pi * i / 16
        poly(G, [pol(0.15, a - 0.10), pol(0.265 if i % 2 == 0 else 0.215, a), pol(0.15, a + 0.10)])
    ring(W, 0.0, 0.10, 255)
    ring(G, 0.11, 0.135, 230)
    ring(W, 0.058, 0.07, 120)
    gold_a = np.asarray(gold.resize((n, n), Image.LANCZOS), float) / 255
    blue_a = np.asarray(blue.resize((n, n), Image.LANCZOS), float) / 255
    white_a = np.asarray(white.resize((n, n), Image.LANCZOS), float) / 255
    x, y = grid(n)
    r = np.sqrt(x * x + y * y)
    th = np.arctan2(y, x)
    m = np.clip(np.maximum(gold_a, blue_a), 0, 1)
    glow = blur(m, n * 0.010)
    glow2 = blur(m, n * 0.035)
    # 색: 금 / 하늘, 방사 방향으로 분홍/청록이 살짝 흐른다
    ph = (0.5 + 0.5 * np.sin(th * 4 + r * 6.0))[..., None]
    accent = PINK * ph + TEAL * (1 - ph)
    gm = (gold_a / np.maximum(m, 1e-3))[..., None] * (m[..., None] > 0.01)
    col_g = GOLD + (GOLD_HI - GOLD) * np.clip(1.2 - r[..., None] * 1.3, 0, 1)
    col_b = SKY + (SKY_HI - SKY) * np.clip(1.0 - r[..., None], 0, 1) * 0.6
    rgb = col_g * gm + col_b * (1 - gm)
    rgb = rgb + (accent - rgb) * np.clip(glow - m, 0, 1)[..., None] * 0.6
    rgb = rgb + (np.array([1.0, 1.0, 1.0]) - rgb) * (white_a[..., None] * 0.9 + 0.12 * m[..., None])
    # 중심으로 갈수록 환하게 (새벽빛이 번지는 느낌)
    core = np.clip(1.0 - r / 0.55, 0, 1)[..., None] ** 2
    rgb = rgb + (np.array([1.0, 0.95, 0.8]) - rgb) * core * 0.35
    alpha = np.clip(m + glow * 0.6 + glow2 * 0.28 + white_a * 0.5, 0, 1)
    return to_img(rgb, alpha)


# ----------------------------------------------------------------- 거대한 검 (오리지널 디자인)
def giant_sword(n=512):
    """검은 날 + 청록 상감 + 금 장식 + 흰 깃털 날개 날밑. 끝이 오른쪽 아래(세로축에서 33도)를 향한다.
    일반 알파 블렌딩으로 그려야 어두운 날이 보인다(가산 합성이면 검은색이 투명해진다)."""
    ss = 2
    S = n * ss
    names = ('blade', 'bevel', 'trim', 'inlay', 'ridge', 'wingW', 'wingB', 'gold', 'goldD', 'gem')
    layers = {k: Image.new('L', (S, S), 0) for k in names}
    D = {k: ImageDraw.Draw(v) for k, v in layers.items()}
    tilt = math.radians(33)
    L = 2.20
    st, ct = math.sin(tilt), math.cos(tilt)

    def T(u, v):
        v = v - 0.34 * L
        return (((v * st + u * ct) + 1) / 2 * S, ((v * ct - u * st) + 1) / 2 * S)

    def poly(k, pts, val=255):
        D[k].polygon([T(*p) for p in pts], fill=val)

    def line(k, a_, b_, w, val=255):
        D[k].line([T(*a_), T(*b_)], fill=val, width=max(1, int(w * S / 2)))

    bl = 1.45
    # 날: 밑이 넓고 끝으로 갈수록 좁아지는 넓은 칼날
    def hw(v):
        if v < 0.9:
            return 0.17 - 0.035 * (v / 0.9)
        return 0.135 * (1 - ((v - 0.9) / (bl - 0.9)) ** 1.35)
    vs = np.linspace(0.02, bl, 60)
    left = [(-hw(v), v) for v in vs]; right = [(hw(v), v) for v in vs]
    poly('blade', left + right[::-1])
    # 은빛 모서리와 금 안쪽 선
    for sgn in (-1, 1):
        edge = [(sgn * hw(v), v) for v in vs]
        inner = [(sgn * (hw(v) - 0.022), v) for v in vs if v < bl - 0.05]
        poly('bevel', edge + [(sgn * (hw(v) - 0.022), v) for v in vs[::-1]])
        for p, q in zip(inner[:-1], inner[1:]):
            line('trim', p, q, 0.006)
    # 중심 능선(금)과 양옆 청록 상감
    line('ridge', (0.0, 0.10), (0.0, bl - 0.08), 0.016)
    poly('ridge', [(-0.03, 0.06), (0.03, 0.06), (0.0, 0.0)])
    for k in range(6):
        v = 0.22 + k * 0.16
        wv = 0.085 * (1 - 0.12 * k)
        for sgn in (-1, 1):
            poly('inlay', [(sgn * 0.022, v), (sgn * wv, v - 0.07), (sgn * wv, v - 0.045), (sgn * 0.022, v + 0.03)])
    poly('inlay', [(-0.012, 0.14), (-0.012, bl - 0.2), (-0.004, bl - 0.12), (0.004, bl - 0.12), (0.012, bl - 0.2), (0.012, 0.14)], 150)
    # 날밑 위쪽의 금 가시 (불꽃 모양이 아니라 뾰족한 방패 문장 모양)
    poly('goldD', [(-0.19, 0.0), (-0.08, 0.10), (0.0, 0.16), (0.08, 0.10), (0.19, 0.0), (0.0, -0.08)])

    # 깃털 날개: 칼끝 쪽으로 휘어 올라가는 흰 깃털 3겹 + 금 테두리
    def feather(layer, base, length, width, ang0, curve):
        pts_l, pts_r = [], []
        x, y = base
        a_ = ang0
        steps = 16
        for i in range(steps + 1):
            t = i / steps
            wv = width * (math.sin(math.pi * (t ** 0.75)) ** 0.9) + 0.004
            nx, ny = -math.sin(a_), math.cos(a_)     # 진행 방향의 수직
            pts_l.append((x + nx * wv * 0.5, y + ny * wv * 0.5)); pts_r.append((x - nx * wv * 0.5, y - ny * wv * 0.5))
            x += math.cos(a_) * length / steps; y += math.sin(a_) * length / steps
            a_ += curve / steps
        shape = pts_l + pts_r[::-1]
        poly(layer, shape)
        return shape
    gold_outline = []
    for sgn in (-1, 1):
        for i, (ln, wd, a0, cv_) in enumerate(((0.62, 0.15, 0.30, 0.9), (0.52, 0.14, 0.60, 0.8), (0.42, 0.13, 0.95, 0.7))):
            # 각도는 (u 방향, v 방향) 평면에서 u 바깥쪽을 0 으로, v+ (칼끝쪽)으로 올라가며 휜다
            sh = feather('wingW' if i != 1 else 'wingB', (sgn * 0.12, 0.05 + i * 0.015), ln, wd, 0.0, 0.0) if False else None
    # 위 호출은 좌표계를 맞추기 위한 자리 표시이므로, 아래에서 u/v 좌표로 직접 그린다.
    def feather_uv(layer, sgn, base, length, width, ang0, curve):
        pts_l, pts_r = [], []
        u, v = base
        a_ = ang0                                   # 0 = 바깥(±u), +pi/2 = 칼끝쪽(+v)
        steps = 18
        for i in range(steps + 1):
            t = i / steps
            wv = width * (math.sin(math.pi * (t ** 0.7)) ** 0.9) + 0.004
            du, dv = math.cos(a_) * sgn, math.sin(a_)
            nu, nv = -dv * sgn, du * sgn
            pts_l.append((u + nu * wv * 0.5, v + nv * wv * 0.5)); pts_r.append((u - nu * wv * 0.5, v - nv * wv * 0.5))
            u += du * length / steps; v += dv * length / steps
            a_ += curve / steps
        shape = pts_l + pts_r[::-1]
        poly(layer, shape)
        return shape
    outlines = []
    for sgn in (-1, 1):
        for i, (ln, wd, a0, cv_) in enumerate(((0.70, 0.17, -0.05, 1.05), (0.60, 0.16, 0.20, 1.00), (0.50, 0.15, 0.45, 0.95), (0.40, 0.13, 0.70, 0.85))):
            sh = feather_uv('wingB' if i % 2 == 0 else 'wingW', sgn, (sgn * 0.11, 0.03 + 0.02 * i), ln, wd, a0, cv_)
            outlines.append(sh)
    for sh in outlines:
        for p, q in zip(sh, sh[1:] + sh[:1]):
            line('gold', p, q, 0.005)
    # 날밑 중앙: 금 마름모 + 청록 보석
    poly('gold', [(0.0, -0.10), (0.15, 0.04), (0.0, 0.18), (-0.15, 0.04)])
    poly('goldD', [(0.0, -0.06), (0.10, 0.04), (0.0, 0.14), (-0.10, 0.04)])
    poly('gem', [(0.0, -0.02), (0.06, 0.04), (0.0, 0.10), (-0.06, 0.04)])
    # 손잡이: 검은 감개 + 금 고리, 자루머리는 초승달 + 보석
    poly('goldD', [(-0.034, -0.08), (0.034, -0.08), (0.034, -0.38), (-0.034, -0.38)])
    for k in range(5):
        v = -0.12 - k * 0.06
        poly('gold', [(-0.045, v), (0.045, v), (0.045, v - 0.018), (-0.045, v - 0.018)])
    poly('gold', [(-0.12, -0.40), (0.12, -0.40), (0.16, -0.50), (0.0, -0.44), (-0.16, -0.50)])
    poly('gold', [(-0.05, -0.44), (0.05, -0.44), (0.0, -0.60)])
    poly('gem', [(0.0, -0.42), (0.035, -0.46), (0.0, -0.50), (-0.035, -0.46)])

    A = {k: np.asarray(v.resize((n, n), Image.LANCZOS), float) / 255 for k, v in layers.items()}
    x, y = grid(n)
    vproj = (x * st + y * ct)
    vt = np.clip((vproj + 1.0) / 2.0, 0, 1)[..., None]
    rgb = np.zeros((n, n, 3)); alpha = np.zeros((n, n))

    def over(col, a_):
        nonlocal rgb, alpha
        a3 = a_[..., None]
        rgb = rgb * (1 - a3) + np.asarray(col) * a3
        alpha = alpha + a_ * (1 - alpha)

    blade_dark = np.array([0.05, 0.08, 0.11]) + np.array([0.04, 0.10, 0.12]) * (0.5 + 0.5 * np.sin(vproj * 31))[..., None] * 0.6
    over(blade_dark, A['blade'])
    over(np.array([0.82, 0.88, 0.95]) + np.array([0.15, 0.1, 0.05]) * (0.5 + 0.5 * np.sin(vproj * 53))[..., None] * 0.5, A['bevel'])
    over(np.array([0.95, 0.76, 0.28]), A['trim'] * 0.95)
    over(np.array([0.30, 0.95, 0.95]), A['inlay'])
    over(np.array([0.98, 0.82, 0.38]), A['ridge'])
    over(np.array([0.60, 0.66, 0.74]), A['wingB'])
    over(np.array([0.93, 0.96, 1.0]) - 0.10 * (1 - vt), A['wingW'])
    over(np.array([0.72, 0.52, 0.18]), A['goldD'])
    over(np.array([0.98, 0.80, 0.30]) + 0.08 * (0.5 + 0.5 * np.sin(vproj * 41))[..., None], A['gold'])
    over(np.array([0.40, 1.0, 0.98]), A['gem'])
    m = np.clip(alpha, 0, 1)
    cyan_glow = blur(np.clip(A['inlay'] + A['gem'], 0, 1), n * 0.018)[..., None]
    gold_glow = blur(np.clip(A['gold'], 0, 1), n * 0.012)[..., None]
    rgb = rgb + (np.array([0.3, 1.0, 1.0]) - rgb) * cyan_glow * 0.55 * (m[..., None] > 0.5)
    rgb = rgb + (np.array([1.0, 0.85, 0.4]) - rgb) * gold_glow * 0.15 * (m[..., None] > 0.5)
    return to_img(rgb, np.where(m > 0.02, np.clip(m * 1.0, 0, 1), 0))


# ----------------------------------------------------------------- 사슬 / 구체
def chain_link(kind, n=96):
    ss = 4
    S = n * ss
    m = Image.new('L', (S, S), 0)
    d = ImageDraw.Draw(m)
    if kind == 'a':       # 정면: 길쭉한 타원 고리
        d.ellipse([S * 0.22, S * 0.04, S * 0.78, S * 0.96], fill=255)
        d.ellipse([S * 0.36, S * 0.20, S * 0.64, S * 0.80], fill=0)
    else:                 # 측면: 얇은 막대
        d.rounded_rectangle([S * 0.40, S * 0.10, S * 0.60, S * 0.90], radius=S * 0.10, fill=255)
    a = np.asarray(m.resize((n, n), Image.LANCZOS), float) / 255
    x, y = grid(n)
    dark = np.array([0.16, 0.05, 0.07])
    red = np.array([1.0, 0.12, 0.18])
    edge = np.clip(a - blur(a, n * 0.03) * 0.9, 0, 1)
    rim = np.clip(a - np.asarray(Image.fromarray((a * 255).astype(np.uint8)).filter(ImageFilter.MinFilter(5)), float) / 255, 0, 1)
    rgb = dark[None, None, :] * np.ones((n, n, 1)) + (np.array([0.35, 0.12, 0.14]) - dark) * (0.5 + 0.5 * np.sin(y * 9 + x * 3))[..., None] * 0.4
    rgb = rgb + (red - rgb) * np.clip(rim * 1.6, 0, 1)[..., None]
    glow = blur(a, n * 0.05)
    rgb = np.where((a < 0.2)[..., None], red, rgb)
    alpha = np.clip(a + glow * 0.35, 0, 1)
    return to_img(rgb, alpha)


def orb_rim(n=256):
    x, y = grid(n)
    r = np.sqrt(x * x + y * y)
    th = np.arctan2(y, x)
    rim = np.exp(-((r - 0.80) / 0.045) ** 2)
    swirl = (0.5 + 0.5 * np.cos(5 * th - 14 * np.log(r + 0.1))) ** 3 * np.clip((r - 0.35) / 0.5, 0, 1) * np.clip((0.92 - r) / 0.2, 0, 1)
    outer = np.exp(-((r - 0.9) / 0.12) ** 2) * 0.5
    inten = np.clip(rim * 1.3 + swirl * 0.8 + outer, 0, 1)
    col = np.array([0.55, 0.02, 0.10]) + (np.array([1.0, 0.35, 0.22]) - np.array([0.55, 0.02, 0.10])) * inten[..., None]
    col = col + (np.array([1.0, 0.9, 0.7]) - col) * np.clip(rim - 0.5, 0, 1)[..., None]
    return to_img(col, inten * (r < 1.0))


for name, img in (('dawn_slash', dawn_slash()), ('dawn_circle', dawn_circle()), ('giant_sword', giant_sword()),
                  ('chain_a', chain_link('a')), ('chain_b', chain_link('b')), ('orb_rim', orb_rim())):
    img.save(f'{TEX}/{name}.png')
    print('wrote', name)
