"""마비카용 아즈텍 태양석풍 파티클 스프라이트 생성기 (임시 아트). 같은 이름의 PNG로 덮어쓰면 교체됩니다.
  sun_stone  : 하늘에 뜨는 태양석 마법진 (중앙 얼굴, 날짜 기호 띠, 8개 태양 광선)
  sun_glyph  : 땅에 깔리는 작은 태양 문양 (태양기둥 예고/착탄)
  sun_band   : 기둥을 감싸는 계단 무늬(시칼콜리우키) 띠
  fire_slash : 사용자가 준 불꽃 호 이미지(tools/src_fire_slash.png)를 투명 PNG 로 변환
"""
import math, os, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = sys.argv[1] if len(sys.argv) > 1 else '.'
TEX = f'{ROOT}/src/main/resources/assets/elementalgaze/textures/particle'
os.makedirs(TEX, exist_ok=True)
rng = np.random.default_rng(7)

EDGE, MID, CORE = np.array([0.78, 0.20, 0.05]), np.array([1.0, 0.68, 0.18]), np.array([1.0, 0.97, 0.72])

class Canvas:
    def __init__(self, n, ss=4):
        self.n, self.ss = n, ss
        self.s = n * ss
        self.m = Image.new('L', (self.s, self.s), 0)
        self.d = ImageDraw.Draw(self.m)
    def P(self, x, y): return ((x + 1) / 2 * self.s, (y + 1) / 2 * self.s)
    def ring(self, r0, r1, v=255):
        self.d.ellipse([*self.P(-r1, -r1), *self.P(r1, r1)], fill=v)
        self.d.ellipse([*self.P(-r0, -r0), *self.P(r0, r0)], fill=0)
    def disc(self, cx, cy, r, v=255):
        self.d.ellipse([*self.P(cx - r, cy - r), *self.P(cx + r, cy + r)], fill=v)
    def poly(self, pts, v=255): self.d.polygon([self.P(*p) for p in pts], fill=v)
    def rot_rect(self, cx, cy, w, h, ang, v=255):
        c, s = math.cos(ang), math.sin(ang)
        pts = [(cx + (dx * c - dy * s), cy + (dx * s + dy * c)) for dx, dy in ((-w, -h), (w, -h), (w, h), (-w, h))]
        self.poly(pts, v)
    def carve_rect(self, cx, cy, w, h, ang): self.rot_rect(cx, cy, w, h, ang, 0)
    mode = 'palette'   # 'palette' | 'fire'(쨍한 불꽃: 중심 황백 -> 주황 -> 붉은 가장자리) | 'aurora'(청록 -> 파랑 -> 보라 -> 분홍)

    def finish(self):
        n = self.n
        a = np.asarray(self.m.resize((n, n), Image.LANCZOS), float) / 255.0
        glow = np.asarray(Image.fromarray((a * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(n * 0.012)), float) / 255.0
        yy, xx = np.mgrid[0:n, 0:n]
        x = (xx + 0.5) / n * 2 - 1
        y = (yy + 0.5) / n * 2 - 1
        r = np.clip(np.sqrt(x * x + y * y), 0, 1.2)
        if self.mode == 'fire':
            inten = np.clip((a * 0.66 + glow * 0.5) * (1.10 - 0.55 * r), 0, 1)[..., None]
            stops = [(0.0, (0.80, 0.06, 0.02)), (0.45, (1.0, 0.36, 0.03)), (0.75, (1.0, 0.72, 0.10)), (1.0, (1.0, 0.97, 0.60))]
            rgb = np.zeros((n, n, 3))
            for (t0, c0), (t1, c1) in zip(stops[:-1], stops[1:]):
                w = np.clip((inten - t0) / (t1 - t0), 0, 1)
                rgb = np.where(inten >= t0, np.array(c0) + (np.array(c1) - np.array(c0)) * w, rgb)
            alpha = np.clip(np.maximum(a, glow * 0.6) * 1.05, 0, 1)[..., None]
        elif self.mode == 'twotone':   # 청록 <-> 보랏빛이 소용돌이치듯 섞이는 투톤 (벤티)
            th = np.arctan2(y, x)
            t = (0.5 + 0.5 * np.sin(3 * th + 5.0 * r + 0.6))[..., None]
            A, B = np.array([0.10, 0.96, 0.78]), np.array([0.68, 0.46, 1.0])
            col = A + (B - A) * t
            inten = np.clip(a * 0.9 + glow * 0.5, 0, 1)[..., None]
            rgb = col * (1 - 0.3 * inten) + np.array([1.0, 1.0, 1.0]) * 0.3 * inten
            alpha = np.clip(np.maximum(a, glow * 0.55), 0, 1)[..., None]
        elif self.mode == 'aurora':
            th = (np.arctan2(y, x) / (2 * np.pi) + 0.5)
            stops = [(0.0, (0.10, 1.0, 0.65)), (0.25, (0.15, 0.65, 1.0)), (0.5, (0.55, 0.30, 1.0)), (0.75, (1.0, 0.30, 0.85)), (1.0, (0.10, 1.0, 0.65))]
            col = np.zeros((n, n, 3))
            for (t0, c0), (t1, c1) in zip(stops[:-1], stops[1:]):
                w = np.clip((th - t0) / (t1 - t0), 0, 1)[..., None]
                col = np.where(((th >= t0) & (th <= t1))[..., None], np.array(c0) + (np.array(c1) - np.array(c0)) * w, col)
            inten = np.clip(a * 0.9 + glow * 0.5, 0, 1)[..., None]
            rgb = col * (1 - 0.35 * inten) + np.array([1.0, 1.0, 1.0]) * 0.35 * inten    # 밝은 부분은 흰빛으로
            alpha = np.clip(np.maximum(a, glow * 0.55), 0, 1)[..., None]
        else:
            inten = np.clip(a * 0.62 + glow * 0.42, 0, 1)
            t = inten[..., None]
            lo = EDGE + (MID - EDGE) * np.clip(t * 2, 0, 1)
            hi = MID + (CORE - MID) * np.clip(t * 2 - 1, 0, 1)
            rgb = np.where(t < 0.5, lo, hi)
            alpha = np.clip(np.maximum(a, glow * 0.55), 0, 1)[..., None]
        return Image.fromarray((np.concatenate([np.clip(rgb, 0, 1), alpha], -1) * 255).astype(np.uint8), 'RGBA')

def rays(c, r0, r1, k, rot, width, hollow=True):
    for i in range(k):
        a = rot + 2 * math.pi * i / k
        tip = (r1 * math.cos(a), r1 * math.sin(a))
        bl = (r0 * math.cos(a - width), r0 * math.sin(a - width)); br = (r0 * math.cos(a + width), r0 * math.sin(a + width))
        c.poly([tip, bl, br])
        if hollow:   # 안쪽을 파서 새긴 느낌
            tip2 = ((r1 - 0.09) * math.cos(a), (r1 - 0.09) * math.sin(a))
            r2 = r0 + 0.05
            c.poly([tip2, (r2 * math.cos(a - width * 0.55), r2 * math.sin(a - width * 0.55)), (r2 * math.cos(a + width * 0.55), r2 * math.sin(a + width * 0.55))], 0)
            c.poly([((r1 - 0.2) * math.cos(a), (r1 - 0.2) * math.sin(a)),
                    ((r0 + 0.1) * math.cos(a - width * 0.25), (r0 + 0.1) * math.sin(a - width * 0.25)),
                    ((r0 + 0.1) * math.cos(a + width * 0.25), (r0 + 0.1) * math.sin(a + width * 0.25))], 255)

def stair_band(c, r0, r1, k, rot=0.0):
    """계단 무늬(시칼콜리우키): 각 칸이 바깥으로 올라가는 3단 계단"""
    for i in range(k):
        a0 = rot + 2 * math.pi * i / k
        a1 = a0 + 2 * math.pi / k
        for st in range(3):
            ra = r0 + (r1 - r0) * (st + 1) / 3
            rb = r0
            f0 = a0 + (a1 - a0) * st / 3 * 0.7
            f1 = a1 - (a1 - a0) * (2 - st) / 3 * 0.1 - (a1 - a0) * 0.3
            pts = [(rb * math.cos(f0), rb * math.sin(f0)), (ra * math.cos(f0), ra * math.sin(f0)),
                   (ra * math.cos(f1), ra * math.sin(f1)), (rb * math.cos(f1), rb * math.sin(f1))]
            c.poly(pts)

def sun_stone(n=256):
    c = Canvas(n); c.mode = 'fire'
    c.ring(0.955, 0.985); c.ring(0.84, 0.865)          # 바깥 테두리 두 줄
    # 날짜 기호 띠: 20칸, 각 칸에 새긴 사각 문양
    for i in range(20):
        a = 2 * math.pi * (i + 0.5) / 20
        r = 0.76
        cx, cy = r * math.cos(a), r * math.sin(a)
        c.rot_rect(cx, cy, 0.062, 0.062, a, 255)
        c.carve_rect(cx, cy, 0.045, 0.045, a)
        for _ in range(3):
            ox, oy = rng.uniform(-0.03, 0.03), rng.uniform(-0.03, 0.03)
            c.rot_rect(cx + ox * math.cos(a) - oy * math.sin(a), cy + ox * math.sin(a) + oy * math.cos(a), 0.012, 0.012, a, 255)
    c.ring(0.655, 0.675)
    # 8개의 태양 광선 (날카로운 삼각형)
    rays(c, 0.5, 1.0, 8, math.pi / 8, 0.17)
    # 계단 띠 + 옥구슬 고리
    stair_band(c, 0.56, 0.62, 32)
    c.ring(0.40, 0.425)
    for i in range(16):
        a = 2 * math.pi * i / 16
        c.disc(0.485 * math.cos(a), 0.485 * math.sin(a), 0.022)
    # 네 개의 태양(올린) 문양 4개
    for i in range(4):
        a = math.pi / 4 + i * math.pi / 2
        cx, cy = 0.53 * math.cos(a), 0.53 * math.sin(a)
        c.rot_rect(cx, cy, 0.055, 0.055, a, 255); c.carve_rect(cx, cy, 0.036, 0.036, a)
        c.disc(cx, cy, 0.016)
    # 중앙 얼굴 (토나티우)
    c.disc(0, 0, 0.3); c.disc(0, 0, 0.27, 0); c.disc(0, 0, 0.255)
    c.rot_rect(0, -0.215, 0.20, 0.028, 0, 255)                          # 머리띠
    for i in range(5): c.rot_rect(-0.16 + i * 0.08, -0.255, 0.017, 0.032, 0, 255)  # 깃털 장식
    c.disc(-0.285, 0.0, 0.065); c.disc(-0.285, 0.0, 0.04, 0); c.disc(-0.285, 0, 0.018)   # 귀걸이
    c.disc(0.285, 0.0, 0.065); c.disc(0.285, 0.0, 0.04, 0); c.disc(0.285, 0, 0.018)
    for sx in (-1, 1):                                                    # 눈
        c.rot_rect(sx * 0.095, -0.07, 0.052, 0.034, 0, 0)
        c.rot_rect(sx * 0.095, -0.07, 0.036, 0.02, 0, 255)
    c.poly([(0, -0.03), (-0.04, 0.06), (0.04, 0.06)], 0); c.poly([(0, 0.0), (-0.025, 0.055), (0.025, 0.055)], 255)  # 코
    c.rot_rect(0, 0.115, 0.115, 0.03, 0, 0)                               # 입
    for i in range(6): c.rot_rect(-0.088 + i * 0.035, 0.115, 0.012, 0.02, 0, 255)  # 이빨
    c.poly([(-0.045, 0.14), (0.045, 0.14), (0.0, 0.265)], 255)            # 혀(부싯돌 칼)
    c.poly([(-0.022, 0.15), (0.022, 0.15), (0.0, 0.235)], 0)
    return c.finish()

def sun_glyph(n=128):
    c = Canvas(n); c.mode = 'fire'
    c.ring(0.9, 0.975)
    c.ring(0.72, 0.745)
    rays(c, 0.5, 1.0, 8, math.pi / 8, 0.16, hollow=False)
    for i in range(16):
        a = 2 * math.pi * i / 16 + math.pi / 16
        c.disc(0.82 * math.cos(a), 0.82 * math.sin(a), 0.026)
    c.ring(0.36, 0.40)
    c.disc(0, 0, 0.18); c.disc(0, 0, 0.12, 0); c.disc(0, 0, 0.065)
    for i in range(4):   # 올린 십자
        a = i * math.pi / 2 + math.pi / 4
        c.rot_rect(0.27 * math.cos(a), 0.27 * math.sin(a), 0.04, 0.012, a, 255)
    return c.finish()

def sun_band(n=128):
    c = Canvas(n); c.mode = 'fire'
    c.ring(0.93, 0.97); c.ring(0.55, 0.59)
    stair_band(c, 0.63, 0.90, 14)
    return c.finish()

def fire_slash(n=256):
    im = Image.open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'src_fire_slash.png')).convert('RGB')
    a = np.asarray(im, float) / 255.0
    alpha = np.clip(1.0 - a.min(-1), 0, 1) ** 0.85                    # 흰 배경 제거: 흰색 성분을 투명으로
    alpha = np.clip(alpha * 1.25, 0, 1)
    rgb = np.where(alpha[..., None] > 1e-3, (a - (1 - alpha[..., None])) / np.maximum(alpha[..., None], 1e-3), 0)
    rgb = np.clip(rgb, 0, 1)
    out = Image.fromarray((np.concatenate([rgb, alpha[..., None]], -1) * 255).astype(np.uint8), 'RGBA')
    w, h = out.size
    s = max(w, h)
    sq = Image.new('RGBA', (s, s), (0, 0, 0, 0)); sq.paste(out, ((s - w) // 2, (s - h) // 2))
    return sq.resize((n, n), Image.LANCZOS)

for name, fn in (('sun_stone', sun_stone), ('sun_glyph', sun_glyph), ('sun_band', sun_band), ('fire_slash', fire_slash)):
    fn().save(f'{TEX}/{name}.png'); print('wrote', name)
