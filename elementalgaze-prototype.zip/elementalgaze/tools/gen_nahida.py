"""나히다(수메르/지혜의 정원) 파티클 스프라이트 생성기 (임시 아트). 같은 이름 PNG로 덮어쓰면 교체됩니다.
  akasha_ring  : 하늘빛 사슬 문자(육각 고리/연결 기호) 띠 + 금빛 이중 테두리 + 잎 로제트
  akasha_glyph : 땅/씨앗 표식용 작은 문양
  leaf_glow    : 금빛 잎맥이 있는 청록~민트 잎
  vine_curl    : 금빛 덩굴이 말려 올라가며 청록 잎이 달린 곡선
  shell_bubble : 반투명 구체 (적을 감싸는 보호막/씨앗 막)
  arch_panel   : 스테인드글라스 같은 뾰족 아치 창 (성소 외벽 패널)
"""
import math, os, sys
import numpy as np
from PIL import Image, ImageDraw

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = sys.argv[1] if len(sys.argv) > 1 else '.'
TEX = f'{ROOT}/src/main/resources/assets/elementalgaze/textures/particle'
os.makedirs(TEX, exist_ok=True)
src = open(os.path.join(HERE, 'gen_aztec.py'), encoding='utf-8').read()
ns = {'__file__': os.path.join(HERE, 'gen_aztec.py'), '__name__': 'gen_aztec_lib'}
sys.argv = [sys.argv[0], ROOT]
exec(compile(src[:src.index('def sun_stone')], 'gen_aztec_lib', 'exec'), ns)
Canvas = ns['Canvas']
TEAL = (np.array([0.02, 0.55, 0.55]), np.array([0.22, 0.92, 0.78]), np.array([0.50, 1.0, 0.90]))
GOLD = (np.array([0.75, 0.50, 0.05]), np.array([1.0, 0.80, 0.22]), np.array([1.0, 0.92, 0.55]))
MINT = (np.array([0.15, 0.72, 0.42]), np.array([0.45, 0.96, 0.58]), np.array([0.75, 1.0, 0.78]))

def layer(n, pal, fn, ss=4):
    ns['EDGE'], ns['MID'], ns['CORE'] = pal
    c = Canvas(n, ss=ss); fn(c); return c.finish()

def over(*imgs):
    out = imgs[0].copy()
    for im in imgs[1:]: out = Image.alpha_composite(out, im)
    return out

def line(c, a, b, w=0.012, v=255):
    c.d.line([c.P(*a), c.P(*b)], fill=v, width=max(1, int(w * c.s / 2)))

def leaf(c, cx, cy, L, W, ang, v=255):
    pts = []
    for i in range(0, 17):
        t = i / 16
        pts.append((t * L, W * math.sin(math.pi * t) ** 0.8))
    for i in range(16, -1, -1):
        t = i / 16
        pts.append((t * L, -W * math.sin(math.pi * t) ** 0.8))
    ca, sa = math.cos(ang), math.sin(ang)
    c.poly([(cx + x * ca - y * sa, cy + x * sa + y * ca) for x, y in pts], v)

def hexagon(c, cx, cy, r, w=0.018, rot=0.0):
    pts = [(cx + r * math.cos(rot + math.pi / 3 * i), cy + r * math.sin(rot + math.pi / 3 * i)) for i in range(6)]
    for i in range(6): line(c, pts[i], pts[(i + 1) % 6], w)

def glyph_hex(c, cx, cy, s, a):
    """육각 고리 글리프 (이미지의 '⌬' 모양): 바깥 육각 + 양 옆 연결 막대"""
    ca, sa = math.cos(a), math.sin(a)
    def R(x, y): return (cx + x * ca - y * sa, cy + x * sa + y * ca)
    pts = [R(s * math.cos(math.pi / 3 * i + math.pi / 6) * 0.9, s * math.sin(math.pi / 3 * i + math.pi / 6) * 0.9) for i in range(6)]
    for i in range(6): line(c, pts[i], pts[(i + 1) % 6], 0.016)
    inner = [R(s * 0.55 * math.cos(math.pi / 3 * i + math.pi / 6), s * 0.55 * math.sin(math.pi / 3 * i + math.pi / 6)) for i in range(6)]
    for i in range(6): line(c, inner[i], inner[(i + 1) % 6], 0.012)
    line(c, R(-s * 1.3, 0), R(-s * 0.85, 0), 0.014); line(c, R(s * 0.85, 0), R(s * 1.3, 0), 0.014)

def glyph_x(c, cx, cy, s, a):
    """연결 기호(이미지의 '⌘/≍' 모양): 두 막대 + X"""
    ca, sa = math.cos(a), math.sin(a)
    def R(x, y): return (cx + x * ca - y * sa, cy + x * sa + y * ca)
    for y in (-0.55, 0.55): line(c, R(-s * 1.1, y * s), R(s * 1.1, y * s), 0.016)
    line(c, R(-s * 0.7, -0.55 * s), R(s * 0.7, 0.55 * s), 0.016); line(c, R(-s * 0.7, 0.55 * s), R(s * 0.7, -0.55 * s), 0.016)
    line(c, R(-s * 1.1, -0.55 * s), R(-s * 1.1, 0.55 * s), 0.012); line(c, R(s * 1.1, -0.55 * s), R(s * 1.1, 0.55 * s), 0.012)

def akasha_ring(n=256):
    def gold(c):
        c.ring(0.955, 0.985); c.ring(0.915, 0.925); c.ring(0.44, 0.455)
        for i in range(8):                                   # 안쪽 잎 로제트의 금빛 잎맥
            a = 2 * math.pi * i / 8
            line(c, (0.20 * math.cos(a), 0.20 * math.sin(a)), (0.42 * math.cos(a), 0.42 * math.sin(a)), 0.010)
        hexagon(c, 0, 0, 0.14, 0.014)
    def teal(c):
        c.ring(0.795, 0.805); c.ring(0.60, 0.61)
        for i in range(16):                                  # 사슬 문자 띠
            a = 2 * math.pi * i / 16
            r = 0.70
            cx, cy = r * math.cos(a), r * math.sin(a)
            (glyph_hex if i % 2 == 0 else glyph_x)(c, cx, cy, 0.062, a + math.pi / 2)
        for i in range(8):
            a = 2 * math.pi * i / 8 + math.pi / 8
            leaf(c, 0.46 * math.cos(a), 0.46 * math.sin(a), 0.0, 0.0, a, 0)
        for i in range(8):                                   # 중앙 잎 로제트 (채움)
            a = 2 * math.pi * i / 8
            leaf(c, 0.05 * math.cos(a), 0.05 * math.sin(a), 0.36, 0.07, a)
    return over(layer(n, TEAL, teal), layer(n, GOLD, gold))

def akasha_glyph(n=128):
    def gold(c):
        c.ring(0.88, 0.97); c.ring(0.62, 0.64); hexagon(c, 0, 0, 0.30, 0.03)
    def teal(c):
        for i in range(6):
            a = 2 * math.pi * i / 6
            leaf(c, 0.30 * math.cos(a), 0.30 * math.sin(a), 0.50, 0.12, a)
        c.disc(0, 0, 0.12)
    return over(layer(n, TEAL, teal), layer(n, GOLD, gold))

def leaf_glow(n=64):
    def teal(c): leaf(c, -0.85, 0.0, 1.7, 0.42, 0.0)
    def gold(c):
        line(c, (-0.85, 0.0), (0.8, 0.0), 0.06)
        for t in (-0.45, -0.1, 0.25):
            line(c, (t, 0), (t + 0.25, -0.2), 0.035); line(c, (t, 0), (t + 0.25, 0.2), 0.035)
    return over(layer(n, MINT, teal, 6), layer(n, GOLD, gold, 6))

def vine_curl(n=128):
    pts = []
    for i in range(60):
        t = i / 59
        r = 0.78 - 0.62 * t
        a = 3.3 * math.pi * t - math.pi * 0.2
        pts.append((r * math.cos(a), r * math.sin(a), a))
    def gold(c):
        for p, q in zip(pts[:-1], pts[1:]): line(c, p[:2], q[:2], 0.035 * (1.2 - 0.0))
    def teal(c):
        for i in range(6, 58, 8):
            x, y, a = pts[i]
            leaf(c, x, y, 0.22, 0.065, a + math.pi / 2 + 0.3)
            leaf(c, x, y, 0.16, 0.05, a - math.pi / 2 - 0.2)
    return over(layer(n, TEAL, teal), layer(n, GOLD, gold))

def shell_bubble(n=128):
    yy, xx = np.mgrid[0:n, 0:n]
    x = (xx + 0.5) / n * 2 - 1; y = (yy + 0.5) / n * 2 - 1
    r = np.sqrt(x * x + y * y)
    rim = np.exp(-((r - 0.93) / 0.05) ** 2)
    fill = np.clip(1 - r * r, 0, 1) * 0.10 + np.clip(r - 0.5, 0, 1) * (r < 0.95) * 0.12
    hl = np.exp(-(((x + 0.45) ** 2 + (y + 0.5) ** 2) ** 0.5 - 0.0) ** 2 / 0.05) * 0.5
    arc = np.exp(-((np.sqrt((x + 0.1) ** 2 + (y + 0.1) ** 2) - 0.78) / 0.04) ** 2) * (x + y < -0.6)
    a = np.clip(rim * 0.9 + fill + hl * 0.4, 0, 1) * (r < 1.0)
    t = np.clip(a * 1.3, 0, 1)[..., None]
    col = np.array([0.30, 0.95, 0.80]) * (1 - t) + np.array([0.95, 1.0, 0.98]) * t
    return Image.fromarray((np.concatenate([col, a[..., None]], -1) * 255).astype(np.uint8), 'RGBA')

def arch_pts():
    left = [(0.2 - math.cos(math.radians(th)) * 1.0 * -1 * -1, 0.15 - math.sin(math.radians(th)) * 1.0) for th in np.linspace(180, 101.5, 24)]
    left = [(0.2 + math.cos(math.radians(th)), 0.15 - math.sin(math.radians(th))) for th in np.linspace(180, 101.5, 24)]
    right = [(-x, y) for x, y in reversed(left)]
    return [(-0.8, 0.95)] + left + right + [(0.8, 0.95)]

def arch_panel(n=256):
    pts = arch_pts()
    def fill(c):
        c.poly(pts, 70)
    def gold(c):
        for p, q in zip(pts[:-1], pts[1:]): line(c, p, q, 0.05)
        line(c, pts[-1], pts[0], 0.05)
        inner = [(x * 0.84, (y - 0.15) * 0.86 + 0.20) for x, y in pts]
        for p, q in zip(inner[:-1], inner[1:]): line(c, p, q, 0.022)
        line(c, (-0.8, 0.93), (0.8, 0.93), 0.05)
    def top(x): return 0.15 - math.sqrt(max(0.0, 1 - (abs(x) + 0.2) ** 2))
    def teal(c):
        for mx in (-0.42, 0.0, 0.42): line(c, (mx, 0.9), (mx, top(mx) + 0.06), 0.022)
        line(c, (-0.76, 0.5), (0.76, 0.5), 0.02); line(c, (-0.78, 0.05), (0.78, 0.05), 0.02)
        for cx in (-0.21, 0.21): leaf(c, cx, 0.45, -0.8, 0.09, -math.pi / 2)
        for cx in (-0.6, 0.6): leaf(c, cx, 0.45, -0.45, 0.07, -math.pi / 2)
    return over(layer(n, MINT, fill), layer(n, TEAL, teal), layer(n, GOLD, gold))

for name, fn in (('akasha_ring', akasha_ring), ('akasha_glyph', akasha_glyph), ('leaf_glow', leaf_glow),
                 ('vine_curl', vine_curl), ('shell_bubble', shell_bubble), ('arch_panel', arch_panel)):
    fn().save(f'{TEX}/{name}.png'); print('wrote', name)
