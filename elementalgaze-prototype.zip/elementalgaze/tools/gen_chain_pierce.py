"""파이논 Q: 바닥에 꽂히는 가시 사슬 스프라이트 (chain_pierce.png, 128x1280).
아래쪽 끝이 창끝처럼 뾰족하고, 위쪽은 하늘 속으로 사라진다. 검은 금속 + 붉은 테두리 광."""
import math, os, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = sys.argv[1] if len(sys.argv) > 1 else '.'
OUT = f'{ROOT}/src/main/resources/assets/elementalgaze/textures/particle/chain_pierce.png'
W, H, SS = 128, 1280, 4
S = SS


def draw():
    m = Image.new('L', (W * S, H * S), 0)       # 금속 마스크
    hl = Image.new('L', (W * S, H * S), 0)      # 하이라이트
    d, dh = ImageDraw.Draw(m), ImageDraw.Draw(hl)
    cx = W * S / 2
    # 창끝 (맨 아래)
    tip_h, blade_w = 230, 34
    y_tip = H * S - 4
    y_col = y_tip - tip_h * S
    d.polygon([(cx, y_tip), (cx - blade_w * S, y_tip - 150 * S), (cx - 12 * S, y_col), (cx + 12 * S, y_col), (cx + blade_w * S, y_tip - 150 * S)], fill=255)
    dh.polygon([(cx, y_tip), (cx - 5 * S, y_tip - 150 * S), (cx - 3 * S, y_col), (cx + 1 * S, y_col)], fill=255)
    for k in range(3):                           # 창끝 아래쪽 가시 날개
        yy = y_col + (22 + k * 34) * S
        d.polygon([(cx - 14 * S, yy), (cx - (30 + 10 * k) * S, yy - 26 * S), (cx - 12 * S, yy - 12 * S)], fill=255)
        d.polygon([(cx + 14 * S, yy), (cx + (30 + 10 * k) * S, yy - 26 * S), (cx + 12 * S, yy - 12 * S)], fill=255)
    # 사슬: 정면 고리 / 옆면 고리 번갈아
    link_h, step = 96, 70
    y = y_col + 6 * S
    i = 0
    while y > -link_h * S:
        top = y - link_h * S
        if i % 2 == 0:
            ow, iw = 22 * S, 11 * S
            d.rounded_rectangle([cx - ow, top, cx + ow, y], radius=ow, fill=255)
            d.rounded_rectangle([cx - iw, top + 12 * S, cx + iw, y - 12 * S], radius=iw, fill=0)
            dh.arc([cx - ow, top, cx + ow, y], 200, 300, fill=255, width=3 * S)
            # 가시: 고리 좌우로 뾰족하게
            for sgn in (-1, 1):
                ym = (top + y) / 2
                d.polygon([(cx + sgn * (ow - 4 * S), ym - 12 * S), (cx + sgn * (ow + 16 * S), ym), (cx + sgn * (ow - 4 * S), ym + 12 * S)], fill=255)
        else:
            ow = 9 * S
            d.rounded_rectangle([cx - ow, top, cx + ow, y], radius=ow, fill=255)
            dh.line([(cx - 3 * S, top + 8 * S), (cx - 3 * S, y - 8 * S)], fill=255, width=2 * S)
            for sgn in (-1, 1):
                ym = (top + y) / 2
                d.polygon([(cx + sgn * (ow - 2 * S), ym - 9 * S), (cx + sgn * (ow + 10 * S), ym - 20 * S), (cx + sgn * (ow - 2 * S), ym + 2 * S)], fill=255)
        y -= step * S
        i += 1
    m = m.resize((W, H), Image.LANCZOS)
    hl = hl.resize((W, H), Image.LANCZOS)
    return m, hl


def main():
    m, hl = draw()
    M = np.asarray(m, float) / 255
    Hh = np.asarray(hl, float) / 255
    yy = np.linspace(0, 1, H)[:, None] * np.ones((1, W))
    xx = np.ones((H, 1)) * np.linspace(-1, 1, W)[None, :]
    # 금속 색: 검정 -> 어두운 선홍, 가장자리 쪽은 밝은 붉은 테두리
    inner = np.asarray(m.filter(ImageFilter.MinFilter(5)).filter(ImageFilter.GaussianBlur(1.5)), float) / 255
    rim = np.clip(M - inner, 0, 1)
    shade = np.clip(0.5 + 0.5 * (-xx) * 1.2, 0, 1) * 0.35
    col = np.stack([0.06 + shade * 0.5, 0.01 + shade * 0.05, 0.025 + shade * 0.08], -1)
    col = col + (np.array([1.0, 0.18, 0.24]) - col) * np.clip(rim * 1.3, 0, 0.85)[..., None]
    col = col + (np.array([1.0, 0.78, 0.7]) - col) * (Hh * 0.7)[..., None]
    # 창끝은 조금 더 밝게 번쩍
    tipm = np.clip((yy - 0.84) / 0.16, 0, 1)
    col = col + (np.array([0.5, 0.08, 0.1]) - col) * (tipm * 0.25)[..., None]
    # 위쪽은 하늘로 사라진다
    fade = np.clip(yy / 0.22, 0, 1) ** 1.2
    a = np.clip(M, 0, 1) * fade
    base = Image.fromarray((np.dstack([np.clip(col, 0, 1), a]) * 255).astype(np.uint8), 'RGBA')
    glow = Image.fromarray((np.dstack([np.ones((H, W)) * 1.0, np.ones((H, W)) * 0.10, np.ones((H, W)) * 0.16,
                                       np.clip(np.asarray(m.filter(ImageFilter.GaussianBlur(7)), float) / 255 * 0.85, 0, 1) * fade]) * 255).astype(np.uint8), 'RGBA')
    out = Image.alpha_composite(glow, base)
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    out.save(OUT)
    print('wrote', OUT)


main()
