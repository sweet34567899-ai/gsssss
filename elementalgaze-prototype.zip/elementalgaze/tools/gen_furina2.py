"""푸리나 Q 연출용 스프라이트 생성기 (2차). 같은 이름 PNG로 덮어쓰면 교체됩니다.
  whale_swim   : 사용자가 준 수채 고래 사진(체크무늬 가짜 배경)을 투명 PNG 로 변환. 몸이 수평이고 머리가 오른쪽(+x), 512x256.
                 textures/entity/whale_swim.png (파티클이 아니라 3D 메시에 입혀 헤엄치는 물결 변형 애니메이션을 준다)
  libra_circle : 천칭이 그려진 물 원소 마법진 (particle 아틀라스)
  flood_wave   : 범람하는 물결 고리 (거품 테두리, 안쪽으로 흐르는 물줄기)
"""
import math, os, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter
from scipy import ndimage as ndi

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = sys.argv[1] if len(sys.argv) > 1 else '.'
TEX = f'{ROOT}/src/main/resources/assets/elementalgaze/textures/particle'
ENT = f'{ROOT}/src/main/resources/assets/elementalgaze/textures/entity'
os.makedirs(TEX, exist_ok=True); os.makedirs(ENT, exist_ok=True)


def grid(n):
    yy, xx = np.mgrid[0:n, 0:n]
    return (xx + 0.5) / n * 2 - 1, (yy + 0.5) / n * 2 - 1


def blur(a, r):
    return ndi.gaussian_filter(np.clip(a, 0, 1), r)


def smooth(e0, e1, v):
    t = np.clip((v - e0) / (e1 - e0), 0, 1)
    return t * t * (3 - 2 * t)


def to_img(rgb, alpha):
    return Image.fromarray((np.concatenate([np.clip(rgb, 0, 1), np.clip(alpha, 0, 1)[..., None]], -1) * 255).astype(np.uint8), 'RGBA')


# ------------------------------------------------------------------ 고래
def whale_swim():
    src = Image.open(os.path.join(HERE, 'src_whale.png')).convert('RGB')
    a = np.asarray(src).astype(float)
    mask = (a[..., 2] - a[..., 0]) > 14
    mask = ndi.binary_closing(mask, iterations=4)
    mask = ndi.binary_fill_holes(mask)
    mask = ndi.binary_opening(mask, iterations=2)
    lab, cnt = ndi.label(mask)
    sizes = ndi.sum(mask, lab, range(1, cnt + 1))
    mask = lab == (1 + int(np.argmax(sizes)))
    alpha = ndi.gaussian_filter(mask.astype(float), 1.1)
    ys, xs = np.nonzero(mask)
    pts = np.stack([xs - xs.mean(), ys - ys.mean()], 1)
    w, v = np.linalg.eigh(np.cov(pts.T))
    ax = v[:, 1]
    if ax[0] < 0:
        ax = -ax
    ang = math.degrees(math.atan2(ax[1], ax[0]))        # 몸 축이 x 축에서 기운 각도 (y 아래가 +)
    rgb = np.clip(a / 255 * 1.10 + 0.04, 0, 1)
    rgb = rgb + (np.array([0.55, 0.85, 1.0]) - rgb) * 0.10     # 살짝 푸른 빛
    img = Image.fromarray((np.concatenate([rgb, alpha[..., None]], -1) * 255).astype(np.uint8), 'RGBA')
    img = img.rotate(ang, resample=Image.BICUBIC, expand=True)
    bb = img.getchannel('A').point(lambda x: 255 if x > 25 else 0).getbbox()
    img = img.crop(bb)
    img = img.transpose(Image.FLIP_LEFT_RIGHT)           # 원본은 머리가 왼쪽이므로 좌우를 뒤집어 머리가 오른쪽(+x)이 되게 한다
    W, H = 512, 256
    sc = min(W / img.width, H / img.height) * 0.97
    img = img.resize((max(1, int(img.width * sc)), max(1, int(img.height * sc))), Image.LANCZOS)
    out = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    out.paste(img, ((W - img.width) // 2, (H - img.height) // 2), img)
    return out


# ------------------------------------------------------------------ 천칭 마법진
def libra_circle(n=512):
    ss = 3
    S = n * ss
    blue = Image.new('L', (S, S), 0); white = Image.new('L', (S, S), 0); cyan = Image.new('L', (S, S), 0)
    B, Wh, C = ImageDraw.Draw(blue), ImageDraw.Draw(white), ImageDraw.Draw(cyan)

    def P(x, y):
        return ((x + 1) / 2 * S, (y + 1) / 2 * S)

    def ring(D, r0, r1, v=255):
        D.ellipse([*P(-r1, -r1), *P(r1, r1)], fill=v)
        D.ellipse([*P(-r0, -r0), *P(r0, r0)], fill=0)

    def line(D, a, b, w, v=255):
        D.line([P(*a), P(*b)], fill=v, width=max(1, int(w * S / 2)))

    def poly(D, pts, v=255):
        D.polygon([P(*p) for p in pts], fill=v)

    def pol(r, t):
        return (r * math.cos(t), r * math.sin(t))

    def arc_pts(cx, cy, rx, ry, a0, a1, k=30):
        return [(cx + rx * math.cos(math.radians(a0 + (a1 - a0) * i / k)), cy + ry * math.sin(math.radians(a0 + (a1 - a0) * i / k))) for i in range(k + 1)]

    def polyline(D, pts, w, v=255):
        for p, q in zip(pts[:-1], pts[1:]):
            line(D, p, q, w, v)
            r = max(1, int(w * S / 4))
            x, y = P(*q)
            D.ellipse([x - r, y - r, x + r, y + r], fill=v)

    # 바깥 이중 고리와 눈금
    ring(C, 0.965, 0.990); ring(C, 0.925, 0.935, 200)
    for i in range(120):
        t = 2 * math.pi * i / 120
        line(C, pol(0.94 if i % 5 else 0.93, t), pol(0.962, t), 0.004 if i % 5 else 0.008)
    # 파도 띠: 사인 곡선 두 줄
    for ph, w, v in ((0.0, 0.008, 255), (math.pi, 0.006, 200)):
        pts = [pol(0.865 + 0.024 * math.sin(26 * t + ph), t) for t in np.linspace(0, 2 * math.pi, 600)]
        polyline(B, pts, w, v)
    ring(C, 0.835, 0.842, 180); ring(C, 0.895, 0.90, 180)
    # 물방울 12개 (안쪽을 향한 눈물 모양)
    for i in range(12):
        t = 2 * math.pi * i / 12 + math.pi / 12
        base = pol(0.79, t); tip = pol(0.70, t)
        nx, ny = -math.sin(t), math.cos(t)
        pts = [tip]
        for k in range(1, 12):
            u = k / 11
            r = 0.035 * math.sin(math.pi * u ** 0.8)
            c = (tip[0] + (base[0] - tip[0]) * u, tip[1] + (base[1] - tip[1]) * u)
            pts.append((c[0] + nx * r, c[1] + ny * r))
        for k in range(11, 0, -1):
            u = k / 11
            r = 0.035 * math.sin(math.pi * u ** 0.8)
            c = (tip[0] + (base[0] - tip[0]) * u, tip[1] + (base[1] - tip[1]) * u)
            pts.append((c[0] - nx * r, c[1] - ny * r))
        poly(Wh, pts, 230)
    # 네 방향의 별
    for i in range(4):
        t = 2 * math.pi * i / 4
        c = pol(0.945, t)
    for i in range(4):
        t = 2 * math.pi * i / 4 + math.pi / 4
        c0 = pol(0.60, t)
        pts = []
        for k in range(8):
            rr = 0.07 if k % 2 == 0 else 0.022
            tt = t + k * math.pi / 4
            pts.append((c0[0] + rr * math.cos(tt), c0[1] + rr * math.sin(tt)))
        poly(Wh, pts, 220)
    ring(B, 0.700, 0.708); ring(B, 0.655, 0.662, 200); ring(C, 0.60, 0.605, 150)
    # 가운데 천칭
    top = (0.0, -0.40)
    line(Wh, (0.0, 0.46), (0.0, -0.32), 0.026)                           # 기둥
    poly(Wh, [(-0.20, 0.50), (0.20, 0.50), (0.12, 0.43), (-0.12, 0.43)])       # 받침
    polyline(Wh, arc_pts(0, 0.40, 0.30, 0.10, 0, 180), 0.016)
    poly(Wh, [(0.0, -0.50), (0.035, -0.43), (0.0, -0.36), (-0.035, -0.43)])    # 윗장식 마름모
    Wh.ellipse([*P(-0.045, -0.365), *P(0.045, -0.275)], fill=255)
    beam = [(-0.48 + 0.96 * i / 40, -0.22 - 0.07 * math.sin(math.pi * i / 40)) for i in range(41)]
    polyline(Wh, beam, 0.020)                                              # 저울대
    for sx in (-1, 1):
        ex, ey = sx * 0.48, -0.22
        Wh.ellipse([*P(ex - 0.03, ey - 0.03), *P(ex + 0.03, ey + 0.03)], fill=255)
        py = 0.14
        line(Wh, (ex, ey), (ex - 0.17, py), 0.007, 230); line(Wh, (ex, ey), (ex + 0.17, py), 0.007, 230); line(Wh, (ex, ey), (ex, py), 0.005, 180)
        polyline(Wh, arc_pts(ex, py, 0.17, 0.08, 0, 180, 24), 0.014)             # 접시
        line(Wh, (ex - 0.17, py), (ex + 0.17, py), 0.010)
        poly(C, [(ex, py - 0.045), (ex + 0.022, py - 0.01), (ex, py + 0.0), (ex - 0.022, py - 0.01)], 220)   # 접시 위의 물방울
    # 저울 주변 소용돌이 물결
    for i in range(6):
        t0 = i * math.pi / 3
        pts = [pol(0.54 - 0.12 * k / 24, t0 + 1.5 * k / 24) for k in range(25)]
        polyline(C, pts, 0.006, 190)
    A_b = np.asarray(blue.resize((n, n), Image.LANCZOS), float) / 255
    A_w = np.asarray(white.resize((n, n), Image.LANCZOS), float) / 255
    A_c = np.asarray(cyan.resize((n, n), Image.LANCZOS), float) / 255
    x, y = grid(n)
    r = np.sqrt(x * x + y * y); th = np.arctan2(y, x)
    m = np.clip(np.maximum.reduce([A_b, A_w, A_c]), 0, 1)
    g1, g2 = blur(m, n * 0.010), blur(m, n * 0.04)
    deep = np.array([0.10, 0.36, 0.98]); cy_ = np.array([0.38, 0.88, 1.0]); wh_ = np.array([0.93, 0.99, 1.0]); vi = np.array([0.62, 0.55, 1.0])
    col = deep * (A_b[..., None]) + cy_ * (A_c[..., None]) + wh_ * (A_w[..., None])
    wsum = (A_b + A_c + A_w)[..., None]
    col = col / np.maximum(wsum, 1e-3)
    ph = (0.5 + 0.5 * np.sin(th * 3 + r * 5))[..., None]
    col = col + (vi - col) * ph * np.clip(g1 - m, 0, 1)[..., None] * 0.6
    col = col + (np.array([0.5, 0.95, 1.0]) - col) * np.clip(g2, 0, 1)[..., None] * 0.35
    rgb = np.where((m > 0.02)[..., None], col, np.array([0.30, 0.70, 1.0]))
    alpha = np.clip(m + g1 * 0.55 + g2 * 0.30, 0, 1)
    return to_img(rgb, alpha)


# ------------------------------------------------------------------ 범람 물결
def flood_wave(n=512):
    rng = np.random.default_rng(13)
    p = rng.uniform(0, 6.28, 8)
    x, y = grid(n)
    r = np.sqrt(x * x + y * y); th = np.arctan2(y, x)
    R = 0.80 + 0.035 * np.sin(7 * th + p[0]) + 0.025 * np.sin(13 * th + p[1]) + 0.015 * np.sin(23 * th + p[2])
    T = 0.13 + 0.04 * np.sin(5 * th + p[3])
    d = (r - R) / T                                      # 바깥쪽이 +
    crest = np.exp(-((d - 0.15) / 0.55) ** 2)             # 물마루
    # 거품: 바깥 가장자리 근처의 불규칙한 흰 점/줄
    n1 = ndi.gaussian_filter(rng.normal(size=(n, n)), 1.6); n1 = (n1 - n1.min()) / (n1.max() - n1.min())
    foam = np.clip((n1 - 0.45) * 3.0, 0, 1) * np.exp(-((d - 0.55) / 0.45) ** 2) + np.exp(-((d - 0.80) / 0.14) ** 2) * 0.8
    # 안쪽으로 흐르는 물줄기: 방사형 줄무늬, 중심으로 갈수록 옅다
    streak = (0.5 + 0.5 * np.sin(48 * th + 4 * np.sin(5 * th + p[4]) + r * 8)) ** 3
    inner = np.clip((R - r) / R, 0, 1) ** 0.6 * np.clip(r / 0.25, 0, 1) * streak * 0.55 * (d < 0.2)
    body = np.clip(crest * 0.95 + inner, 0, 1)
    deep = np.array([0.08, 0.40, 0.95]); mid = np.array([0.32, 0.86, 1.0]); wh = np.array([1.0, 1.0, 1.0])
    t = np.clip(crest + inner * 0.6, 0, 1)[..., None]
    col = deep + (mid - deep) * t
    f = np.clip(foam, 0, 1)[..., None]
    col = col + (wh - col) * f * 0.9
    alpha = np.clip(body * 0.9 + foam * 0.8, 0, 1) * (1 - smooth(0.96, 1.0, r))
    g = blur(alpha, n * 0.01)
    alpha = np.clip(np.maximum(alpha, g * 0.5), 0, 1)
    return to_img(col, alpha)


for name, img, d in (('whale_swim', whale_swim(), ENT), ('libra_circle', libra_circle(), TEX), ('flood_wave', flood_wave(), TEX)):
    img.save(f'{d}/{name}.png')
    print('wrote', name, img.size)
