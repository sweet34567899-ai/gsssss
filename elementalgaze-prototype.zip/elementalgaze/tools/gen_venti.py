"""벤티용 스프라이트 생성기 (임시 아트). 같은 이름 PNG로 덮어쓰면 교체됩니다.
  music_circle : 오선(5줄 고리)과 음표, 리라, 바람 소용돌이가 새겨진 투톤(청록 <-> 보라) 마법진
  vortex_disc  : 중심으로 빨려드는 나선 팔 원반 (블랙홀 강착원반 / 바닥 소용돌이)
  note_a/b/c   : 음표(8분 / 이음 8분 / 4분) - 흰색, 실행 중에 청록/보라로 색을 입힌다
"""
import math, os, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = sys.argv[1] if len(sys.argv) > 1 else '.'
TEX = f'{ROOT}/src/main/resources/assets/elementalgaze/textures/particle'
os.makedirs(TEX, exist_ok=True)
src = open(os.path.join(HERE, 'gen_aztec.py'), encoding='utf-8').read()
ns = {'__file__': os.path.join(HERE, 'gen_aztec.py'), '__name__': 'gen_aztec_lib'}
sys.argv = [sys.argv[0], ROOT]
exec(compile(src[:src.index('def sun_stone')], 'gen_aztec_lib', 'exec'), ns)
Canvas = ns['Canvas']

def line(c, a, b, w=0.012):
    c.d.line([c.P(*a), c.P(*b)], fill=255, width=max(1, int(w * c.s / 2)))

def head(c, cx, cy, rx, ry, tilt=-0.35):
    pts = []
    for i in range(24):
        a = 2 * math.pi * i / 24
        x, y = rx * math.cos(a), ry * math.sin(a)
        pts.append((cx + x * math.cos(tilt) - y * math.sin(tilt), cy + x * math.sin(tilt) + y * math.cos(tilt)))
    c.poly(pts)

def eighth(c, cx, cy, s, flag=True, stem_up=True):
    head(c, cx, cy, 0.20 * s, 0.14 * s)
    sx = cx + 0.18 * s
    line(c, (sx, cy), (sx, cy - 0.85 * s), 0.05 * s)
    if flag:
        c.poly([(sx, cy - 0.85 * s), (sx + 0.34 * s, cy - 0.62 * s), (sx + 0.30 * s, cy - 0.32 * s), (sx + 0.14 * s, cy - 0.5 * s), (sx, cy - 0.46 * s)])

def beamed(c, cx, cy, s):
    x1, x2 = cx - 0.32 * s, cx + 0.32 * s
    head(c, x1, cy + 0.12 * s, 0.17 * s, 0.12 * s); head(c, x2, cy - 0.02 * s, 0.17 * s, 0.12 * s)
    line(c, (x1 + 0.15 * s, cy + 0.12 * s), (x1 + 0.15 * s, cy - 0.78 * s), 0.045 * s)
    line(c, (x2 + 0.15 * s, cy - 0.02 * s), (x2 + 0.15 * s, cy - 0.92 * s), 0.045 * s)
    c.poly([(x1 + 0.13 * s, cy - 0.78 * s), (x2 + 0.17 * s, cy - 0.94 * s), (x2 + 0.17 * s, cy - 0.74 * s), (x1 + 0.13 * s, cy - 0.58 * s)])

def quarter(c, cx, cy, s):
    head(c, cx, cy, 0.22 * s, 0.15 * s)
    line(c, (cx + 0.2 * s, cy), (cx + 0.2 * s, cy - 0.9 * s), 0.055 * s)

def note_sprite(kind, n=64):
    c = Canvas(n, ss=6)
    if kind == 'a': eighth(c, -0.12, 0.45, 0.95)
    elif kind == 'b': beamed(c, 0.0, 0.5, 0.95)
    else: quarter(c, -0.1, 0.5, 0.95)
    ns['EDGE'], ns['MID'], ns['CORE'] = np.array([0.75, 0.88, 1.0]), np.array([0.92, 0.97, 1.0]), np.array([1.0, 1.0, 1.0])
    return c.finish()

def music_circle(n=256):
    c = Canvas(n); c.mode = 'twotone'
    c.ring(0.955, 0.985); c.ring(0.89, 0.90)
    for i in range(60):                                       # 눈금
        a = 2 * math.pi * i / 60
        r0, r1 = (0.915, 0.95) if i % 5 == 0 else (0.93, 0.95)
        line(c, (r0 * math.cos(a), r0 * math.sin(a)), (r1 * math.cos(a), r1 * math.sin(a)), 0.007)
    for k in range(5):                                         # 오선: 5줄 고리
        r = 0.60 + k * 0.045
        c.ring(r - 0.004, r + 0.004)
    rng = np.random.default_rng(4)
    for i in range(12):                                        # 오선 위에 놓인 음표들
        a = 2 * math.pi * i / 12 + 0.1
        r = 0.60 + rng.integers(0, 5) * 0.045 + 0.02
        cx, cy = r * math.cos(a), r * math.sin(a)
        if i % 3 == 0: beamed(c, cx, cy, 0.20)
        elif i % 3 == 1: eighth(c, cx, cy, 0.18)
        else: quarter(c, cx, cy, 0.18)
    for i in range(4):                                         # 바람 소용돌이 팔 4개 (오선과 중심 사이)
        a0 = i * math.pi / 2
        pts = []
        for j in range(20):
            t = j / 19
            r = 0.52 - 0.30 * t
            a = a0 + 2.2 * t
            pts.append((r * math.cos(a), r * math.sin(a)))
        for p, q in zip(pts[:-1], pts[1:]): line(c, p, q, 0.014)
    c.ring(0.16, 0.18)
    # 리라 (중앙)
    lyre = [(-0.09 + 0.0, 0.10)]
    for t in np.linspace(0, math.pi, 16):
        pass
    left = [(-0.11 - 0.025 * math.sin(t), 0.10 - 0.20 * t / math.pi) for t in np.linspace(0, math.pi, 12)]
    right = [(0.11 + 0.025 * math.sin(t), 0.10 - 0.20 * t / math.pi) for t in np.linspace(0, math.pi, 12)]
    for p, q in zip(left[:-1], left[1:]): line(c, p, q, 0.016)
    for p, q in zip(right[:-1], right[1:]): line(c, p, q, 0.016)
    line(c, (-0.11, 0.10), (0.11, 0.10), 0.014)
    line(c, (-0.09, -0.10), (0.09, -0.10), 0.016)
    for k in range(-3, 4): line(c, (k * 0.03, 0.10), (k * 0.03, -0.10), 0.006)
    return c.finish()

def vortex_disc(n=256):
    yy, xx = np.mgrid[0:n, 0:n]
    x = (xx + 0.5) / n * 2 - 1
    y = (yy + 0.5) / n * 2 - 1
    r = np.sqrt(x * x + y * y)
    th = np.arctan2(y, x)
    phase = 3 * th - 11.0 * np.log(r + 0.07)
    arms = (0.5 + 0.5 * np.cos(phase)) ** 2.4
    fade = np.clip(1 - r, 0, 1) ** 0.8
    hole = np.clip((r - 0.07) / 0.10, 0, 1)                   # 중심은 비워서 어둡게
    ring = np.exp(-((r - 0.13) / 0.045) ** 2)                  # 강착원반 밝은 고리
    inten = np.clip(arms * fade * hole * 1.1 + ring * 1.2, 0, 1)
    t = (0.5 + 0.5 * np.sin(3 * th + 5.0 * r + 0.6))[..., None]
    A, B = np.array([0.10, 0.96, 0.78]), np.array([0.68, 0.46, 1.0])
    col = A + (B - A) * t
    col = col * (1 - 0.45 * inten[..., None]) + 0.45 * inten[..., None]
    alpha = np.clip(inten, 0, 1)[..., None]
    return Image.fromarray((np.concatenate([col, alpha], -1) * 255).astype(np.uint8), 'RGBA')

for name, img in (('music_circle', music_circle()), ('vortex_disc', vortex_disc()),
                  ('note_a', note_sprite('a')), ('note_b', note_sprite('b')), ('note_c', note_sprite('c'))):
    img.save(f'{TEX}/{name}.png'); print('wrote', name)
