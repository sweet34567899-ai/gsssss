package com.example.elementalgaze;

import com.google.common.base.Suppliers;
import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import java.util.Set;
import java.util.function.Supplier;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;
import org.jetbrains.annotations.NotNull;

/**
 * 모든 구조물 상자(chests/...)에 낮은 확률로 집정관의 흔적(원소 무작위)과 재발현 증표를 추가한다.
 * 던전, 광산, 요새, 사원, 고대 도시, 엔드 시티 등 고급 상자는 확률이 더 높다. 확률은 서버 config 에서 바꾼다.
 */
public class ChestLootModifier extends LootModifier {
    public static final Supplier<Codec<ChestLootModifier>> CODEC =
            Suppliers.memoize(() -> RecordCodecBuilder.create(inst -> codecStart(inst).apply(inst, ChestLootModifier::new)));

    private static final Set<String> RICH = Set.of("simple_dungeon", "abandoned_mineshaft", "stronghold_library", "stronghold_corridor",
            "stronghold_crossing", "woodland_mansion", "jungle_temple", "desert_pyramid", "buried_treasure", "ancient_city",
            "ancient_city_ice_box", "bastion_treasure", "bastion_hoglin_stable", "bastion_other", "bastion_bridge", "end_city_treasure",
            "nether_bridge", "underwater_ruin_big", "shipwreck_treasure", "ruined_portal", "pillager_outpost", "trail_ruins_rare");

    public ChestLootModifier(LootItemCondition[] conditions) {
        super(conditions);
    }

    @NotNull
    @Override
    protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> loot, LootContext ctx) {
        ResourceLocation id = ctx.getQueriedLootTableId();
        if (id == null || !id.getPath().startsWith("chests/") || id.getPath().contains("spawn_bonus")) return loot;
        String name = id.getPath().substring("chests/".length());
        boolean rich = RICH.contains(name);
        double traceP = Config.LOOT_TRACE_CHANCE.get() * (rich ? 3.0 : 1.0);
        double tokenP = Config.LOOT_TOKEN_CHANCE.get() * (rich ? 2.5 : 1.0);
        if (ctx.getRandom().nextDouble() < traceP) {
            Element e = Element.VALUES[ctx.getRandom().nextInt(Element.VALUES.length)];
            loot.add(new ItemStack(ModItems.TRACE.get(e).get()));
        }
        if (ctx.getRandom().nextDouble() < tokenP) {
            loot.add(new ItemStack(ModItems.REROLL_TOKEN.get()));
        }
        return loot;
    }

    @Override
    public Codec<? extends IGlobalLootModifier> codec() {
        return CODEC.get();
    }
}
