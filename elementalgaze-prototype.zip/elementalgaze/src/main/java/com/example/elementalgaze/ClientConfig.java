package com.example.elementalgaze;

import net.minecraftforge.common.ForgeConfigSpec;

/** 클라이언트 전용 설정 (config/elementalgaze-client.toml) */
public final class ClientConfig {
    public static final ForgeConfigSpec SPEC;
    public static final ForgeConfigSpec.DoubleValue HUD_SCALE;
    public static final ForgeConfigSpec.BooleanValue SHOW_MARKS;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();
        HUD_SCALE = b.comment("HUD 크기 배율 (1.0 = 원래 크기)").defineInRange("hudScale", 0.8, 0.4, 1.5);
        SHOW_MARKS = b.comment("몹 머리 위에 원소 마크 표시").define("showElementMarks", true);
        SPEC = b.build();
    }

    private ClientConfig() {}
}
