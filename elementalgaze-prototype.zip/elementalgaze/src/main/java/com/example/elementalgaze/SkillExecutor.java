package com.example.elementalgaze;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import javax.annotation.Nullable;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.animal.horse.AbstractHorse;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * 서버 전용 스킬 실행기. 지속/다단히트 스킬은 엔티티를 만들지 않고 Scheduler 작업으로 처리한다.
 * 같은 종류의 지속 스킬은 재시전 시 토큰이 바뀌어 이전 작업이 스스로 종료된다.
 */
public final class SkillExecutor {
    private SkillExecutor() {}

    private static final Map<String, Integer> TOKENS = new HashMap<>();

    public static void clearTokens() { TOKENS.clear(); }

    private static int newToken(UUID id, String key) { return TOKENS.merge(id + key, 1, Integer::sum); }

    private static boolean tokenAlive(UUID id, String key, int token) {
        Integer c = TOKENS.get(id + key);
        return c != null && c == token;
    }

    /** 스케줄된 작업에서 플레이어를 다시 찾기 위한 컨텍스트 */
    private record Ctx(UUID id, MinecraftServer server, GazeCharacter c, SkillDef d, int slot) {
        @Nullable
        ServerPlayer player() {
            ServerPlayer p = server.getPlayerList().getPlayer(id);
            return (p != null && p.isAlive()) ? p : null;
        }

        Element el() { return c.element; }
    }

    // ================= 진입점 =================
    public static void normal(ServerPlayer p, PlayerKit kit, GazeCharacter c) {
        long now = p.level().getGameTime();
        SkillDef d = (kit.stanceUntil > now && kit.stanceDef != null) ? kit.stanceDef : c.normal;
        if (now < kit.nextNormalAt) return;
        kit.nextNormalAt = now + Math.max(2, d.interval);
        boolean ranged = "ranged".equals(d.type);
        LivingEntity t = pickTarget(p, d.range, ranged ? 0.97 : 0.75);
        p.swing(InteractionHand.MAIN_HAND, true);
        ServerLevel l = p.serverLevel();
        Vec3 look = p.getLookAngle();
        if ("area".equals(d.style)) {
            // 강화 상태 등: 대상(또는 전방) 주변 전체를 타격
            Vec3 center = t != null ? t.position() : new Vec3(p.getX() + look.x * 2.5, p.getY(), p.getZ() + look.z * 2.5);
            Fx.slash(l, c.element, p.getEyePosition(), look);
            Fx.burst(l, c.element, center.x, center.y, center.z, d.radius * 0.7);
            float dm = dmg(p, d, Levels.NORMAL);
            int n = 0, max = maxTargets();
            for (LivingEntity e : enemiesAround(l, center, d.radius)) {
                hit(p, e, c.element, dm);
                if (++n >= max) break;
            }
            return;
        }
        if (ranged) {
            Vec3 from = p.getEyePosition().add(look.scale(0.8)).add(0, -0.2, 0);
            Vec3 end = t != null ? t.getBoundingBox().getCenter() : p.getEyePosition().add(look.scale(d.range));
            Fx.line(l, c.element, from, end);
        } else {
            Fx.slash(l, c.element, p.getEyePosition(), look);
        }
        if (t != null) hit(p, t, c.element, dmg(p, d, Levels.NORMAL));
    }

    public static void skill(ServerPlayer p, PlayerKit kit, GazeCharacter c) {
        long now = p.level().getGameTime();
        if (now < kit.skillReadyAt) {
            p.displayClientMessage(Component.translatable("msg.elementalgaze.cooldown"), true);
            return;
        }
        perform(p, c, c.skill, Levels.SKILL);
        kit.skillReadyAt = now + c.skill.cooldown;
        kit.burstEnergy = Math.min(c.burst.energyCost, kit.burstEnergy + c.skill.energyGain);
        kit.dirty = true;
    }

    public static void burst(ServerPlayer p, PlayerKit kit, GazeCharacter c) {
        long now = p.level().getGameTime();
        if (now < kit.burstReadyAt) {
            p.displayClientMessage(Component.translatable("msg.elementalgaze.cooldown"), true);
            return;
        }
        if (kit.burstEnergy < c.burst.energyCost) {
            p.displayClientMessage(Component.translatable("msg.elementalgaze.no_energy"), true);
            return;
        }
        perform(p, c, c.burst, Levels.BURST);
        kit.burstEnergy = 0f;
        kit.burstReadyAt = now + c.burst.cooldown;
        kit.dirty = true;
    }

    private static void perform(ServerPlayer p, GazeCharacter c, SkillDef d, int slot) {
        Ctx cx = new Ctx(p.getUUID(), p.server, c, d, slot);
        Fx.sound(p.serverLevel(), c.element, p.getX(), p.getY(), p.getZ(), slot == Levels.BURST);
        run(cx);
    }

    private static void run(Ctx cx) {
        switch (cx.d().type) {
            case "composite" -> {
                for (SkillDef part : cx.d().parts) run(new Ctx(cx.id(), cx.server(), cx.c(), part, cx.slot()));
            }
            case "stance" -> stance(cx);
            case "buff" -> buff(cx);
            case "seed" -> seed(cx);
            case "constellation" -> constellation(cx);
            case "lift" -> lift(cx);
            case "dash" -> dash(cx);
            case "cone" -> cone(cx);
            case "strikes" -> strikes(cx);
            case "field" -> field(cx);
            case "orbit" -> orbit(cx);
            case "summon" -> summon(cx);
            case "barrier" -> barrier(cx);
            case "boomerang" -> boomerang(cx);
            case "delayed_burst" -> delayedBurst(cx);
            default -> aoe(cx);
        }
    }

    // ================= 스킬 동작 =================

    /** aoe: 대상 지점(range>0) 또는 자신 주변(range=0)에 즉발 범위 피해. radius */
    private static void aoe(Ctx cx) {
        ServerPlayer p = cx.player();
        if (p == null) return;
        ServerLevel l = p.serverLevel();
        SkillDef d = cx.d();
        Element el = cx.el();
        Vec3 center = pickCenter(p, d);
        Fx.burst(l, el, center.x, center.y, center.z, d.radius);
        float dm = dmg(p, d, cx.slot());
        int n = 0, max = maxTargets();
        for (LivingEntity e : enemiesAround(l, center, d.radius)) {
            hitD(p, e, cx, dm);
            if (++n >= max) break;
        }
    }

    /** dash: 바라보는 방향으로 돌진하며 경로 주변에 피해. range=거리, radius */
    private static void dash(Ctx cx) {
        ServerPlayer p = cx.player();
        if (p == null) return;
        ServerLevel l = p.serverLevel();
        SkillDef d = cx.d();
        Element el = cx.el();
        Vec3 look = p.getLookAngle();
        Vec3 dir = new Vec3(look.x, 0, look.z).normalize();
        Vec3 start = p.position();
        p.setDeltaMovement(dir.x * d.range * 0.25, 0.15, dir.z * d.range * 0.25);
        p.hurtMarked = true;
        Vec3 mid = start.add(dir.scale(d.range * 0.5));
        double radius = Math.min(6.0, d.range * 0.5 + d.radius);
        Fx.line(l, el, start.add(0, 1, 0), start.add(dir.scale(d.range)).add(0, 1, 0));
        Fx.burst(l, el, mid.x, mid.y, mid.z, radius * 0.7);
        float dm = dmg(p, d, cx.slot());
        int n = 0, max = maxTargets();
        for (LivingEntity e : enemiesAround(l, mid, radius)) {
            hitD(p, e, cx, dm);
            if (++n >= max) break;
        }
    }

    /**
     * cone: 전방 부채꼴. waves=반복 횟수, tick=간격, range, cone=각도(내적 하한),
     * progressive=true 이면 파동이 앞으로 퍼지며 구간별로 한 번씩만 타격.
     */
    private static void cone(Ctx cx) {
        ServerPlayer p = cx.player();
        if (p == null) return;
        SkillDef d = cx.d();
        Element el = cx.el();
        Vec3 look = p.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        final Vec3 dir = flat.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : flat.normalize();
        final Vec3 origin = p.position().add(0, 1.0, 0);
        final int waves = Math.max(1, d.waves);
        final boolean prog = d.progressive;
        for (int w = 0; w < waves; w++) {
            final int idx = w;
            Runnable step = () -> {
                ServerPlayer sp = cx.player();
                if (sp == null) return;
                ServerLevel l = sp.serverLevel();
                double lo = prog ? d.range * idx / waves : 0.0;
                double hi = prog ? d.range * (idx + 1) / waves : d.range;
                for (double s = Math.max(1.0, lo); s <= hi; s += 1.0) {
                    Fx.stream(l, el, origin.add(dir.scale(s)), 0.4 + s * 0.28);
                }
                float dm = dmg(sp, d, cx.slot());
                int n = 0, max = maxTargets();
                Vec3 mid = origin.add(dir.scale(d.range * 0.5));
                for (LivingEntity e : enemiesAround(l, mid, d.range * 0.5 + 1.5)) {
                    Vec3 to = e.position().subtract(origin);
                    double dist = to.length();
                    if (dist < lo || dist > hi + e.getBbWidth()) continue;
                    if (dist > 0.5 && to.multiply(1, 0, 1).normalize().dot(dir) < d.cone) continue;
                    hitD(sp, e, cx, dm);
                    if (++n >= max) break;
                }
            };
            if (w == 0) step.run(); else Scheduler.later(w * Math.max(1, d.tick), step);
        }
    }

    /**
     * strikes: 여러 번 내리꽂는 일격. waves=횟수, tick=간격, aoe=일격 반경.
     * style="target": 대상 지점에 집중. 그 외: radius 안의 적을 무작위로 골라 타격(follow=true면 시전자 기준).
     */
    private static void strikes(Ctx cx) {
        ServerPlayer p = cx.player();
        if (p == null) return;
        SkillDef d = cx.d();
        final Vec3 center = pickCenter(p, d);
        int n = Math.max(1, d.waves);
        for (int i = 0; i < n; i++) {
            final int idx = i;
            Runnable r = () -> {
                ServerPlayer sp = cx.player();
                if (sp == null) return;
                ServerLevel l = sp.serverLevel();
                Vec3 pos = center;
                if (!"target".equals(d.style)) {
                    Vec3 origin = d.follow ? sp.position() : center;
                    List<LivingEntity> es = enemiesAround(l, origin, d.radius);
                    if (!es.isEmpty()) {
                        pos = es.get(sp.getRandom().nextInt(es.size())).position();
                    } else {
                        pos = origin.add((sp.getRandom().nextDouble() - 0.5) * d.radius, 0,
                                (sp.getRandom().nextDouble() - 0.5) * d.radius);
                    }
                }
                strikeAt(sp, cx, pos, idx);
            };
            if (i == 0) r.run(); else Scheduler.later(i * Math.max(1, d.tick), r);
        }
    }

    private static void strikeAt(ServerPlayer p, Ctx cx, Vec3 pos, int idx) {
        ServerLevel l = p.serverLevel();
        SkillDef d = cx.d();
        Element el = cx.el();
        Fx.strike(l, el, pos.x, pos.y, pos.z, d.aoe, idx < 4);
        float dm = dmg(p, d, cx.slot());
        int n = 0, max = maxTargets();
        for (LivingEntity e : enemiesAround(l, pos, d.aoe)) {
            hitD(p, e, cx, dm);
            if (++n >= max) break;
        }
    }

    /**
     * field: 지속 필드. duration/tick 마다 pulse, radius, hits=한 번에 맞는 최대 수, pull=끌어당김 세기,
     * follow=시전자를 따라다님. style: "vortex"(소용돌이), "columns"(적마다 물줄기), 기본은 링.
     */
    private static void field(Ctx cx) {
        ServerPlayer p = cx.player();
        if (p == null) return;
        SkillDef d = cx.d();
        final Vec3 fixed = pickCenter(p, d);
        int tick = Math.max(1, d.tick);
        int pulses = Math.max(1, d.duration / tick);
        for (int i = 0; i < pulses; i++) {
            final int idx = i;
            Runnable r = () -> {
                ServerPlayer sp = cx.player();
                if (sp == null) return;
                fieldPulse(sp, cx, d.follow ? sp.position() : fixed, idx);
            };
            if (i == 0) r.run(); else Scheduler.later(i * tick, r);
        }
    }

    private static void fieldPulse(ServerPlayer p, Ctx cx, Vec3 c, int idx) {
        ServerLevel l = p.serverLevel();
        SkillDef d = cx.d();
        Element el = cx.el();
        List<LivingEntity> es = enemiesAround(l, c, d.radius);
        boolean columns = "columns".equals(d.style);
        // interval 이 tick 보다 크면 연출은 매 pulse, 피해는 interval 마다만 (기존 필드는 interval<=tick 이라 매번 피해)
        boolean damage = d.interval <= d.tick || (idx * Math.max(1, d.tick)) % d.interval == 0;
        // 원소 흡수: 안에 있는 적에게 붙은 원소 색으로 소용돌이가 바뀐다
        Element vis = el;
        if (d.absorb > 0f) {
            for (LivingEntity e : es) {
                Element a = Reactions.auraElement(e);
                if (a != null) {
                    vis = a;
                    break;
                }
            }
        }
        if ("pillar".equals(d.style)) {
            Fx.column(l, vis, c.x, c.y, c.z, 4.0);
            Fx.ring(l, vis, c.x, c.y + 0.2, c.z, 1.4, 12);
            if (damage) {
                Fx.burst(l, vis, c.x, c.y, c.z, d.radius * 0.6);
                Fx.ring(l, vis, c.x, c.y + 0.2, c.z, d.radius, 20);
            }
        } else if ("aurora".equals(d.style)) {
            // 가장자리를 따라 오로라 기둥이 천천히 돈다
            for (int k2 = 0; k2 < 6; k2++) {
                double a2 = idx * 0.25 + k2 * Math.PI / 3;
                Fx.column(l, vis, c.x + Math.cos(a2) * d.radius * 0.85, c.y, c.z + Math.sin(a2) * d.radius * 0.85, 7.0);
            }
            Fx.ring(l, vis, c.x, c.y + 0.2, c.z, d.radius, 20);
        } else if ("shrine".equals(d.style)) {
            Fx.spiral(l, vis, c.x, c.y, c.z, d.radius * 0.5, 3.0, 2.0, 14, idx * 0.7);
            Fx.ring(l, vis, c.x, c.y + 0.2, c.z, d.radius, 20);
        } else if ("vortex".equals(d.style)) {
            Fx.spiral(l, vis, c.x, c.y, c.z, d.radius * 0.8, 3.0, 2.0, 14, idx * 0.9);
            Fx.ring(l, vis, c.x, c.y + 0.2, c.z, d.radius, 20);
        } else {
            Fx.ring(l, vis, c.x, c.y + 0.2, c.z, d.radius, 20);
        }
        if (d.pull > 0f) {
            for (LivingEntity e : es) pull(e, c, d.pull);
        }
        if (!damage) return;
        if (d.seeds > 0) markSeeds(p, cx, c);   // 전각 안의 적에게 씨앗을 계속 갱신
        float dm = dmg(p, d, cx.slot());
        int n = 0, max = Math.min(d.hits, maxTargets());
        for (LivingEntity e : es) {
            if (n >= max) break;
            if (columns) Fx.strike(l, el, e.getX(), e.getY(), e.getZ(), 1.5, false);
            hitD(p, e, cx, dm);
            if (d.absorb > 0f) {
                Element a = Reactions.auraElement(e);
                if (a != null) hit(p, e, a, dm * d.absorb);   // 흡수한 원소로 추가 피해
            }
            n++;
        }
    }

    /** orbit: 시전자 주위를 도는 구체. arms=개수, radius=궤도 반경, tick=연출 간격, interval=피해 간격. */
    private static void orbit(Ctx cx) {
        ServerPlayer p0 = cx.player();
        if (p0 == null) return;
        SkillDef d = cx.d();
        Element el = cx.el();
        final String key = ":orbit" + cx.slot();
        final int token = newToken(cx.id(), key);
        int tick = Math.max(1, d.tick);
        int pulses = Math.max(1, d.duration / tick);
        Fx.burst(p0.serverLevel(), el, p0.getX(), p0.getY(), p0.getZ(), 2.5);
        for (int i = 0; i < pulses; i++) {
            final int idx = i;
            Runnable r = () -> {
                if (!tokenAlive(cx.id(), key, token)) return;
                ServerPlayer sp = cx.player();
                if (sp == null) return;
                ServerLevel l = sp.serverLevel();
                Vec3 c = sp.position().add(0, 1.0, 0);
                double base = idx * 0.55;
                for (int a = 0; a < d.arms; a++) {
                    double ang = base + a * (Math.PI * 2 / d.arms);
                    Fx.orbitPoint(l, el, c.x + Math.cos(ang) * d.radius, c.y + Math.sin(idx * 0.4 + a) * 0.35,
                            c.z + Math.sin(ang) * d.radius);
                }
                if ((idx * tick) % Math.max(1, d.interval) == 0) {
                    float dm = dmg(sp, d, cx.slot());
                    int n = 0, max = maxTargets();
                    for (LivingEntity e : enemiesAround(l, sp.position(), d.radius + 0.8)) {
                        hitD(sp, e, cx, dm);
                        if (++n >= max) break;
                    }
                }
            };
            if (i == 0) r.run(); else Scheduler.later(i * tick, r);
        }
    }

    /** summon: 어깨 위에 떠서 가까운 적을 공격하는 소환체(파티클). range=공격 사거리, interval=공격 간격. 플레이어당 1개. */
    private static void summon(Ctx cx) {
        ServerPlayer p0 = cx.player();
        if (p0 == null) return;
        SkillDef d = cx.d();
        Element el = cx.el();
        final String key = ":summon" + d.id;   // 소환체 종류(id)마다 독립적으로 유지된다
        final int token = newToken(cx.id(), key);
        int tick = Math.max(1, d.tick);
        int pulses = Math.max(1, d.duration / tick);
        for (int i = 0; i < pulses; i++) {
            final int idx = i;
            Runnable r = () -> {
                if (!tokenAlive(cx.id(), key, token)) return;
                ServerPlayer sp = cx.player();
                if (sp == null) return;
                ServerLevel l = sp.serverLevel();
                Vec3 look = sp.getLookAngle();
                Vec3 right = new Vec3(-look.z, 0, look.x);
                right = right.lengthSqr() < 1e-4 ? new Vec3(1, 0, 0) : right.normalize();
                Vec3 fwd = new Vec3(look.x, 0, look.z);
                fwd = fwd.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : fwd.normalize();
                Vec3 oz = sp.position().add(0, d.sup + Math.sin(idx * 0.6) * 0.15, 0)
                        .add(right.scale(d.sright)).add(fwd.scale(d.sfwd));
                Fx.summon(l, el, oz);
                if ((idx * tick) % Math.max(1, d.interval) == 0) {
                    LivingEntity t = nearestEnemy(l, oz, d.range);
                    if (t != null) {
                        Fx.line(l, el, oz, t.getBoundingBox().getCenter());
                        if ("area".equals(d.style)) {
                            // 대상 주변 전체를 타격 (예: 뇌안의 낙뢰)
                            Vec3 tp = t.position();
                            Fx.burst(l, el, tp.x, tp.y, tp.z, d.aoe);
                            float dm = dmg(sp, d, cx.slot());
                            int n = 0, max = maxTargets();
                            for (LivingEntity e : enemiesAround(l, tp, d.aoe)) {
                                hitD(sp, e, cx, dm);
                                if (++n >= max) break;
                            }
                        } else {
                            hitD(sp, t, cx, dmg(sp, d, cx.slot()));
                        }
                        Fx.sound(l, el, oz.x, oz.y, oz.z, false);
                    }
                }
            };
            if (i == 0) r.run(); else Scheduler.later(i * tick, r);
        }
    }

    /**
     * barrier: 흡수 체력 + 피해 감소 부여. 기본은 전방에 벽(aoe=설치 시 타격 반경),
     * style="aura" 이면 몸을 감싸는 보호막(피해 없음). duration, tick=연출 간격.
     */
    private static void barrier(Ctx cx) {
        ServerPlayer p = cx.player();
        if (p == null) return;
        ServerLevel l = p.serverLevel();
        SkillDef d = cx.d();
        Element el = cx.el();
        PlayerKit k = PlayerKit.get(p);
        int lvl = k != null ? k.up[Levels.SKILL] : 0;
        int dur = Math.max(20, d.duration);
        p.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, dur, 1 + Math.min(2, lvl / 3)));
        p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, dur, 0));
        final String key = ":barrier" + cx.slot();
        final int token = newToken(cx.id(), key);
        int tick = Math.max(1, d.tick);
        int pulses = Math.max(1, dur / tick);

        if ("aura".equals(d.style)) {
            Fx.burst(l, el, p.getX(), p.getY(), p.getZ(), 1.8);
            Fx.sigil(l, el, p.getX(), p.getY(), p.getZ(), 2.4);
            for (int i = 1; i < pulses; i++) {
                Scheduler.later(i * tick, () -> {
                    if (!tokenAlive(cx.id(), key, token)) return;
                    ServerPlayer sp = cx.player();
                    if (sp == null) return;
                    ServerLevel ll = sp.serverLevel();
                    Fx.ring(ll, el, sp.getX(), sp.getY() + 0.3, sp.getZ(), 1.2, 10);
                    Fx.ring(ll, el, sp.getX(), sp.getY() + 1.4, sp.getZ(), 1.2, 10);
                });
            }
            return;
        }

        Vec3 look = p.getLookAngle();
        Vec3 flat = new Vec3(look.x, 0, look.z);
        Vec3 dir = flat.lengthSqr() < 1e-4 ? new Vec3(0, 0, 1) : flat.normalize();
        final Vec3 wall = p.position().add(dir.scale(2.6));
        final Vec3 side = new Vec3(-dir.z, 0, dir.x);
        Fx.burst(l, el, wall.x, wall.y, wall.z, d.aoe);
        Fx.wall(l, el, wall, side);
        float dm = dmg(p, d, cx.slot());
        int n = 0, max = maxTargets();
        for (LivingEntity e : enemiesAround(l, wall, d.aoe)) {
            hitD(p, e, cx, dm);
            if (++n >= max) break;
        }
        for (int i = 1; i < pulses; i++) {
            Scheduler.later(i * tick, () -> {
                if (!tokenAlive(cx.id(), key, token)) return;
                ServerPlayer sp = cx.player();
                if (sp == null) return;
                Fx.wall(sp.serverLevel(), el, wall, side);
            });
        }
    }

    /** boomerang: 전방 직선으로 나갔다가 돌아오며 경로의 적을 두 번 타격. range=거리, radius=경로 폭 */
    private static void boomerang(Ctx cx) {
        ServerPlayer p = cx.player();
        if (p == null) return;
        final Vec3 a = p.getEyePosition().add(0, -0.3, 0);
        final Vec3 b = a.add(p.getLookAngle().scale(cx.d().range));
        sweep(p, cx, a, b);
        Scheduler.later(7, () -> {
            ServerPlayer sp = cx.player();
            if (sp == null) return;
            sweep(sp, cx, b, sp.getEyePosition().add(0, -0.3, 0));
        });
    }

    private static void sweep(ServerPlayer sp, Ctx cx, Vec3 from, Vec3 to) {
        ServerLevel l = sp.serverLevel();
        SkillDef d = cx.d();
        Element el = cx.el();
        Fx.line(l, el, from, to);
        Fx.burst(l, el, to.x, to.y - 0.5, to.z, 1.2);
        Vec3 mid = from.add(to).scale(0.5);
        double half = from.distanceTo(to) / 2 + 2.0;
        float dm = dmg(sp, d, cx.slot());
        int n = 0, max = maxTargets();
        for (LivingEntity e : enemiesAround(l, mid, half)) {
            if (distToSegment(e.getBoundingBox().getCenter(), from, to) > d.radius) continue;
            hitD(sp, e, cx, dm);
            if (++n >= max) break;
        }
    }

    /** delayed_burst: 대상 지점에 표식 후 delay 틱 뒤 대폭발(radius), 이후 duration/tick 동안 잔류 피해(aoe). */
    private static void delayedBurst(Ctx cx) {
        ServerPlayer p = cx.player();
        if (p == null) return;
        final ServerLevel l = p.serverLevel();
        SkillDef d = cx.d();
        Element el = cx.el();
        final Vec3 center = pickCenter(p, d);
        final int delay = Math.max(5, d.delay);
        final boolean meteor = "meteor".equals(d.style);
        Fx.column(l, el, center.x, center.y, center.z, 3.0);
        for (int t = 5; t < delay; t += 5) {
            final int tt = t;
            Scheduler.later(t, () -> {
                if (meteor) {
                    Fx.meteor(l, el, center.x, center.y, center.z, delay - tt);   // 위에서 점점 내려오는 운석
                }
                Fx.ring(l, el, center.x, center.y + 0.2, center.z, Math.max(0.8, d.radius * (1.0 - (double) tt / delay)), 16);
                Fx.orbitPoint(l, el, center.x, center.y + 1.2, center.z);
            });
        }
        Scheduler.later(delay, () -> {
            ServerPlayer sp = cx.player();
            if (sp == null) return;
            Fx.strike(l, el, center.x, center.y, center.z, d.radius, true);
            Fx.sound(l, el, center.x, center.y, center.z, true);
            float dm = dmg(sp, d, cx.slot());
            int n = 0, max = maxTargets();
            for (LivingEntity e : enemiesAround(l, center, d.radius)) {
                hitD(sp, e, cx, dm);
                if (++n >= max) break;
            }
        });
        int tick = Math.max(1, d.tick);
        int pulses = d.duration / tick;
        for (int i = 1; i <= pulses; i++) {
            Scheduler.later(delay + i * tick, () -> {
                ServerPlayer sp = cx.player();
                if (sp == null) return;
                Fx.ring(l, el, center.x, center.y + 0.2, center.z, d.aoe, 16);
                Fx.orbitPoint(l, el, center.x, center.y + 0.8, center.z);
                float dm = dmg(sp, d, cx.slot()) * 0.3f;
                int n = 0, max = maxTargets();
                for (LivingEntity e : enemiesAround(l, center, d.aoe)) {
                    hitD(sp, e, cx, dm);
                    if (++n >= max) break;
                }
            });
        }
    }

    /**
     * stance: duration 동안 일반공격을 stance(JSON 하위 객체)로 교체. 같은 스킬을 다시 쓰면 갱신된다.
     * (예: 몽상일심) 일반공격은 전투 모드에서 나간다.
     */
    private static void stance(Ctx cx) {
        ServerPlayer p = cx.player();
        if (p == null || cx.d().stance == null) return;
        PlayerKit k = PlayerKit.get(p);
        if (k == null) return;
        SkillDef d = cx.d();
        Element el = cx.el();
        long now = p.level().getGameTime();
        k.stanceUntil = now + Math.max(20, d.duration);
        k.stanceDef = d.stance;
        p.displayClientMessage(Component.translatable("msg.elementalgaze.stance"), true);
        Fx.sigil(p.serverLevel(), el, p.getX(), p.getY(), p.getZ(), 3.5);
        final String key = ":stance";
        final int token = newToken(cx.id(), key);
        int tick = Math.max(2, d.tick);
        int pulses = Math.max(1, d.duration / tick);
        for (int i = 0; i < pulses; i++) {
            final int idx = i;
            Runnable r = () -> {
                if (!tokenAlive(cx.id(), key, token)) return;
                ServerPlayer sp = cx.player();
                if (sp == null) return;
                Fx.spiral(sp.serverLevel(), el, sp.getX(), sp.getY(), sp.getZ(), 0.9, 2.0, 1.5, 10, idx * 0.8);
            };
            if (i == 0) r.run(); else Scheduler.later(i * tick, r);
        }
    }

    /** lift: 자신을 위로 띄우고 duration 동안 느리게 낙하(활강). selfLift=상승 속도. */
    private static void lift(Ctx cx) {
        ServerPlayer p = cx.player();
        if (p == null) return;
        SkillDef d = cx.d();
        Element el = cx.el();
        Vec3 look = p.getLookAngle();
        p.setDeltaMovement(look.x * 0.3, d.selfLift, look.z * 0.3);
        p.hurtMarked = true;
        p.fallDistance = 0f;
        p.addEffect(new MobEffectInstance(MobEffects.SLOW_FALLING, Math.max(20, d.duration), 0));
        Fx.spiral(p.serverLevel(), el, p.getX(), p.getY(), p.getZ(), 1.2, 4.0, 3.0, 14, 0.0);
        for (int i = 1; i <= 6; i++) {
            Scheduler.later(i * 3, () -> {
                ServerPlayer sp = cx.player();
                if (sp == null) return;
                ServerLevel ll = sp.serverLevel();
                Fx.orbitPoint(ll, el, sp.getX(), sp.getY(), sp.getZ());
                Fx.ring(ll, el, sp.getX(), sp.getY(), sp.getZ(), 1.0, 10);
            });
        }
    }

    /** 스킬 타격: 기본 타격 + 행동불능(stun) + 띄우기(launch) */
    private static void hitD(ServerPlayer p, LivingEntity e, Ctx cx, float dm) {
        SkillDef d = cx.d();
        hit(p, e, cx.el(), dm);
        if (d.stun > 0) e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, d.stun, 6));
        if (d.slow > 0) e.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, d.slow, 2));
        if (d.launch > 0f) {
            Vec3 m = e.getDeltaMovement();
            e.setDeltaMovement(m.x, d.launch, m.z);
            e.hurtMarked = true;
        }
    }

    // ================= 2단계 스킬: 버프 / 씨앗 연쇄 / 별자리 =================

    /** 버프가 지금 유효한지. buffR > 0 이면 시전 위치(또는 시전자) 반경 안에 있을 때만 유효. */
    private static boolean buffActive(ServerPlayer p, PlayerKit k) {
        if (k.buffUntil <= p.level().getGameTime()) return false;
        if (k.buffR <= 0f || k.buffFollow) return true;
        double dx = p.getX() - k.buffX, dz = p.getZ() - k.buffZ;
        return dx * dx + dz * dz <= (double) k.buffR * k.buffR;
    }

    /**
     * buff: duration 동안 공격력(buffAtk, 0.5=+50%)과 반응 숙련(buffMastery)을 올린다.
     * radius>0 이면 시전 위치 반경 안에서만 유효(follow=true 면 시전자를 따라다님), radius=0 이면 어디서나.
     */
    private static void buff(Ctx cx) {
        ServerPlayer p = cx.player();
        if (p == null) return;
        PlayerKit k = PlayerKit.get(p);
        if (k == null) return;
        SkillDef d = cx.d();
        Element el = cx.el();
        long now = p.level().getGameTime();
        k.buffUntil = now + Math.max(20, d.duration);
        k.buffMastery = d.buffMastery;
        k.buffAtk = d.buffAtk;
        k.buffR = Math.max(0f, d.radius);
        k.buffFollow = d.follow;
        k.buffX = p.getX();
        k.buffZ = p.getZ();
        p.displayClientMessage(Component.translatable("msg.elementalgaze.buff"), true);
        final double ax = p.getX(), ay = p.getY(), az = p.getZ();
        final String key = ":buff" + cx.slot();
        final int token = newToken(cx.id(), key);
        final float sr = d.radius > 0f ? d.radius : 3.5f;
        int tick = Math.max(5, d.tick);
        int pulses = Math.max(1, d.duration / tick);
        for (int i = 0; i < pulses; i++) {
            final int idx = i;
            Runnable r = () -> {
                if (!tokenAlive(cx.id(), key, token)) return;
                ServerPlayer sp = cx.player();
                if (sp == null) return;
                ServerLevel l = sp.serverLevel();
                boolean moving = d.follow || d.radius <= 0f;
                double x = moving ? sp.getX() : ax, y = moving ? sp.getY() : ay, z = moving ? sp.getZ() : az;
                Fx.sigil(l, el, x, y, z, sr);
                if (idx % 2 == 0) Fx.spiral(l, el, x, y, z, Math.min(sr, 2.0f), 2.5, 1.5, 12, idx * 0.7);
            };
            if (i == 0) r.run(); else Scheduler.later(i * tick, r);
        }
    }

    /**
     * seed: 대상 지점 범위 피해 후, radius 안의 가까운 적 최대 seeds 마리에 씨앗을 심는다(seedTicks 동안).
     * 씨앗 가진 적이 맞으면 다른 씨앗 보유 적들도 chain 배율의 풀 피해를 받는다.
     */
    private static void seed(Ctx cx) {
        ServerPlayer p = cx.player();
        if (p == null) return;
        ServerLevel l = p.serverLevel();
        SkillDef d = cx.d();
        Element el = cx.el();
        Vec3 center = pickCenter(p, d);
        Fx.burst(l, el, center.x, center.y, center.z, d.aoe);
        float dm = dmg(p, d, cx.slot());
        int n = 0, max = maxTargets();
        for (LivingEntity e : enemiesAround(l, center, d.aoe)) {
            hitD(p, e, cx, dm);
            if (++n >= max) break;
        }
        markSeeds(p, cx, center);
    }

    private static void markSeeds(ServerPlayer p, Ctx cx, Vec3 center) {
        ServerLevel l = p.serverLevel();
        SkillDef d = cx.d();
        long now = l.getGameTime();
        List<LivingEntity> es = enemiesAround(l, center, d.radius);
        es.sort(Comparator.comparingDouble((LivingEntity e) -> e.distanceToSqr(center)));
        int n = 0, max = Math.min(Math.max(1, d.seeds), maxTargets());
        for (LivingEntity e : es) {
            if (n >= max) break;
            CompoundTag t = e.getPersistentData();
            boolean fresh = t.getLong("gz_seed") <= now;
            t.putLong("gz_seed", now + d.seedTicks);
            t.putString("gz_seed_o", p.getStringUUID());
            if (fresh) {
                Net.sendAura(e, Element.DENDRO.ordinal(), d.seedTicks);   // 머리 위에 풀 룬 아이콘으로 표시
                Fx.hit(l, Element.DENDRO, e.getX(), e.getY() + e.getBbHeight() + 0.3, e.getZ());
            }
            n++;
        }
        PlayerKit k = PlayerKit.get(p);
        if (k != null && d.chain > 0f) k.chainMult = Math.max(k.chainMult, d.chain);
    }

    /** 씨앗 연쇄: 씨앗을 가진 적을 때리면(최대 1초에 3번) 같은 주인의 다른 씨앗 보유 적들도 chainMult 배율 피해. */
    private static void triggerChain(ServerPlayer p, @Nullable PlayerKit k, LivingEntity src) {
        if (k == null || k.chainMult <= 0f) return;
        long now = p.level().getGameTime();
        if (now < k.chainReadyAt) return;
        String owner = p.getStringUUID();
        CompoundTag st = src.getPersistentData();
        if (st.getLong("gz_seed") <= now || !owner.equals(st.getString("gz_seed_o"))) return;
        k.chainReadyAt = now + 20;   // 피해를 주기 전에 먼저 걸어서 재귀를 막는다
        ServerLevel l = (ServerLevel) src.level();
        float dm = base(p) * k.chainMult * Levels.atkMul(k.up, k.level);
        int n = 0, max = maxTargets();
        for (LivingEntity e : enemiesAround(l, p.position(), 40.0)) {
            if (e == src) continue;
            CompoundTag et = e.getPersistentData();
            if (et.getLong("gz_seed") <= now || !owner.equals(et.getString("gz_seed_o"))) continue;
            Fx.line(l, Element.DENDRO, src.getBoundingBox().getCenter(), e.getBoundingBox().getCenter());
            hit(p, e, Element.DENDRO, dm);
            if (++n >= max) break;
        }
    }

    /**
     * constellation: 대상 주변 적 최대 seeds 마리(최대 6)에 별 표식을 찍고 선으로 잇는다.
     * delay 틱 뒤 표식 대상 전원과 별자리 선 위의 적(60%)을 타격하고 slow 만큼 둔화시킨다.
     */
    private static void constellation(Ctx cx) {
        ServerPlayer p = cx.player();
        if (p == null) return;
        ServerLevel l = p.serverLevel();
        SkillDef d = cx.d();
        Element el = cx.el();
        final Vec3 center = pickCenter(p, d);
        List<LivingEntity> es = enemiesAround(l, center, d.radius);
        es.sort(Comparator.comparingDouble((LivingEntity e) -> e.distanceToSqr(center)));
        int cap = Math.min(Math.max(1, d.seeds), 6);
        final List<LivingEntity> marked = new ArrayList<>(es.subList(0, Math.min(cap, es.size())));
        if (marked.isEmpty()) {
            Fx.sigil(l, el, center.x, center.y, center.z, 3.0);
            return;
        }
        for (int i = 0; i < marked.size(); i++) {
            LivingEntity e = marked.get(i);
            Vec3 pt = e.getBoundingBox().getCenter();
            Fx.sigil(l, el, e.getX(), e.getY(), e.getZ(), 1.8);
            Fx.hit(l, el, pt.x, pt.y + e.getBbHeight() * 0.5, pt.z);
            Net.sendAura(e, el.ordinal(), Math.max(5, d.delay));
            if (i > 0) Fx.line(l, el, marked.get(i - 1).getBoundingBox().getCenter(), pt);
        }
        if (marked.size() > 2) {
            Fx.line(l, el, marked.get(marked.size() - 1).getBoundingBox().getCenter(), marked.get(0).getBoundingBox().getCenter());
        }
        Fx.sound(l, el, center.x, center.y, center.z, false);
        Scheduler.later(Math.max(5, d.delay), () -> {
            ServerPlayer sp = cx.player();
            if (sp == null) return;
            ServerLevel ll = sp.serverLevel();
            float dm = dmg(sp, d, cx.slot());
            int n = 0, mx = maxTargets();
            for (LivingEntity e : marked) {
                if (!e.isAlive()) continue;
                Fx.strike(ll, el, e.getX(), e.getY(), e.getZ(), 2.0, false);
                hitD(sp, e, cx, dm);
            }
            int segs = marked.size() > 2 ? marked.size() : marked.size() - 1;
            for (int i = 0; i < segs; i++) {
                Vec3 a = marked.get(i).getBoundingBox().getCenter();
                Vec3 b = marked.get((i + 1) % marked.size()).getBoundingBox().getCenter();
                Fx.line(ll, el, a, b);
                Vec3 mid = a.add(b).scale(0.5);
                for (LivingEntity e : enemiesAround(ll, mid, a.distanceTo(b) / 2 + 2.0)) {
                    if (marked.contains(e) || distToSegment(e.getBoundingBox().getCenter(), a, b) > 1.6) continue;
                    hitD(sp, e, cx, dm * 0.6f);
                    if (++n >= mx) break;
                }
            }
        });
    }

    // ================= 공통 =================

    /**
     * 스킬 대상 판정. 기본은 모든 몹(동물, 주민 포함). 플레이어, 갑옷 거치대는 제외.
     * 설정으로 적대 몹만 공격하거나, 길들인 반려동물을 보호할 수 있다.
     */
    private static boolean isEnemy(LivingEntity e) {
        if (!e.isAlive() || !(e instanceof Mob)) return false;
        if (!Config.ATTACK_ALL_MOBS.get() && !(e instanceof Enemy)) return false;
        if (Config.PROTECT_PETS.get()) {
            if (e instanceof TamableAnimal t && t.isTame()) return false;
            if (e instanceof AbstractHorse h && h.isTamed()) return false;
        }
        return true;
    }

    private static int maxTargets() { return Config.MAX_TARGETS.get(); }

    /** 기준 공격력 = 플레이어 공격력 속성(들고 있는 무기 수치 반영, 무기 종류는 무관). */
    private static float base(ServerPlayer p) {
        return Math.max((float) p.getAttributeValue(Attributes.ATTACK_DAMAGE), Config.MIN_BASE_ATK.get().floatValue());
    }

    /** 기준공격력 x 스킬배율 x 스킬레벨 x 공격력/레벨 보너스 */
    private static float dmg(ServerPlayer p, SkillDef d, int slot) {
        PlayerKit k = PlayerKit.get(p);
        float m = 1f, a = 1f;
        if (k != null) {
            m = Levels.skillMul(k.up, slot);
            a = Levels.atkMul(k.up, k.level) * (buffActive(p, k) ? 1f + k.buffAtk : 1f);
        }
        return base(p) * d.mult * m * a;
    }

    private static void hit(ServerPlayer p, LivingEntity t, Element el, float dmg) {
        PlayerKit k = PlayerKit.get(p);
        boolean crit = false;
        float bonus = 0f;
        if (k != null) {
            bonus = Levels.mastery(k.up) + (buffActive(p, k) ? k.buffMastery : 0f);
            if (p.getRandom().nextFloat() < Levels.critRate(k.up)) {
                dmg *= Levels.CRIT_DMG;
                crit = true;
            }
        }
        float out = Reactions.apply(p, t, el, dmg, bonus);
        t.invulnerableTime = 0;
        t.hurt(p.damageSources().playerAttack(p), out);
        ServerLevel l = (ServerLevel) t.level();
        double y = t.getY() + t.getBbHeight() * 0.5;
        Fx.hit(l, el, t.getX(), y, t.getZ());
        if (crit) l.sendParticles(ParticleTypes.CRIT, t.getX(), y + 0.3, t.getZ(), 8, 0.3, 0.3, 0.3, 0.3);
        triggerChain(p, k, t);
    }

    private static void pull(LivingEntity e, Vec3 center, float strength) {
        Vec3 v = center.subtract(e.position());
        double len = v.length();
        if (len < 0.5) return;
        Vec3 m = v.scale(strength / len);
        e.setDeltaMovement(e.getDeltaMovement().add(m.x, 0.08, m.z));
        e.hurtMarked = true;
    }

    private static Vec3 pickCenter(ServerPlayer p, SkillDef d) {
        if (d.range <= 0) return p.position();
        LivingEntity t = pickTarget(p, d.range, 0.9);
        if (t != null) return t.position();
        Vec3 pt = p.getEyePosition().add(p.getLookAngle().scale(d.range * 0.6));
        return new Vec3(pt.x, p.getY(), pt.z);
    }

    private static List<LivingEntity> enemiesAround(ServerLevel lvl, Vec3 c, double r) {
        AABB box = new AABB(c.x - r, c.y - r, c.z - r, c.x + r, c.y + r, c.z + r);
        return lvl.getEntitiesOfClass(LivingEntity.class, box,
                e -> isEnemy(e) && e.distanceToSqr(c) <= (r + e.getBbWidth()) * (r + e.getBbWidth()));
    }

    @Nullable
    private static LivingEntity nearestEnemy(ServerLevel l, Vec3 from, double range) {
        LivingEntity best = null;
        double bd = range * range;
        for (LivingEntity e : enemiesAround(l, from, range)) {
            double dd = e.distanceToSqr(from);
            if (dd < bd) {
                bd = dd;
                best = e;
            }
        }
        return best;
    }

    private static double distToSegment(Vec3 p, Vec3 a, Vec3 b) {
        Vec3 ab = b.subtract(a);
        double len2 = ab.lengthSqr();
        double t = len2 < 1e-6 ? 0.0 : Mth.clamp(p.subtract(a).dot(ab) / len2, 0.0, 1.0);
        return p.distanceTo(a.add(ab.scale(t)));
    }

    @Nullable
    private static LivingEntity pickTarget(ServerPlayer p, double range, double minDot) {
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        AABB box = p.getBoundingBox().expandTowards(look.scale(range)).inflate(2.0);
        LivingEntity best = null;
        double bestDot = minDot;
        for (LivingEntity e : p.level().getEntitiesOfClass(LivingEntity.class, box, SkillExecutor::isEnemy)) {
            Vec3 to = e.getBoundingBox().getCenter().subtract(eye);
            double dist = to.length();
            if (dist > range + e.getBbWidth()) continue;
            double dot = to.normalize().dot(look);
            if (dot > bestDot && p.hasLineOfSight(e)) {
                bestDot = dot;
                best = e;
            }
        }
        return best;
    }
}
