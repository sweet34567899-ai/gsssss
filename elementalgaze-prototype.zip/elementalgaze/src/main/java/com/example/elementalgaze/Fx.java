package com.example.elementalgaze;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

/**
 * 서버 쪽 연출 API. 스킬 코드는 예전과 똑같이 호출하지만, 이제 파티클을 직접 만들지 않고
 * 근처 플레이어에게 "연출 신호"만 보낸다. 실제 그리기는 client/FxClient 가 담당한다.
 */
public final class Fx {
    private Fx() {}

    private static void send(ServerLevel l, byte kind, Element e, double x, double y, double z,
                             double vx, double vy, double vz, double a, double b) {
        FxPacket m = new FxPacket(kind, (byte) e.ordinal(), (float) x, (float) y, (float) z,
                (float) vx, (float) vy, (float) vz, (float) a, (float) b);
        Net.CH.send(PacketDistributor.NEAR.with(() -> new PacketDistributor.TargetPoint(x, y, z, 64.0, l.dimension())), m);
    }

    public static void ring(ServerLevel l, Element e, double cx, double cy, double cz, double r, int points) {
        send(l, FxPacket.RING, e, cx, cy, cz, 0, 0, 0, r, 0);
    }

    public static void spiral(ServerLevel l, Element e, double cx, double cy, double cz,
                              double radius, double height, double turns, int points, double phase) {
        send(l, FxPacket.SPIRAL, e, cx, cy, cz, turns, phase, 0, radius, height);
    }

    public static void column(ServerLevel l, Element e, double x, double y, double z, double h) {
        send(l, FxPacket.COLUMN, e, x, y, z, 0, 0, 0, h, 0);
    }

    /** 두 점을 잇는 빔. 번개는 지그재그 번개. */
    public static void line(ServerLevel l, Element e, Vec3 a, Vec3 b) {
        send(l, FxPacket.LINE, e, a.x, a.y, a.z, b.x, b.y, b.z, 0, 0);
    }

    public static void burst(ServerLevel l, Element e, double x, double y, double z, double r) {
        send(l, FxPacket.BURST, e, x, y, z, 0, 0, 0, r, 0);
    }

    /** 하늘에서 내리꽂는 일격. 번개는 낙뢰, 바위는 보석 낙하, 물은 물줄기. */
    public static void strike(ServerLevel l, Element e, double x, double y, double z, double r, boolean bolt) {
        send(l, FxPacket.STRIKE, e, x, y, z, 0, 0, 0, r, bolt ? 1 : 0);
        sound(l, e, x, y, z, false);
    }

    public static void hit(ServerLevel l, Element e, double x, double y, double z) {
        send(l, FxPacket.HIT, e, x, y, z, 0, 0, 0, 0, 0);
    }

    public static void stream(ServerLevel l, Element e, Vec3 c, double spread) {
        send(l, FxPacket.STREAM, e, c.x, c.y, c.z, 0, 0, 0, spread, 0);
    }

    public static void orbitPoint(ServerLevel l, Element e, double x, double y, double z) {
        send(l, FxPacket.ORBIT, e, x, y, z, 0, 0, 0, 0, 0);
    }

    public static void summon(ServerLevel l, Element e, Vec3 p) {
        send(l, FxPacket.SUMMON, e, p.x, p.y, p.z, 0, 0, 0, 0, 0);
    }

    public static void wall(ServerLevel l, Element e, Vec3 c, Vec3 side) {
        send(l, FxPacket.WALL, e, c.x, c.y, c.z, side.x, 0, side.z, 0, 0);
    }

    public static void slash(ServerLevel l, Element e, Vec3 eye, Vec3 look) {
        send(l, FxPacket.SLASH, e, eye.x, eye.y, eye.z, look.x, look.y, look.z, 0, 0);
    }

    /** 높이 h 위에서 떨어지는 운석 한 장면 */
    public static void meteor(ServerLevel l, Element e, double x, double y, double z, double h) {
        send(l, FxPacket.METEOR, e, x, y, z, 0, 0, 0, h, 0);
    }

    /** 바닥에 깔리는 회전 마법진 */
    public static void sigil(ServerLevel l, Element e, double x, double y, double z, double r) {
        send(l, FxPacket.SIGIL, e, x, y, z, 0, 0, 0, r, 0);
    }

    public static void sound(ServerLevel l, Element e, double x, double y, double z, boolean big) {
        SoundEvent s = switch (e) {
            case PYRO -> SoundEvents.FIRECHARGE_USE;
            case HYDRO -> SoundEvents.PLAYER_SPLASH;
            case ELECTRO -> SoundEvents.LIGHTNING_BOLT_IMPACT;
            case CRYO -> SoundEvents.GLASS_BREAK;
            case ANEMO -> SoundEvents.ENDER_DRAGON_FLAP;
            case GEO -> SoundEvents.AMETHYST_CLUSTER_BREAK;
            case DENDRO -> SoundEvents.BONE_MEAL_USE;
        };
        l.playSound(null, x, y, z, s, SoundSource.PLAYERS, big ? 1.0f : 0.5f, big ? 0.9f : 1.2f);
    }
}
