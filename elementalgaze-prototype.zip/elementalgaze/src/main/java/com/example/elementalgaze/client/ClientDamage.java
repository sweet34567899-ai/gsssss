package com.example.elementalgaze.client;

import com.example.elementalgaze.Element;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * 내가 넣은 피해를 모아서 보여 준다: 누적 피해, 최근 5초 DPS, 최고 한 방, 그리고 조준점 근처에 떠오르는 피해 숫자.
 * 마지막 공격 후 약 10초 동안 아무 공격이 없으면 전투가 끝난 것으로 보고 누적을 초기화한다.
 */
public final class ClientDamage {
    private static final int RESET_TICKS = 200, FADE_TICKS = 40, WINDOW_TICKS = 100, POPUP_TICKS = 30;

    private static final class Popup {
        float amount;
        int el;
        boolean crit;
        long born;
        float dx;
    }

    private static final List<Popup> POPUPS = new ArrayList<>();
    private static final ArrayDeque<float[]> WINDOW = new ArrayDeque<>();   // {틱, 피해}
    private static double total;
    private static float best;
    private static long lastHit = -100000, started;
    private static int el;

    private ClientDamage() {}

    public static double total() {
        return total;
    }

    public static void onPacket(float amount, byte hits, byte element, boolean crit) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        long now = mc.level.getGameTime();
        if (now - lastHit > RESET_TICKS) {
            total = 0;
            best = 0;
            started = now;
            WINDOW.clear();
        }
        total += amount;
        best = Math.max(best, amount);
        lastHit = now;
        el = element;
        WINDOW.addLast(new float[]{now, amount});
        Popup p = new Popup();
        p.amount = amount;
        p.el = element;
        p.crit = crit;
        p.born = now;
        p.dx = (mc.level.random.nextFloat() - 0.5f) * 70f;
        POPUPS.add(p);
        if (POPUPS.size() > 24) POPUPS.remove(0);
    }

    private static String num(double v) {
        return String.format(Locale.ROOT, "%,d", Math.round(v));
    }

    private static float dps(long now) {
        while (!WINDOW.isEmpty() && now - WINDOW.peekFirst()[0] > WINDOW_TICKS) WINDOW.removeFirst();
        double sum = 0;
        for (float[] e : WINDOW) sum += e[1];
        double elapsed = Math.max(1.0, Math.min(WINDOW_TICKS, now - started) / 20.0);
        return (float) (sum / elapsed);
    }

    public static void render(GuiGraphics g, Font f, int vw, int vh, long now, float pt) {
        float since = now - lastHit + pt;
        if (since < RESET_TICKS + FADE_TICKS && total > 0) {
            float fade = since < RESET_TICKS ? 1f : 1f - (since - RESET_TICKS) / FADE_TICKS;
            int a = (int) (255 * Math.max(0f, fade));
            int accent = 0xFF000000 | Element.VALUES[Math.max(0, Math.min(Element.VALUES.length - 1, el))].color;
            int x = 8, y = 8, w = 118, h = 36;
            g.fill(x, y, x + w, y + h, ((Math.round(a * 0.75f)) << 24) | 0x101018);
            g.fill(x, y, x + 2, y + h, (a << 24) | (accent & 0xFFFFFF));
            g.drawString(f, Component.translatable("hud.elementalgaze.dmg_total"), x + 7, y + 4, (a << 24) | 0x8A8FA8, false);
            g.drawString(f, num(total), x + 7, y + 14, (a << 24) | 0xFFD75E, true);
            String sub = Component.translatable("hud.elementalgaze.dps", num(dps(now)), num(best)).getString();
            g.pose().pushPose();
            g.pose().translate(x + 7, y + 26, 0);
            g.pose().scale(0.75f, 0.75f, 1f);
            g.drawString(f, sub, 0, 0, (a << 24) | 0xB8BDD1, false);
            g.pose().popPose();
        }
        // 떠오르는 피해 숫자
        Iterator<Popup> it = POPUPS.iterator();
        while (it.hasNext()) {
            Popup p = it.next();
            float age = now - p.born + pt;
            if (age > POPUP_TICKS) {
                it.remove();
                continue;
            }
            float k = age / POPUP_TICKS;
            int a = (int) (255 * (1f - k * k));
            if (a < 8) continue;
            int rgb = p.crit ? 0xFFD75E : Element.VALUES[Math.max(0, Math.min(Element.VALUES.length - 1, p.el))].color;
            float s = p.crit ? 1.35f : 1.0f;
            String txt = num(p.amount) + (p.crit ? "!" : "");
            g.pose().pushPose();
            g.pose().translate(vw / 2f + 14 + p.dx * 0.5f, vh / 2f - 12 - age * 0.9f, 0);
            g.pose().scale(s, s, 1f);
            g.drawString(f, txt, 0, 0, (a << 24) | (rgb & 0xFFFFFF), true);
            g.pose().popPose();
        }
    }
}
