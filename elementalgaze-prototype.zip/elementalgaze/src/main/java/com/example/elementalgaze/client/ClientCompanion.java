package com.example.elementalgaze.client;

import com.example.elementalgaze.ClientKit;
import com.example.elementalgaze.GazeCharacter;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/** 동료 루미의 알림: 상태가 바뀌면 화면 왼쪽 아래에 말풍선으로 알려 준다. */
public final class ClientCompanion {
    private static final int MINT = 0x8FE3C8, SHOW_TICKS = 100, FADE_TICKS = 16;

    private static boolean init, prevReady;
    private static byte prevStage;
    private static String prevChar = "";
    private static int prevLevel;
    private static long lastTick = Long.MIN_VALUE, until, hpWarnAt;
    private static Component text = Component.empty();

    private ClientCompanion() {}

    private static void say(Component c, long now) {
        text = c;
        until = now + SHOW_TICKS;
    }

    private static void tick(Minecraft mc, long now) {
        if (now == lastTick) return;
        lastTick = now;
        boolean ready = ClientKit.burstCost > 0 && ClientKit.burst >= ClientKit.burstCost;
        if (!init) {
            init = true;
            prevStage = ClientKit.stage;
            prevChar = ClientKit.characterId;
            prevLevel = ClientKit.level;
            prevReady = ready;
            return;
        }
        if (ClientKit.stage >= 2 && prevStage < 2) {
            say(Component.translatable("companion.elementalgaze.awaken"), now);
        } else if (ClientKit.stage >= 2 && !ClientKit.characterId.equals(prevChar) && !ClientKit.characterId.isEmpty()) {
            say(Component.translatable("companion.elementalgaze.char", Component.translatable(GazeCharacter.nameKey(ClientKit.characterId))), now);
        } else if (ClientKit.level > prevLevel && prevLevel > 0) {
            say(Component.translatable("companion.elementalgaze.levelup", ClientKit.level), now);
        } else if (ready && !prevReady && ClientKit.stage >= 2) {
            say(Component.translatable("companion.elementalgaze.q_ready", Keys.BURST.getTranslatedKeyMessage()), now);
        } else if (mc.player != null && mc.player.getMaxHealth() > 0 && mc.player.getHealth() / mc.player.getMaxHealth() < 0.3f
                && now >= hpWarnAt && mc.player.isAlive()) {
            say(Component.translatable("companion.elementalgaze.low_hp"), now);
            hpWarnAt = now + 600;
        }
        prevStage = ClientKit.stage;
        prevChar = ClientKit.characterId;
        prevLevel = ClientKit.level;
        prevReady = ready;
    }

    public static void render(GuiGraphics g, Font f, int vw, int vh, long now, float pt) {
        Minecraft mc = Minecraft.getInstance();
        tick(mc, now);
        float left = until - now - pt;
        if (left <= 0f) return;
        float fade = Math.min(1f, left / FADE_TICKS);
        int a = (int) (255 * fade);
        String name = Component.translatable("companion.elementalgaze.name").getString();
        String msg = text.getString();
        int w = Math.max(f.width(msg), f.width(name) + 14) + 16, h = 30;
        int x = (vw - w) / 2, y = vh - h - 76;   // 화면 가운데, 바닐라 경험치바/체력 줄 바로 위
        g.fill(x, y, x + w, y + h, ((Math.round(a * 0.78f)) << 24) | 0x101820);
        g.fill(x, y, x + 2, y + h, (a << 24) | MINT);
        g.drawString(f, "★", x + 7, y + 4, (a << 24) | 0xFFE066, false);
        g.drawString(f, name, x + 18, y + 4, (a << 24) | MINT, false);
        g.drawString(f, msg, x + 8, y + 16, (a << 24) | 0xFFFFFF, false);
    }
}
