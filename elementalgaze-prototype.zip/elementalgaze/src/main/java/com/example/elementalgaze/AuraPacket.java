package com.example.elementalgaze;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** 몹에 원소가 묻었다/사라졌다는 알림. el=-1 이면 제거. 몹 머리 위 원소 마크 표시에 쓴다. */
public final class AuraPacket {
    public final int entityId;
    public final byte el;
    public final short ticks;

    public AuraPacket(int entityId, byte el, short ticks) {
        this.entityId = entityId;
        this.el = el;
        this.ticks = ticks;
    }

    public static void encode(AuraPacket m, FriendlyByteBuf b) {
        b.writeVarInt(m.entityId);
        b.writeByte(m.el);
        b.writeShort(m.ticks);
    }

    public static AuraPacket decode(FriendlyByteBuf b) {
        return new AuraPacket(b.readVarInt(), b.readByte(), b.readShort());
    }

    public static void handle(AuraPacket m, Supplier<NetworkEvent.Context> s) {
        NetworkEvent.Context ctx = s.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> com.example.elementalgaze.client.ClientMarks.onPacket(m.entityId, m.el, m.ticks)));
        ctx.setPacketHandled(true);
    }
}
