package com.example.elementalgaze.client;

import com.example.elementalgaze.ElementalGaze;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * 파이논 Q 의 가시 사슬. 카메라를 따라 도는 파티클 대신, 월드에 고정된 메시로 그린다.
 * 대상마다 사슬 두 가닥이 X 자로 엇갈려 바닥에 대각선으로 꽂히고(창끝이 바닥에 박힘), 대상의 몸통을 꿰뚫는다.
 * 각 사슬은 축을 포함하는 서로 직교한 두 장의 면으로 그려 어느 방향에서 봐도 보인다.
 */
@Mod.EventBusSubscriber(modid = ElementalGaze.MODID, value = Dist.CLIENT)
public final class ChainRenderer {
    private ChainRenderer() {}

    private static final ResourceLocation TEX = new ResourceLocation(ElementalGaze.MODID, "textures/particle/chain_pierce.png");
    private static final double LEN = 11.0;          // 사슬 길이 (창끝 ~ 하늘 쪽 끝)
    private static final double HALF_W = LEN * 0.05; // 반폭 (텍스처 비율 1:10)
    private static final double FALL = 14.0;         // 낙하 시작 높이 (축 방향)
    private static final int FALL_TICKS = 5;

    private static final class Chain {
        double x, y, z, h;       // y = 바닥, h = 대상 몸통 중심 높이
        double ux, uz;           // 기울어지는 수평 방향
        long born, expire;
        boolean landed;
    }

    private static final List<Chain> LIST = new ArrayList<>();

    /** 대상 한 명에게 X 자 사슬을 건다. 이미 있으면 유지 시간만 늘린다. fresh = 하늘에서 떨어지는 연출 */
    public static void pulse(double x, double groundY, double z, double midH, boolean fresh) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        long now = mc.level.getGameTime();
        long exp = now + (fresh ? 15 : 7);
        for (Chain c : LIST) {
            double dx = c.x - x, dz = c.z - z;
            if (dx * dx + dz * dz < 2.25 && Math.abs(c.y - groundY) < 3.0) {
                if (c.expire < exp) c.expire = exp;
            }
        }
        for (Chain c : LIST) {
            double dx = c.x - x, dz = c.z - z;
            if (dx * dx + dz * dz < 2.25 && Math.abs(c.y - groundY) < 3.0) return;
        }
        double th = ((Math.floor(x * 3.1) * 12.9898 + Math.floor(z * 3.1) * 78.233) % 6.2832);
        double ux = Math.cos(th), uz = Math.sin(th);
        for (int k = 0; k < 2; k++) {
            Chain c = new Chain();
            c.x = x; c.y = groundY; c.z = z; c.h = Math.max(0.8, midH);
            c.ux = k == 0 ? ux : -ux;
            c.uz = k == 0 ? uz : -uz;
            c.born = fresh ? now : now - FALL_TICKS - 1;
            c.expire = exp;
            c.landed = !fresh;
            LIST.add(c);
        }
    }

    @SubscribeEvent
    public static void onTick(net.minecraftforge.event.TickEvent.ClientTickEvent e) {
        if (e.phase != net.minecraftforge.event.TickEvent.Phase.END || LIST.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            LIST.clear();
            return;
        }
        long now = mc.level.getGameTime();
        Iterator<Chain> it = LIST.iterator();
        while (it.hasNext()) {
            Chain c = it.next();
            if (now > c.expire) {
                it.remove();
                continue;
            }
            if (!c.landed && now - c.born >= FALL_TICKS) {
                c.landed = true;
                double s = c.h * Math.tan(LEAN);
                FxClient.chainImpact(c.x - c.ux * s, c.y, c.z - c.uz * s);
            }
        }
    }

    private static final double LEAN = Math.toRadians(36);

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        LIST.clear();
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || LIST.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        PoseStack ps = e.getPoseStack();
        Vec3 cam = e.getCamera().getPosition();
        float pt = e.getPartialTick();
        long now = mc.level.getGameTime();
        MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();
        RenderType rt = RenderType.entityTranslucent(TEX);
        VertexConsumer vc = bs.getBuffer(rt);
        Matrix4f pm = ps.last().pose();
        Matrix3f nm = ps.last().normal();
        double sinL = Math.sin(LEAN), cosL = Math.cos(LEAN);
        boolean any = false;
        for (Chain c : LIST) {
            double age = now - c.born + pt;
            double remain = c.expire - now - pt;
            float alpha = (float) Math.min(1.0, Math.max(0.0, remain / 4.0));
            if (age < 0 || alpha <= 0.01f) continue;
            // 축 방향 d (바닥에서 위로, 기울어짐). 창끝은 바닥 아래로 살짝 박힌다
            double dx = c.ux * sinL, dy = cosL, dz = c.uz * sinL;
            double s = c.h * Math.tan(LEAN);
            double tx = c.x - c.ux * s, ty = c.y - 0.25, tz = c.z - c.uz * s;
            double off = 0;
            if (!c.landed || age < FALL_TICKS) {
                double f = Math.min(1.0, age / FALL_TICKS);
                off = FALL * (1.0 - f * f);        // 가속하며 내리꽂힌다
            }
            tx += dx * off; ty += dy * off; tz += dz * off;
            // 두 면의 폭 방향: w1 = 수평(기울어지는 면에 수직), w2 = d x w1
            double w1x = -c.uz, w1z = c.ux;
            double w2x = dy * w1z, w2y = dz * w1x - dx * w1z, w2z = -dy * w1x;
            double wl = Math.sqrt(w2x * w2x + w2y * w2y + w2z * w2z);
            w2x /= wl; w2y /= wl; w2z /= wl;
            quad(vc, pm, nm, tx - cam.x, ty - cam.y, tz - cam.z, dx, dy, dz, w1x * HALF_W, 0, w1z * HALF_W, alpha);
            quad(vc, pm, nm, tx - cam.x, ty - cam.y, tz - cam.z, dx, dy, dz, w2x * HALF_W, w2y * HALF_W, w2z * HALF_W, alpha);
            any = true;
        }
        if (any) bs.endBatch(rt);
    }

    /** (tx,ty,tz) = 창끝, d = 위로 향하는 축, w = 반폭 벡터. 앞뒤 양면을 모두 그린다 */
    private static void quad(VertexConsumer vc, Matrix4f pm, Matrix3f nm, double tx, double ty, double tz,
                             double dx, double dy, double dz, double wx, double wy, double wz, float a) {
        double[][] p = {
                {tx - wx + dx * LEN, ty - wy + dy * LEN, tz - wz + dz * LEN},  // 위-왼
                {tx - wx, ty - wy, tz - wz},                                  // 아래-왼
                {tx + wx, ty + wy, tz + wz},                                  // 아래-오
                {tx + wx + dx * LEN, ty + wy + dy * LEN, tz + wz + dz * LEN}   // 위-오
        };
        float[][] uv = {{0f, 0f}, {0f, 1f}, {1f, 1f}, {1f, 0f}};
        for (int i = 0; i < 4; i++) v(vc, pm, nm, p[i], uv[i][0], uv[i][1], a);
        for (int i = 3; i >= 0; i--) v(vc, pm, nm, p[i], uv[i][0], uv[i][1], a);
    }

    private static void v(VertexConsumer vc, Matrix4f pm, Matrix3f nm, double[] p, float u, float w, float a) {
        vc.vertex(pm, (float) p[0], (float) p[1], (float) p[2])
                .color(1f, 1f, 1f, a)
                .uv(u, w)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(LightTexture.FULL_BRIGHT)
                .normal(nm, 0f, 1f, 0f)
                .endVertex();
    }
}
