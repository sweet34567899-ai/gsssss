package com.example.elementalgaze.client;

import com.example.elementalgaze.ElementalGaze;
import com.example.elementalgaze.SummonKinds;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 소환수(푸리나의 어셔/슈발마랭/크라바레타)를 엔티티 없이 클라이언트에서만 그린다.
 * 서버가 주기적으로 보내는 위치 신호를 받아 부드럽게 따라가고, 신호가 끊기면 서서히 사라진다.
 */
@Mod.EventBusSubscriber(modid = ElementalGaze.MODID, value = Dist.CLIENT)
public final class SummonRenderer {
    private SummonRenderer() {}

    private static final String[] MODEL = {null, "water_cubee", "water_seahorse", "bs_vm_crab"};
    private static final float[] SCALE = {1f, 1.4f, 1.0f, 1.1f};
    private static final int LIFETIME_GRACE = 14;   // 마지막 신호 이후 이 틱이 지나면 제거

    private static final class Visual {
        final int kind;
        double x, y, z, px, py, pz, tx, ty, tz;
        float yaw, pyaw, tyaw, pulse;
        long born, lastUpdate;

        Visual(int kind) {
            this.kind = kind;
        }
    }

    private static final Map<Long, Visual> VISUALS = new HashMap<>();
    private static final SummonModel[] MODELS = new SummonModel[MODEL.length];
    private static final boolean[] TRIED = new boolean[MODEL.length];

    /** FxClient 가 소환 신호를 받을 때 호출 */
    public static void update(int kind, int owner, double x, double y, double z, float yaw, boolean attacking) {
        if (kind <= SummonKinds.NONE || kind >= MODEL.length) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        long key = ((long) owner << 8) | kind;
        Visual v = VISUALS.get(key);
        long now = mc.level.getGameTime();
        if (v == null) {
            v = new Visual(kind);
            v.x = v.px = v.tx = x;
            v.y = v.py = v.ty = y;
            v.z = v.pz = v.tz = z;
            v.yaw = v.pyaw = v.tyaw = yaw;
            v.born = now;
            VISUALS.put(key, v);
        }
        v.tx = x;
        v.ty = y;
        v.tz = z;
        v.tyaw = yaw;
        v.lastUpdate = now;
        if (attacking) v.pulse = 1f;
    }

    @Nullable
    private static SummonModel model(int kind) {
        if (!TRIED[kind]) {
            TRIED[kind] = true;
            MODELS[kind] = SummonModel.load(MODEL[kind]);
        }
        return MODELS[kind];
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || VISUALS.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            VISUALS.clear();
            return;
        }
        long now = mc.level.getGameTime();
        Iterator<Visual> it = VISUALS.values().iterator();
        while (it.hasNext()) {
            Visual v = it.next();
            if (now - v.lastUpdate > LIFETIME_GRACE) {
                it.remove();
                continue;
            }
            v.px = v.x;
            v.py = v.y;
            v.pz = v.z;
            v.pyaw = v.yaw;
            v.x += (v.tx - v.x) * 0.45;
            v.y += (v.ty - v.y) * 0.45;
            v.z += (v.tz - v.z) * 0.45;
            v.yaw += Mth.wrapDegrees(v.tyaw - v.yaw) * 0.3f;
            v.pulse = Math.max(0f, v.pulse - 0.12f);
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        VISUALS.clear();
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || VISUALS.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        PoseStack ps = e.getPoseStack();
        Vec3 cam = e.getCamera().getPosition();
        float pt = e.getPartialTick();
        long now = mc.level.getGameTime();
        MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();
        List<RenderType> used = new ArrayList<>();
        for (Visual v : VISUALS.values()) {
            SummonModel m = model(v.kind);
            if (m == null) continue;
            double x = Mth.lerp(pt, v.px, v.x) - cam.x;
            double y = Mth.lerp(pt, v.py, v.y) - cam.y;
            double z = Mth.lerp(pt, v.pz, v.z) - cam.z;
            float yaw = Mth.rotLerp(pt, v.pyaw, v.yaw);
            float age = now - v.born + pt;
            float since = now - v.lastUpdate + pt;
            float alpha = Mth.clamp(age / 5f, 0f, 1f) * Mth.clamp((LIFETIME_GRACE - since) / 6f, 0f, 1f);
            double speed = Math.sqrt((v.x - v.px) * (v.x - v.px) + (v.z - v.pz) * (v.z - v.pz));
            SummonModel.Anim anim = speed > 0.08 && m.anims.containsKey("walk") ? m.anims.get("walk") : m.anims.get("idle");

            ps.pushPose();
            ps.translate(x, y, z);
            ps.mulPose(Axis.YP.rotationDegrees(180f - yaw));   // 모델의 앞면(-Z)이 바라보는 방향
            float s = SCALE[v.kind] / 16f * (1f + 0.18f * v.pulse);
            ps.scale(s, s, s);
            ps.translate(-m.cx, -m.cy, -m.cz);
            RenderType rt = RenderType.entityTranslucent(m.texture);
            VertexConsumer vc = bs.getBuffer(rt);
            m.render(ps, vc, anim, age / 20f, alpha, LightTexture.FULL_BRIGHT);
            ps.popPose();
            if (!used.contains(rt)) used.add(rt);
        }
        for (RenderType rt : used) bs.endBatch(rt);
    }
}
