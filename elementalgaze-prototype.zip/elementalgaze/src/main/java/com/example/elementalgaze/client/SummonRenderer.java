package com.example.elementalgaze.client;

import com.example.elementalgaze.ClientConfig;
import com.example.elementalgaze.ClientKit;
import com.example.elementalgaze.ElementalGaze;
import com.example.elementalgaze.SummonKinds;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.client.event.RenderPlayerEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

/**
 * 소환수(푸리나의 어셔/슈발마랭/크라바레타)를 엔티티 없이 클라이언트에서만 그린다.
 * 서버가 주기적으로 보내는 위치 신호를 받아 부드럽게 따라가고, 신호가 끊기면 서서히 사라진다.
 */
@Mod.EventBusSubscriber(modid = ElementalGaze.MODID, value = Dist.CLIENT)
public final class SummonRenderer {
    private SummonRenderer() {}

    private static final String[] MODEL = {null, "water_cubee", "water_seahorse", "bs_vm_crab", "fire_dragon", "lumi", "phainon_sword"};
    private static final float[] SCALE = {1f, 1.4f, 1.0f, 1.1f, 1.15f, 0.62f, 1f};
    private static final float RIDE_LIFT = 10f / 16f * 1.15f;   // 드래곤 등 높이(모델 10px) -> 라이더를 올리는 높이
    private static final int LIFETIME_GRACE = 14;   // 마지막 신호 이후 이 틱이 지나면 제거

    private static final class Visual {
        final int kind;
        double x, y, z, px, py, pz, tx, ty, tz;
        float yaw, pyaw, tyaw, pulse;
        boolean ending;
        int owner;
        long born, lastUpdate;

        Visual(int kind) {
            this.kind = kind;
        }
    }

    /** 파이논 Q 의 낙하하는 검 (서버가 매 틱 보내는 프레임을 받아 두 틱 동안만 유지) */
    private static final class Sword {
        double x, y, z, vx, vy, vz, len;
        float hx, hz, alpha;
        long born;
    }

    private static final Map<Integer, Sword> SWORDS = new HashMap<>();
    private static final int SWORD_MODEL = 6;
    private static final float SWORD_TILT = 213f;   // 칼끝이 (스프라이트 기준) 오른쪽 아래 33도를 향하도록 모델 Z 회전

    /**
     * 칼끝이 (x,y,z) 에 오는 거대한 검을 이번 틱 프레임으로 등록한다. (vx,vy,vz) = 틱당 이동량(부드러운 보간용),
     * (hx,hz) = 낙하 평면의 가로 방향 단위벡터, len = 검 전체 길이(블록). 모델이 없으면 false.
     */
    public static boolean sword(int key, double x, double y, double z, double vx, double vy, double vz, double hx, double hz, double len, float alpha) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null || model(SWORD_MODEL) == null) return false;
        Sword w = SWORDS.computeIfAbsent(key, k -> new Sword());
        w.x = x; w.y = y; w.z = z; w.vx = vx; w.vy = vy; w.vz = vz;
        w.hx = (float) hx; w.hz = (float) hz; w.len = len; w.alpha = alpha;
        w.born = mc.level.getGameTime();
        return true;
    }

    private static final Map<Long, Visual> VISUALS = new HashMap<>();
    private static final SummonModel[] MODELS = new SummonModel[MODEL.length];
    private static final boolean[] TRIED = new boolean[MODEL.length];

    /** FxClient 가 소환 신호를 받을 때 호출 */
    public static void update(int kind, int owner, double x, double y, double z, float yaw, int state) {
        if (kind <= SummonKinds.NONE || kind >= MODEL.length) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        long key = ((long) owner << 8) | kind;
        Visual v = VISUALS.get(key);
        long now = mc.level.getGameTime();
        if (v == null) {
            v = new Visual(kind);
            v.owner = owner;
            v.x = v.px = v.tx = x;
            v.y = v.py = v.ty = y;
            v.z = v.pz = v.tz = z;
            v.yaw = v.pyaw = v.tyaw = yaw;
            v.born = now;
            VISUALS.put(key, v);
        }
        v.tx = x;
        v.ty = y;
        v.tz = z;
        v.tyaw = yaw;
        v.lastUpdate = now;
        if (state == 1) v.pulse = 1f;
        if (state == 2) {          // 종료 신호: 몇 틱 안에 서서히 사라진다
            v.ending = true;
            v.lastUpdate = now - (LIFETIME_GRACE - 5);
        }
    }

    @Nullable
    private static SummonModel model(int kind) {
        if (!TRIED[kind]) {
            TRIED[kind] = true;
            MODELS[kind] = SummonModel.load(MODEL[kind]);
        }
        return MODELS[kind];
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        tickCompanion(mc);
        if (VISUALS.isEmpty()) return;
        if (mc.level == null) {
            VISUALS.clear();
            return;
        }
        long now = mc.level.getGameTime();
        Iterator<Visual> it = VISUALS.values().iterator();
        while (it.hasNext()) {
            Visual v = it.next();
            if (now - v.lastUpdate > LIFETIME_GRACE) {
                it.remove();
                continue;
            }
            if (v.kind == SummonKinds.MOUNT) {
                v.pulse = Math.max(0f, v.pulse - 0.12f);
                continue;
            }
            if (v.kind == SummonKinds.COMPANION) {
                v.px = v.x;
                v.py = v.y;
                v.pz = v.z;
                v.pyaw = v.yaw;
                v.x += (v.tx - v.x) * 0.2;
                v.y += (v.ty - v.y) * 0.2;
                v.z += (v.tz - v.z) * 0.2;
                v.yaw += Mth.wrapDegrees(v.tyaw - v.yaw) * 0.15f;
                continue;
            }
            v.px = v.x;
            v.py = v.y;
            v.pz = v.z;
            v.pyaw = v.yaw;
            v.x += (v.tx - v.x) * 0.45;
            v.y += (v.ty - v.y) * 0.45;
            v.z += (v.tz - v.z) * 0.45;
            v.yaw += Mth.wrapDegrees(v.tyaw - v.yaw) * 0.3f;
            v.pulse = Math.max(0f, v.pulse - 0.12f);
        }
    }

    private static final java.util.Set<Integer> LIFTED = new java.util.HashSet<>();

    private static boolean riding(int playerId) {
        Visual v = VISUALS.get(((long) playerId << 8) | SummonKinds.MOUNT);
        return v != null && !v.ending;
    }

    /** 드래곤을 타고 있는 플레이어는 등 높이만큼 올려서 그린다(3인칭/다른 플레이어 시점). */
    @SubscribeEvent
    public static void onPlayerPre(RenderPlayerEvent.Pre e) {
        if (VISUALS.isEmpty() || !riding(e.getEntity().getId())) return;
        e.getPoseStack().pushPose();
        e.getPoseStack().translate(0, RIDE_LIFT, 0);
        LIFTED.add(e.getEntity().getId());
    }

    @SubscribeEvent
    public static void onPlayerPost(RenderPlayerEvent.Post e) {
        if (!LIFTED.remove(e.getEntity().getId())) return;
        e.getPoseStack().popPose();
    }

    /** 동료(루미): 서버 신호 없이 클라이언트가 직접 플레이어 오른쪽 어깨 뒤를 따라다니게 한다. 발현 후(스킬 카드 단계)에만 보인다. */
    private static void tickCompanion(Minecraft mc) {
        if (mc.player == null || mc.level == null || !ClientConfig.SHOW_COMPANION.get() || ClientKit.stage < 2
                || mc.player.isSpectator() || !mc.player.isAlive()) return;
        var p = mc.player;
        double yaw = Math.toRadians(p.getYRot());
        double fx = -Math.sin(yaw), fz = Math.cos(yaw);   // 바라보는 방향
        double rx = Math.cos(yaw), rz = Math.sin(yaw);     // 오른쪽? (마인크래프트 좌표에서 왼쪽 방향의 반대)
        double bob = Math.sin((mc.level.getGameTime()) * 0.12) * 0.08;
        double x = p.getX() - rx * 0.85 - fx * 0.35, z = p.getZ() - rz * 0.85 - fz * 0.35;
        double y = p.getY() + 1.75 + bob;
        long key = ((long) p.getId() << 8) | SummonKinds.COMPANION;
        Visual v = VISUALS.get(key);
        long now = mc.level.getGameTime();
        if (v == null) {
            v = new Visual(SummonKinds.COMPANION);
            v.owner = p.getId();
            v.x = v.px = v.tx = x;
            v.y = v.py = v.ty = y;
            v.z = v.pz = v.tz = z;
            v.yaw = v.pyaw = v.tyaw = p.getYRot();
            v.born = now;
            VISUALS.put(key, v);
        }
        v.tx = x;
        v.ty = y;
        v.tz = z;
        v.tyaw = p.getYRot();
        v.lastUpdate = now;
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        VISUALS.clear();
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || (VISUALS.isEmpty() && SWORDS.isEmpty())) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        PoseStack ps = e.getPoseStack();
        Vec3 cam = e.getCamera().getPosition();
        float pt = e.getPartialTick();
        long now = mc.level.getGameTime();
        MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();
        List<RenderType> used = new ArrayList<>();
        for (Visual v : VISUALS.values()) {
            SummonModel m = model(v.kind);
            if (m == null) continue;
            double x, y, z;
            float yaw;
            boolean mount = v.kind == SummonKinds.MOUNT;
            boolean moving;
            if (mount) {
                Entity owner = mc.level.getEntity(v.owner);
                if (owner == null) continue;
                if (owner == mc.player && mc.options.getCameraType().isFirstPerson()) continue;   // 1인칭에서는 시야를 가리지 않게 숨긴다
                x = Mth.lerp(pt, owner.xo, owner.getX()) - cam.x;
                y = Mth.lerp(pt, owner.yo, owner.getY()) - cam.y;
                z = Mth.lerp(pt, owner.zo, owner.getZ()) - cam.z;
                yaw = owner instanceof LivingEntity le ? Mth.rotLerp(pt, le.yBodyRotO, le.yBodyRot) : owner.getYRot();
                double dx = owner.getX() - owner.xo, dz = owner.getZ() - owner.zo;
                moving = dx * dx + dz * dz > 0.0036 || !owner.onGround();
            } else {
                x = Mth.lerp(pt, v.px, v.x) - cam.x;
                y = Mth.lerp(pt, v.py, v.y) - cam.y;
                z = Mth.lerp(pt, v.pz, v.z) - cam.z;
                yaw = Mth.rotLerp(pt, v.pyaw, v.yaw);
                double sx = v.x - v.px, sz = v.z - v.pz;
                moving = Math.sqrt(sx * sx + sz * sz) > 0.08;
            }
            float age = now - v.born + pt;
            float since = now - v.lastUpdate + pt;
            float alpha = Mth.clamp(age / 5f, 0f, 1f) * Mth.clamp((LIFETIME_GRACE - since) / 6f, 0f, 1f);
            SummonModel.Anim anim = moving && m.anims.containsKey("walk") ? m.anims.get("walk") : m.anims.get("idle");

            ps.pushPose();
            ps.translate(x, y, z);
            ps.mulPose(Axis.YP.rotationDegrees(180f - yaw));   // 모델의 앞면(-Z)이 바라보는 방향
            float s = SCALE[v.kind] / 16f * (1f + 0.18f * v.pulse);
            ps.scale(s, s, s);
            if (!mount) ps.translate(-m.cx, -m.cy, -m.cz);   // 드래곤은 발밑(모델 원점)이 기준
            RenderType rt = RenderType.entityTranslucent(m.texture);
            VertexConsumer vc = bs.getBuffer(rt);
            m.render(ps, vc, anim, age / 20f, alpha, LightTexture.FULL_BRIGHT);
            ps.popPose();
            if (!used.contains(rt)) used.add(rt);
        }
        renderSwords(mc, ps, cam, pt, now, bs, used);
        for (RenderType rt : used) bs.endBatch(rt);
    }

    private static void renderSwords(Minecraft mc, PoseStack ps, Vec3 cam, float pt, long now, MultiBufferSource.BufferSource bs, List<RenderType> used) {
        if (SWORDS.isEmpty()) return;
        SummonModel m = model(SWORD_MODEL);
        Iterator<Sword> it = SWORDS.values().iterator();
        while (it.hasNext()) {
            Sword w = it.next();
            if (now - w.born > 2) {
                it.remove();
                continue;
            }
            if (m == null) continue;
            float t = Math.min(1.5f, now - w.born + pt);
            double tipY = m.cy + m.sizeY / 2.0;               // 모델에서 칼끝의 y (px)
            float blocksPerPx = (float) (w.len / Math.max(1f, m.sizeY));
            float fade = w.alpha * Mth.clamp((3f - (now - w.born + pt)) / 1.5f, 0f, 1f);
            ps.pushPose();
            ps.translate(w.x + w.vx * t - cam.x, w.y + w.vy * t - cam.y, w.z + w.vz * t - cam.z);
            ps.mulPose(Axis.YP.rotation((float) Math.atan2(w.hz, -w.hx)));   // 모델의 +X 가 낙하 평면의 가로(-h) 방향
            ps.mulPose(Axis.ZP.rotationDegrees(SWORD_TILT));
            ps.scale(blocksPerPx, blocksPerPx, blocksPerPx);
            ps.translate(0, -tipY, 0);                         // 칼끝을 기준점으로
            RenderType rt = RenderType.entityTranslucent(m.texture);
            m.render(ps, bs.getBuffer(rt), null, 0f, fade, LightTexture.FULL_BRIGHT);
            ps.popPose();
            if (!used.contains(rt)) used.add(rt);
        }
    }
}
