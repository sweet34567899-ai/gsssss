package com.example.elementalgaze.client;

import com.example.elementalgaze.ElementalGaze;
import com.example.elementalgaze.FxPacket;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.ParticleStatus;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.texture.MissingTextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;

/**
 * 클라이언트 연출 레시피. 서버가 보낸 신호(FxPacket)를 원소별 파티클 묶음으로 바꿔서 그린다.
 * 텍스처: assets/elementalgaze/textures/particle/<원소>_glow|ring|spark|sigil 및 원소별 모양, 공용 글로우/연기 등.
 * 파티클 설정(전체/감소/최소)에 따라 개수가 자동으로 줄어든다.
 */
public final class FxClient {
    private FxClient() {}

    private static final String[] ELN = {"pyro", "hydro", "electro", "cryo", "anemo", "geo", "dendro"};
    private static final int[] CORE = {0xFFE9A0, 0xC8EEFF, 0xF0DCFF, 0xEAFFFF, 0xE6FFF4, 0xFFF3C0, 0xE9FFC8};
    private static final int[] EDGE = {0xFF5A1E, 0x2F7CFF, 0xA55CFF, 0x74C8FF, 0x5BE0B0, 0xE8A82C, 0x62BC3C};
    /** 원소별 대표 모양. "~"로 시작하면 흰색 공용 텍스처를 원소 색으로 물들여 쓴다. */
    private static final String[][] ACC = {
            {"pyro_flame", "~flame_a", "~flame_b"},
            {"hydro_drop", "hydro_bubble"},
            {"electro_bolt", "electro_static"},
            {"cryo_crystal", "cryo_flake"},
            {"anemo_swirl", "anemo_puff", "~leaf_wind"},
            {"geo_shard", "geo_gem", "~rock"},
            {"dendro_leaf", "dendro_spore", "~petal"}};
    /** 원소별 움직임: {중력(음수=떠오름), 감속, 회전} */
    private static final double[][] PHYS = {
            {-0.15, 0.96, 0.03}, {0.35, 0.97, 0.05}, {0.0, 0.80, 0.0}, {0.05, 0.95, 0.08},
            {-0.02, 0.94, 0.12}, {0.50, 0.97, 0.15}, {0.06, 0.95, 0.10}};
    private static final boolean[] ADD_ACC = {true, false, true, false, false, false, false};
    private static final int WHITE = 0xFFFFFF;
    private static final Map<String, ResourceLocation> RL = new HashMap<>();
    private static final Set<String> WARNED = new HashSet<>();

    // 한 번의 handle 동안만 쓰는 상태 (클라이언트 스레드 전용)
    private static Minecraft mc;
    private static ClientLevel lvl;
    private static RandomSource rnd;
    private static TextureAtlas atlas;
    private static float dens;
    private static int el;

    /** 서버 신호 없이 클라이언트 틱에서 직접 파티클을 낼 때 필요한 정적 상태를 준비한다 */
    private static boolean prepTick() {
        Minecraft m = Minecraft.getInstance();
        if (m.level == null || m.player == null) return false;
        mc = m;
        lvl = m.level;
        el = 1;
        rnd = lvl.random;
        atlas = (TextureAtlas) m.getTextureManager().getTexture(TextureAtlas.LOCATION_PARTICLES);
        ParticleStatus st = m.options.particles().get();
        dens = st == ParticleStatus.ALL ? 1f : (st == ParticleStatus.DECREASED ? 0.5f : 0.2f);
        return true;
    }

    /** 헤엄치는 고래 주변의 별빛/물방울 (WhaleRenderer 가 매 틱 호출). t = 진행도 0~1 */
    static void whaleTrail(double x, double y, double z, double len, float t) {
        if (!prepTick()) return;
        if (mc.player.distanceToSqr(x, y, z) > 80.0 * 80.0) return;
        emit("glow", x, y, z, 0, 0, 0, 5, len * 0.35, len * 0.45, 0x9FDFFF, 0x4C8CFF, 0.10, true, 0, 1, 0, false);
        for (int i = 0; i < cnt(3); i++) {
            double a = ru() * 6.2832, d = len * 0.45 * ru();
            int c = rnd.nextBoolean() ? 0xFFFFFF : 0xBFE8FF;
            emit(i % 2 == 0 ? "star4" : "spark", x + Math.cos(a) * d, y + rr(len * 0.18), z + Math.sin(a) * d, rr(0.02), -0.01 - ru() * 0.03, rr(0.02),
                    22, 0.22 + ru() * 0.25, 0.03, c, c, 0.95, true, 0, 0.97, rr(0.08), false);
        }
        if (rnd.nextInt(3) == 0) {
            emit("hydro_bubble", x + rr(len * 0.3), y + rr(len * 0.15), z + rr(len * 0.3), 0, 0.02, 0, 24, 0.25, 0.4, WHITE, WHITE, 0.8, false, -0.01, 0.98, 0.02, false);
        }
        if (t < 0.12) {   // 솟아오르는 순간의 물보라
            for (int i = 0; i < cnt(6); i++) {
                emit(i % 2 == 0 ? "hydro_drop" : "hydro_bubble", x + rr(len * 0.3), y - 0.2, z + rr(len * 0.3), rr(0.12), 0.18 + ru() * 0.22, rr(0.12),
                        20, 0.35, 0.12, WHITE, WHITE, 0.9, false, 0.03, 0.95, 0.03, false);
            }
        }
    }

    public static void handle(FxPacket m) {
        mc = Minecraft.getInstance();
        lvl = mc.level;
        if (lvl == null || mc.player == null) return;
        if (m.el < 0 || m.el >= ELN.length) return;
        if (mc.player.distanceToSqr(m.x, m.y, m.z) > 80.0 * 80.0) return;
        el = m.el;
        rnd = lvl.random;
        atlas = (TextureAtlas) mc.getTextureManager().getTexture(TextureAtlas.LOCATION_PARTICLES);
        ParticleStatus st = mc.options.particles().get();
        dens = st == ParticleStatus.ALL ? 1f : (st == ParticleStatus.DECREASED ? 0.5f : 0.2f);
        switch (m.kind) {
            case FxPacket.BURST -> burst(m.x, m.y, m.z, m.a);
            case FxPacket.RING -> ring(m.x, m.y, m.z, m.a);
            case FxPacket.SPIRAL -> spiral(m.x, m.y, m.z, m.a, m.b, m.vx, m.vy);
            case FxPacket.COLUMN -> column(m.x, m.y, m.z, m.a);
            case FxPacket.LINE -> {
                if (m.b > 0.5f) akashaBeam(m.x, m.y, m.z, m.vx, m.vy, m.vz);
                else if (el == 2) bolt(m.x, m.y, m.z, m.vx, m.vy, m.vz, 0.35, 0.3);
                else beam(m.x, m.y, m.z, m.vx, m.vy, m.vz);
            }
            case FxPacket.STRIKE -> strike(m.x, m.y, m.z, m.a);
            case FxPacket.HIT -> hit(m.x, m.y, m.z);
            case FxPacket.STREAM -> stream(m.x, m.y, m.z);
            case FxPacket.ORBIT -> orbit(m.x, m.y, m.z);
            case FxPacket.SUMMON -> summon(m);
            case FxPacket.WALL -> wall(m.x, m.y, m.z, m.vx, m.vz);
            case FxPacket.SLASH -> {
                if (m.b > 1.5f) thrust(m.x, m.y, m.z, m.vx, m.vy, m.vz);
                else if (m.b > 0.5f) wideSlash(m.x, m.y, m.z, m.vx, m.vy, m.vz);
                else slash(m.x, m.y, m.z, m.vx, m.vy, m.vz);
            }
            case FxPacket.METEOR -> meteor(m.x, m.y, m.z, m.a);
            case FxPacket.SIGIL -> {
                if (m.b > 0.5f) sunGlyph(m.x, m.y, m.z, m.a);
                else sigil(m.x, m.y, m.z, m.a, 18, 0.85);
            }
            case FxPacket.AKASHA -> akasha(m.x, m.y, m.z, m.a, Math.round(m.b), Math.round(m.vx));
            case FxPacket.MELODY -> melody(m.x, m.y, m.z, m.a, Math.round(m.b));
            case FxPacket.BLACKHOLE -> blackhole(m.x, m.y, m.z, m.a, Math.round(m.b));
            case FxPacket.TIDE -> tide(m.x, m.y, m.z, m.a, Math.round(m.b));
            case FxPacket.PHAINON -> phainon(m, Math.round(m.b));
            case FxPacket.SUNSTONE -> {
                if (m.vy > 0.5f) sunHalo(m.x, m.y, m.z, m.a, Math.round(m.b), Math.toRadians(m.vx));
                else sunStone(m.x, m.y, m.z, m.a, Math.round(m.b));
            }
            case FxPacket.SUNPILLAR -> sunPillar(m.x, m.y, m.z, m.a, m.b > 0.5f);
            default -> { }
        }
    }

    // ================= 도구 =================
    private static double rr(double a) { return (rnd.nextDouble() - 0.5) * 2.0 * a; }

    private static double ru() { return rnd.nextDouble(); }

    private static int cnt(double c) { return Math.max(1, Math.round((float) (c * dens))); }

    private static String t(String kind) { return ELN[el] + "_" + kind; }

    private static ResourceLocation rl(String name) {
        return RL.computeIfAbsent(name, k -> new ResourceLocation(ElementalGaze.MODID, k));   // 파티클 아틀라스는 접두어 없이 등록된다
    }

    private static void emit(String tex, double x, double y, double z, double vx, double vy, double vz, int life,
                             double s0, double s1, int c0, int c1, double a, boolean add,
                             double g, double drag, double spin, boolean flat) {
        emitRoll(tex, x, y, z, vx, vy, vz, life, s0, s1, c0, c1, a, add, g, drag, spin, flat, rnd.nextFloat() * 6.2832f);
    }

    /** emit 과 같지만 시작 회전각(roll)을 직접 정한다. 바닥에 눕는 검기/문양의 방향을 맞출 때 쓴다. */
    private static void emitRoll(String tex, double x, double y, double z, double vx, double vy, double vz, int life,
                                 double s0, double s1, int c0, int c1, double a, boolean add,
                                 double g, double drag, double spin, boolean flat, float roll) {
        emitP(tex, x, y, z, vx, vy, vz, life, s0, s1, c0, c1, a, add, g, drag, spin, flat, roll);
    }

    /** 세워서 그리는 평면 파티클(등 뒤 후광). yawRad = 바라보는 방향 */
    private static void emitUpright(String tex, double x, double y, double z, int life, double s0, double s1,
                                    double a, double spin, double yawRad) {
        FxParticle p = emitP(tex, x, y, z, 0, 0, 0, life, s0, s1, WHITE, WHITE, a, true, 0, 1, spin, true, 0f);
        if (p != null) p.vertical((float) yawRad);
    }

    private static FxParticle emitP(String tex, double x, double y, double z, double vx, double vy, double vz, int life,
                                    double s0, double s1, int c0, int c1, double a, boolean add,
                                    double g, double drag, double spin, boolean flat, float roll) {
        TextureAtlasSprite sp = atlas.getSprite(rl(tex));
        if (sp == atlas.getSprite(MissingTextureAtlasSprite.getLocation())) {
            if (WARNED.add(tex)) ElementalGaze.LOGGER.warn("Missing particle sprite: {}", rl(tex));
            return null;
        }
        FxParticle fp = new FxParticle(lvl, x, y, z, vx, vy, vz, life, (float) s0, (float) s1, c0, c1, (float) a, add,
                (float) g, (float) drag, (float) spin, roll, flat, sp);
        mc.particleEngine.add(fp);
        return fp;
    }

    /** 원소 색이 입혀진 글로우 */
    private static void glowE(double x, double y, double z, double vx, double vy, double vz, int life, double s0, double s1, double a) {
        emit(t("glow"), x, y, z, vx, vy, vz, life, s0, s1, WHITE, WHITE, a, true, 0, 1, 0, false);
    }

    private static void sparkE(double x, double y, double z, double vx, double vy, double vz, int life, double s0, double s1, double a) {
        emit(t("spark"), x, y, z, vx, vy, vz, life, s0, s1, WHITE, WHITE, a, true, 0.1, 0.88, 0, false);
    }

    /** 백열 섬광: 흰색에서 원소 색으로 */
    private static void flash(double x, double y, double z, int life, double s0, double s1, double a) {
        emit("glow", x, y, z, 0, 0, 0, life, s0, s1, WHITE, CORE[el], a, true, 0, 1, 0, false);
    }

    private static void flatRing(double x, double y, double z, double r0, double r1, int life, double a) {
        emit(t("ring"), x, y + 0.06, z, 0, 0, 0, life, r0, r1, WHITE, WHITE, a, true, 0, 1, 0, true);
    }

    private static void sigil(double x, double y, double z, double r, int life, double a) {
        emit(t("sigil"), x, y + 0.05, z, 0, 0, 0, life, r * 0.55, r, WHITE, WHITE, a, true, 0, 1, 0.03, true);
    }

    /** 원소별 대표 모양 한 개 (원소마다 물리와 합성 방식이 다르다) */
    private static void accent(double x, double y, double z, double vx, double vy, double vz, int life, double s0, double s1, double a) {
        String[] list = ACC[el];
        String tex = list[rnd.nextInt(list.length)];
        boolean tinted = tex.startsWith("~");
        if (tinted) tex = tex.substring(1);
        double[] ph = PHYS[el];
        emit(tex, x, y, z, vx, vy, vz, life, s0, s1, tinted ? CORE[el] : WHITE, tinted ? EDGE[el] : WHITE, a,
                ADD_ACC[el], ph[0], ph[1], rr(ph[2]), false);
    }

    // ================= 폭발 =================
    private static void burst(double x, double y, double z, double r) {
        r = Math.max(1.0, r);
        flash(x, y + 0.8, z, 7, 0.6, r * 1.3, 0.9);
        glowE(x, y + 0.5, z, 0, 0.02, 0, 12, 0.4, r * 0.9, 0.7);
        flatRing(x, y, z, 0.3, r * 1.1, 10, 0.95);
        flatRing(x, y, z, 0.2, r * 0.8, 14, 0.6);
        if (r >= 2.5) sigil(x, y, z, r * 0.9, 20, 0.8);
        switch (el) {
            case 0 -> burstPyro(x, y, z, r);
            case 1 -> burstHydro(x, y, z, r);
            case 2 -> burstElectro(x, y, z, r);
            case 3 -> burstCryo(x, y, z, r);
            case 4 -> burstAnemo(x, y, z, r);
            case 5 -> burstGeo(x, y, z, r);
            default -> burstDendro(x, y, z, r);
        }
    }

    private static void burstPyro(double x, double y, double z, double r) {
        int fl = cnt(8 + r * 6);
        for (int i = 0; i < fl; i++) {
            double a = ru() * Math.PI * 2, d = Math.sqrt(ru()) * r * 0.8;
            accent(x + Math.cos(a) * d, y + 0.1, z + Math.sin(a) * d, rr(0.02), 0.08 + ru() * 0.12, rr(0.02),
                    16 + rnd.nextInt(10), 0.5 + ru() * 0.4, 0.1, 0.95);
        }
        int em = cnt(6 + r * 4);
        for (int i = 0; i < em; i++) {
            emit("pyro_ember", x, y + 0.4, z, rr(0.25), 0.15 + ru() * 0.25, rr(0.25), 24 + rnd.nextInt(14),
                    0.16, 0.05, WHITE, WHITE, 1.0, true, 0.5, 0.97, 0, false);
        }
        int sm = cnt(r * 1.5);
        for (int i = 0; i < sm; i++) {
            emit("smoke", x + rr(r * 0.4), y + 0.5, z + rr(r * 0.4), 0, 0.04, 0, 30, 0.6, 1.6, 0x444444, 0x111111, 0.45,
                    false, -0.02, 0.98, 0.01, false);
        }
    }

    private static void burstHydro(double x, double y, double z, double r) {
        emit("water_ring", x, y + 0.07, z, 0, 0, 0, 12, r * 0.3, r * 1.05, WHITE, WHITE, 0.9, true, 0, 1, 0.06, true);
        emit("water_ring_b", x, y + 0.09, z, 0, 0, 0, 16, r * 0.2, r * 0.8, WHITE, WHITE, 0.7, true, 0, 1, -0.05, true);
        int dr = cnt(10 + r * 6);
        for (int i = 0; i < dr; i++) {
            accent(x + rr(r * 0.5), y + 0.3, z + rr(r * 0.5), rr(0.15), 0.25 + ru() * 0.3, rr(0.15), 22, 0.28, 0.1, 0.95);
        }
        int bub = cnt(6 + r * 2);
        for (int i = 0; i < bub; i++) {
            emit("hydro_bubble", x + rr(r * 0.5), y + 0.3, z + rr(r * 0.5), rr(0.03), 0.04 + ru() * 0.04, rr(0.03), 28,
                    0.25, 0.35, WHITE, WHITE, 0.8, false, -0.03, 0.97, 0.02, false);
        }
        int ms = cnt(r * 2);
        for (int i = 0; i < ms; i++) {
            emit("smoke", x + rr(r * 0.5), y + 0.4, z + rr(r * 0.5), 0, 0.03, 0, 24, 0.6, 1.4, 0xDFF4FF, 0xA9D8FF, 0.3,
                    false, -0.01, 0.98, 0, false);
        }
    }

    private static void burstElectro(double x, double y, double z, double r) {
        int b = cnt(8 + r * 3);
        for (int i = 0; i < b; i++) {
            double a = ru() * Math.PI * 2, sp = 0.3 + ru() * 0.15;
            accent(x, y + 0.8 + rr(0.4), z, Math.cos(a) * sp, rr(0.08), Math.sin(a) * sp, 6 + rnd.nextInt(3), 0.9, 0.5, 1.0);
        }
        int s = cnt(12 + r * 5);
        for (int i = 0; i < s; i++) {
            sparkE(x, y + 0.8, z, rr(0.35), rr(0.3) + 0.05, rr(0.35), 8 + rnd.nextInt(7), 0.3, 0.05, 1.0);
        }
        int arcs = cnt(2 + r * 0.5);
        for (int i = 0; i < arcs; i++) {
            double a = ru() * Math.PI * 2, d = r * (0.5 + ru() * 0.5);
            bolt(x, y + 1.0, z, x + Math.cos(a) * d, y + 0.3, z + Math.sin(a) * d, 0.5, 0.2);
        }
    }

    private static void burstCryo(double x, double y, double z, double r) {
        int s = cnt(10 + r * 5);
        for (int i = 0; i < s; i++) {
            accent(x + rr(r * 0.5), y + 0.8 + ru(), z + rr(r * 0.5), rr(0.06), 0.02 + ru() * 0.05, rr(0.06),
                    26 + rnd.nextInt(14), 0.35, 0.15, 0.9);
        }
        int sh = cnt(6 + r * 3);
        for (int i = 0; i < sh; i++) {
            accent(x, y + 0.5, z, rr(0.3), 0.1 + ru() * 0.25, rr(0.3), 20, 0.4, 0.2, 0.95);
        }
        int ms = cnt(r * 2);
        for (int i = 0; i < ms; i++) {
            emit("smoke", x + rr(r * 0.5), y + 0.4, z + rr(r * 0.5), 0, 0.02, 0, 30, 0.7, 1.5, 0xDDF6FF, 0xA8E4FF, 0.35,
                    false, -0.01, 0.98, 0, false);
        }
    }

    private static void burstAnemo(double x, double y, double z, double r) {
        int sw = cnt(8 + r * 3);
        for (int i = 0; i < sw; i++) {
            double a = ru() * Math.PI * 2, d = ru() * r * 0.6, cs = Math.cos(a), sn = Math.sin(a);
            emit("anemo_swirl", x + cs * d, y + 0.3 + ru() * 0.8, z + sn * d, -sn * 0.18 + cs * 0.05, 0.05, cs * 0.18 + sn * 0.05,
                    16, 0.6, 0.9, WHITE, WHITE, 0.8, true, 0, 0.95, 0.15, false);
        }
        int lf = cnt(6 + r * 2);
        for (int i = 0; i < lf; i++) {
            accent(x + rr(r * 0.4), y + 0.3, z + rr(r * 0.4), rr(0.12), 0.1 + ru() * 0.1, rr(0.12), 28, 0.3, 0.25, 0.9);
        }
        int ms = cnt(r * 2);
        for (int i = 0; i < ms; i++) {
            emit("smoke", x + rr(r * 0.5), y + 0.4, z + rr(r * 0.5), rr(0.05), 0.03, rr(0.05), 22, 0.6, 1.4, 0xFFFFFF, 0xDFFFF4,
                    0.3, false, -0.01, 0.97, 0, false);
        }
    }

    private static void burstGeo(double x, double y, double z, double r) {
        int rk = cnt(8 + r * 5);
        for (int i = 0; i < rk; i++) {
            accent(x + rr(r * 0.3), y + 0.2, z + rr(r * 0.3), rr(0.2), 0.3 + ru() * 0.3, rr(0.2), 26, 0.3, 0.2, 1.0);
        }
        int gm = cnt(4 + r * 2);
        for (int i = 0; i < gm; i++) {
            emit("geo_gem", x + rr(r * 0.3), y + 0.5, z + rr(r * 0.3), rr(0.15), 0.2 + ru() * 0.2, rr(0.15), 22,
                    0.25, 0.2, WHITE, WHITE, 1.0, true, 0.4, 0.97, rr(0.2), false);
        }
        int ds = cnt(r * 3);
        for (int i = 0; i < ds; i++) {
            emit("smoke", x + rr(r * 0.5), y + 0.3, z + rr(r * 0.5), rr(0.04), 0.03, rr(0.04), 26, 0.7, 1.7, 0xB8975A, 0x6B5530,
                    0.5, false, -0.01, 0.98, 0.01, false);
        }
    }

    private static void burstDendro(double x, double y, double z, double r) {
        int lf = cnt(10 + r * 5);
        for (int i = 0; i < lf; i++) {
            accent(x + rr(r * 0.5), y + 1 + ru() * 1.5, z + rr(r * 0.5), rr(0.05), -0.01, rr(0.05), 34, 0.35, 0.25, 1.0);
        }
        int gl = cnt(10);
        for (int i = 0; i < gl; i++) {
            sparkE(x + rr(r * 0.5), y + 0.5 + ru() * 1.2, z + rr(r * 0.5), 0, 0.03, 0, 14, 0.25, 0.05, 0.9);
        }
    }

    // ================= 도형 =================
    private static void ring(double x, double y, double z, double r) {
        flatRing(x, y, z, r * 0.92, r, 8, 0.55);
        if (r >= 2.0) sigil(x, y, z, r, 12, 0.3);   // 필드가 반복 호출하면 회전하는 마법진이 이어져 보인다
    }

    private static void spiral(double x, double y, double z, double radius, double height, double turns, double phase) {
        int n = cnt(18);
        for (int i = 0; i < n; i++) {
            double tt = (double) i / n;
            double a = phase + tt * turns * Math.PI * 2;
            double rad = radius * (0.35 + 0.65 * tt);
            double cs = Math.cos(a), sn = Math.sin(a);
            double px = x + cs * rad, py = y + tt * height, pz = z + sn * rad;
            glowE(px, py, pz, -sn * 0.1, 0.03, cs * 0.1, 14, 0.28, 0.1, 0.85);
            if (i % 3 == 0) accent(px, py, pz, -sn * 0.08, 0.04, cs * 0.08, 16, 0.45, 0.2, 0.9);
        }
    }

    private static void column(double x, double y, double z, double h) {
        for (double yy = 0; yy <= h; yy += 0.5 / Math.max(0.3, dens)) {
            glowE(x + rr(0.12), y + yy, z + rr(0.12), 0, 0.05, 0, 14, 0.5, 0.2, 0.55);
        }
        int a = cnt(h);
        for (int i = 0; i < a; i++) {
            accent(x + rr(0.25), y + ru() * h * 0.3, z + rr(0.25), 0, 0.12 + ru() * 0.1, 0, 18, 0.4, 0.15, 0.9);
        }
        flash(x, y + 0.3, z, 10, 0.8, 1.6, 0.7);
        sigil(x, y, z, 1.4, 12, 0.5);
    }

    private static void beam(double ax, double ay, double az, double bx, double by, double bz) {
        double dx = bx - ax, dy = by - ay, dz = bz - az;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 0.1) return;
        double ux = dx / len, uy = dy / len, uz = dz / len;
        double stepLen = 0.6 / Math.max(0.3, dens);
        int steps = (int) (len / stepLen);
        for (int i = 0; i <= steps; i++) {
            double tt = steps == 0 ? 0 : (double) i / steps;
            double px = ax + dx * tt, py = ay + dy * tt, pz = az + dz * tt;
            glowE(px, py, pz, ux * 0.04, uy * 0.04, uz * 0.04, 9, 0.3, 0.12, 0.9);
            if (i % 3 == 0) accent(px, py, pz, ux * 0.05, uy * 0.05, uz * 0.05, 10, 0.4, 0.15, 0.9);
        }
        flash(bx, by, bz, 4, 0.4, 0.8, 0.8);
    }

    /** 지그재그 번개. 밝은 흰 심지 + 보랏빛 번짐 */
    private static void bolt(double ax, double ay, double az, double bx, double by, double bz, double jitter, double size) {
        double dx = bx - ax, dy = by - ay, dz = bz - az;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 0.1) return;
        int segs = Math.max(2, (int) (len / 1.1));
        double px = ax, py = ay, pz = az;
        for (int i = 1; i <= segs; i++) {
            double tt = (double) i / segs;
            boolean last = i == segs;
            double nx = ax + dx * tt + (last ? 0 : rr(jitter));
            double ny = ay + dy * tt + (last ? 0 : rr(jitter * 0.4));
            double nz = az + dz * tt + (last ? 0 : rr(jitter));
            for (int k = 0; k <= 3; k++) {
                double u = k / 3.0;
                double sx = px + (nx - px) * u, sy = py + (ny - py) * u, sz = pz + (nz - pz) * u;
                emit("glow", sx, sy, sz, 0, 0, 0, 5, size, size * 0.5, WHITE, CORE[2], 0.95, true, 0, 1, 0, false);
                emit(t("glow"), sx, sy, sz, 0, 0, 0, 7, size * 2.4, size, WHITE, WHITE, 0.45, true, 0, 1, 0, false);
            }
            sparkE(nx, ny, nz, rr(0.05), rr(0.05), rr(0.05), 7, size * 1.6, 0.1, 1.0);
            px = nx;
            py = ny;
            pz = nz;
        }
    }

    // ================= 일격 / 타격 =================
    private static void strike(double x, double y, double z, double r) {
        switch (el) {
            case 2 -> {
                bolt(x + rr(0.4), y + 9, z + rr(0.4), x, y, z, 0.9, 0.38);
                int br = cnt(2);
                for (int i = 0; i < br; i++) {
                    double by = y + 2 + ru() * 5;
                    bolt(x, by, z, x + rr(2.5), by - 1.5 - ru() * 2, z + rr(2.5), 0.5, 0.2);
                }
            }
            case 5 -> {
                int n = cnt(12);
                for (int i = 0; i < n; i++) {
                    double px = x + rr(r * 0.6), py = y + 4 + ru() * 5, pz = z + rr(r * 0.6);
                    if (ru() < 0.5) {
                        emit("geo_gem", px, py, pz, 0, -0.5, 0, 10, 0.34, 0.3, WHITE, WHITE, 1.0, false, 0.2, 1.0, rr(0.2), false);
                    } else {
                        emit("rock", px, py, pz, 0, -0.5, 0, 10, 0.34, 0.3, 0xE9C46A, 0x8C6A28, 1.0, false, 0.2, 1.0, rr(0.2), false);
                    }
                }
                column(x, y, z, 5.0);
            }
            case 1 -> {
                int n = cnt(14);
                for (int i = 0; i < n; i++) {
                    emit("streak", x + rr(0.5), y + 4 + ru() * 5, z + rr(0.5), 0, -0.6, 0, 8, 0.5, 0.5, WHITE, EDGE[1], 0.8,
                            true, 0, 1, 0, false);
                }
                column(x, y, z, 4.0);
            }
            default -> column(x, y, z, 5.0);
        }
        burst(x, y, z, r);
    }

    private static void hit(double x, double y, double z) {
        flash(x, y, z, 4, 0.5, 0.9, 0.8);
        int s = cnt(4);
        for (int i = 0; i < s; i++) sparkE(x, y, z, rr(0.2), rr(0.2) + 0.05, rr(0.2), 8, 0.28, 0.04, 1.0);
        int a = cnt(2);
        for (int i = 0; i < a; i++) accent(x, y, z, rr(0.15), rr(0.15) + 0.05, rr(0.15), 12, 0.25, 0.1, 0.95);
    }

    private static void stream(double x, double y, double z) {
        accent(x, y, z, rr(0.04), rr(0.04), rr(0.04), 10, 0.3, 0.1, 0.8);
        glowE(x, y, z, 0, 0, 0, 6, 0.25, 0.1, 0.6);
    }

    private static void orbit(double x, double y, double z) {
        glowE(x, y, z, 0, 0, 0, 6, 0.28, 0.1, 0.9);
        accent(x, y, z, rr(0.02), rr(0.02), rr(0.02), 9, 0.2, 0.08, 0.9);
        emit("ember", x, y, z, rr(0.02), rr(0.02), rr(0.02), 8, 0.12, 0.03, WHITE, CORE[el], 0.9, true, 0, 0.95, 0, false);
    }

    private static void summon(FxPacket m) {
        double x = m.x, y = m.y, z = m.z;
        int kind = Math.round(m.a);
        if (kind > 0) {
            // 모델 소환체: 모델은 SummonRenderer 가 그리고, 여기서는 은은한 빛만 더한다
            int state = Math.round(m.b);
            SummonRenderer.update(kind, Math.round(m.vx), x, y, z, m.vy, state);
            if (kind == com.example.elementalgaze.SummonKinds.MOUNT) {
                // 탑승 드래곤: 발밑에서 불씨와 불꽃이 흩날린다
                for (int i = 0; i < 4; i++) {
                    double ox = rr(0.9), oz = rr(0.9);
                    glowE(x + ox, y + 0.25, z + oz, rr(0.01), 0.03, rr(0.01), 10, 0.7, 0.2, 0.3);
                    emit("ember", x + ox, y + 0.2, z + oz, rr(0.02), 0.05, rr(0.02), 14, 0.14, 0.03, WHITE, CORE[el], 0.9, true, 0, 1, 0.05, false);
                }
                if (state == 1) accent(x, y + 0.5, z, rr(0.03), 0.04, rr(0.03), 10, 0.35, 0.1, 0.9);
                return;
            }
            glowE(x, y - 0.1, z, 0, 0, 0, 6, 0.9, 0.5, 0.2);
            if (state == 1) accent(x, y, z, rr(0.03), rr(0.03), rr(0.03), 9, 0.25, 0.1, 0.9);
            return;
        }
        flash(x, y, z, 6, 0.55, 0.45, 0.8);
        glowE(x, y, z, 0, 0, 0, 6, 0.7, 0.55, 0.5);
        emit("spark", x, y, z, 0, 0, 0, 6, 0.4, 0.2, WHITE, CORE[el], 0.9, true, 0, 1, 0.12, false);
        accent(x + rr(0.2), y + rr(0.2), z + rr(0.2), rr(0.02), rr(0.02), rr(0.02), 8, 0.25, 0.1, 0.9);
        if (el == 2) bolt(x + rr(0.4), y + rr(0.4), z + rr(0.4), x + rr(0.4), y + rr(0.4), z + rr(0.4), 0.1, 0.07);
    }

    private static void wall(double cx, double cy, double cz, double sx, double sz) {
        for (int xi = -2; xi <= 2; xi++) {
            for (int yi = 0; yi < 3; yi++) {
                double px = cx + sx * xi, py = cy + 0.3 + yi * 0.9, pz = cz + sz * xi;
                glowE(px, py, pz, 0, 0, 0, 12, 0.6, 0.6, 0.3);
                if (((xi + yi) & 1) == 0) accent(px, py, pz, 0, 0, 0, 12, 0.4, 0.4, 0.7);
            }
        }
    }

    private static void slash(double ex, double ey, double ez, double lx, double ly, double lz) {
        double sx = -lz, sz = lx;
        double sl = Math.sqrt(sx * sx + sz * sz);
        if (sl < 1e-4) {
            sx = 1;
            sz = 0;
        } else {
            sx /= sl;
            sz /= sl;
        }
        int n = Math.max(3, cnt(14));
        for (int k = 0; k < n; k++) {
            double a = -1.2 + 2.4 * k / (n - 1);
            double px = ex + lx * (1.3 + 0.4 * Math.cos(a)) + sx * 1.3 * Math.sin(a);
            double py = ey - 0.2 + ly * 1.3;
            double pz = ez + lz * (1.3 + 0.4 * Math.cos(a)) + sz * 1.3 * Math.sin(a);
            double vx = sx * Math.cos(a) * 0.12, vz = sz * Math.cos(a) * 0.12;
            emit("glow", px, py, pz, vx, 0.01, vz, 6, 0.38, 0.1, WHITE, EDGE[el], 0.9, true, 0, 0.9, 0, false);
            if (k % 3 == 0) accent(px, py, pz, vx, 0.02, vz, 10, 0.35, 0.12, 0.9);
        }
        emit("spark", ex + lx * 1.7, ey + ly * 1.7 - 0.1, ez + lz * 1.7, 0, 0, 0, 5, 0.9, 0.2, WHITE, CORE[el], 0.9, true, 0, 1, 0, false);
    }

    // ================= 지혜의 정원 연출 (나히다): 청록 + 금빛 + 잎과 덩굴 =================
    private static final int[] LEAF_TINT = {0xA8FFD8, 0x6DF0C0, 0xFFE27A, 0x9CF06A};

    private static int leafTint() {
        return LEAF_TINT[rnd.nextInt(LEAF_TINT.length)];
    }

    private static void akasha(double x, double y, double z, double a, int sub, int aux) {
        switch (sub) {
            case 0 -> akashaMark(x, y, z, a);
            case 1 -> akashaCast(x, y, z, a);
            default -> akashaShrine(x, y, z, a, aux);
        }
    }

    /** 씨앗 표식: 적을 감싸는 반투명 구체 + 발밑 문양 + 말려 올라가는 덩굴과 잎 */
    private static void akashaMark(double x, double y, double z, double h) {
        double hh = Math.max(0.8, h);
        emit("shell_bubble", x, y + hh * 0.5, z, 0, 0, 0, 20, hh * 0.75, hh * 0.95, WHITE, WHITE, 0.85, true, 0, 1, 0, false);
        emit("akasha_glyph", x, y + 0.06, z, 0, 0, 0, 26, hh * 0.9, hh * 0.7, WHITE, WHITE, 0.9, true, 0, 1, 0.07, true);
        emit("akasha_ring", x, y + 0.08, z, 0, 0, 0, 22, hh * 0.5, hh * 1.1, WHITE, WHITE, 0.6, true, 0, 1, -0.05, true);
        for (int i = 0; i < cnt(3); i++) {
            double a = i * 2.1 + ru();
            emit("vine_curl", x + Math.cos(a) * hh * 0.45, y + hh * 0.45, z + Math.sin(a) * hh * 0.45, 0, 0.03, 0, 22, hh * 0.45, hh * 0.3, WHITE, WHITE, 0.9, true, 0, 1, 0.08, false);
        }
        for (int i = 0; i < cnt(10); i++) {
            double a = ru() * 6.2832;
            emit("leaf_glow", x + Math.cos(a) * 0.5, y + 0.2 + ru() * hh, z + Math.sin(a) * 0.5, -Math.sin(a) * 0.05, 0.06 + ru() * 0.05, Math.cos(a) * 0.05,
                    24, 0.34, 0.12, leafTint(), leafTint(), 0.95, true, 0, 0.97, rr(0.12), false);
        }
        glowE(x, y + hh * 0.5, z, 0, 0, 0, 12, hh * 1.2, hh * 0.9, 0.3);
    }

    /** 시전 폭발: 사슬 문자 마법진이 퍼지며 잎이 사방으로 흩날리고 덩굴이 솟는다 */
    private static void akashaCast(double x, double y, double z, double r) {
        emit("akasha_ring", x, y + 0.07, z, 0, 0, 0, 22, r * 0.5, r, WHITE, WHITE, 0.9, true, 0, 1, 0.04, true);
        emit("akasha_glyph", x, y + 0.09, z, 0, 0, 0, 22, r * 0.4, r * 0.7, WHITE, WHITE, 0.7, true, 0, 1, -0.06, true);
        flatRing(x, y, z, r * 0.2, r * 1.15, 14, 0.8);
        glowE(x, y + 0.6, z, 0, 0, 0, 10, r * 0.8, r * 1.2, 0.35);
        for (int i = 0; i < cnt(34); i++) {
            double a = ru() * 6.2832, sp = 0.12 + ru() * 0.3;
            emit("leaf_glow", x, y + 0.5, z, Math.cos(a) * sp, 0.08 + ru() * 0.2, Math.sin(a) * sp, 26, 0.4, 0.15, leafTint(), leafTint(), 0.95, true, 0.02, 0.93, rr(0.15), false);
        }
        for (int i = 0; i < 6; i++) {
            double a = i * Math.PI / 3 + ru() * 0.3;
            emit("vine_curl", x + Math.cos(a) * r * 0.55, y + 0.8, z + Math.sin(a) * r * 0.55, 0, 0.1, 0, 20, r * 0.25, r * 0.4, WHITE, WHITE, 0.85, true, 0, 0.97, 0.06, false);
        }
    }

    /** 성소(나히다 Q): 스테인드글라스 아치가 둘러싼 금빛 성소 + 사슬 문자 마법진 + 솟는 잎과 중앙의 빛나는 나무 */
    private static void akashaShrine(double x, double y, double z, double r, int idx) {
        emit("akasha_ring", x, y + 0.06, z, 0, 0, 0, 14, r * 0.97, r, WHITE, WHITE, 0.8, true, 0, 1, 0.015, true);
        emit("akasha_glyph", x, y + 0.09, z, 0, 0, 0, 14, r * 0.45, r * 0.47, WHITE, WHITE, 0.6, true, 0, 1, -0.04, true);
        // 둘러싼 아치 창 패널 6장 (모두 중앙을 향해 서 있다)
        double s = r * 0.42;
        for (int k = 0; k < 6; k++) {
            double a = k * Math.PI / 3 + 0.3;
            double px = x + Math.cos(a) * r * 0.85, pz = z + Math.sin(a) * r * 0.85;
            emitUpright("arch_panel", px, y + s, pz, 16, s, s * 1.02, 0.75, 0, a + Math.PI / 2);
        }
        // 중앙의 빛나는 나무: 청록 빛기둥과 그 둘레를 도는 잎
        for (double h = 0; h < 5.0; h += 0.7) {
            glowE(x, y + h, z, 0, 0, 0, 10, 1.2 - h * 0.12, 0.8, 0.45);
        }
        for (int k = 0; k < cnt(6); k++) {
            double a = ru() * 6.2832, d = 0.6 + ru() * 1.2;
            emit("leaf_glow", x + Math.cos(a) * d, y + 0.3, z + Math.sin(a) * d, -Math.sin(a) * 0.06, 0.1 + ru() * 0.06, Math.cos(a) * 0.06, 28, 0.38, 0.14, leafTint(), leafTint(), 0.95, true, 0, 0.98, rr(0.1), false);
        }
        // 전역으로 떠오르는 잎과 금빛 빛가루
        for (int k = 0; k < cnt(8); k++) {
            double a = ru() * 6.2832, d = r * Math.sqrt(ru());
            emit("leaf_glow", x + Math.cos(a) * d, y + 0.2, z + Math.sin(a) * d, rr(0.02), 0.05 + ru() * 0.05, rr(0.02), 30, 0.34, 0.12, leafTint(), leafTint(), 0.9, true, 0, 0.99, rr(0.1), false);
            emit("spark", x + Math.cos(a) * d, y + 0.4 + ru() * 2, z + Math.sin(a) * d, rr(0.01), 0.04, rr(0.01), 24, 0.22, 0.05, 0xFFF0A0, 0xFFD060, 0.9, true, 0, 0.98, 0, false);
        }
        if (idx % 2 == 0) {
            for (int k = 0; k < 3; k++) {
                double a = ru() * 6.2832, d = r * (0.4 + 0.5 * ru());
                emit("vine_curl", x + Math.cos(a) * d, y + 1.0 + ru(), z + Math.sin(a) * d, 0, 0.04, 0, 18, 0.9, 0.6, WHITE, WHITE, 0.8, true, 0, 1, 0.07, false);
            }
        }
    }

    /** 지혜의 선: 잎들이 줄지어 흐르고 청록빛이 번지며 금빛 불씨가 튄다 */
    private static void akashaBeam(double ax, double ay, double az, double bx, double by, double bz) {
        double dx = bx - ax, dy = by - ay, dz = bz - az;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 0.1) return;
        double ux = dx / len, uy = dy / len, uz = dz / len;
        double stepLen = 0.55 / Math.max(0.3, dens);
        int steps = (int) (len / stepLen);
        for (int i = 0; i <= steps; i++) {
            double tt = steps == 0 ? 0 : (double) i / steps;
            double px = ax + dx * tt, py = ay + dy * tt, pz = az + dz * tt;
            double w = Math.sin(i * 1.3) * 0.18;   // 덩굴처럼 살짝 굽이친다
            double ox = -uz * w, oz = ux * w;
            emit("glow", px + ox, py, pz + oz, ux * 0.04, uy * 0.04, uz * 0.04, 9, 0.32, 0.12, 0x9CFFE0, 0x30D8B0, 0.8, true, 0, 1, 0, false);
            if (i % 2 == 0) emit("leaf_glow", px + ox, py, pz + oz, ux * 0.05 + rr(0.02), uy * 0.05 + rr(0.02), uz * 0.05 + rr(0.02), 12, 0.3, 0.1, leafTint(), leafTint(), 0.95, true, 0, 0.96, rr(0.2), false);
            if (i % 4 == 0) emit("spark", px, py, pz, rr(0.03), rr(0.03), rr(0.03), 10, 0.2, 0.05, 0xFFF0A0, 0xFFD060, 0.9, true, 0, 0.95, 0, false);
        }
        flash(bx, by, bz, 4, 0.5, 0.9, 0.8);
        for (int i = 0; i < cnt(5); i++) {
            emit("leaf_glow", bx, by, bz, rr(0.15), rr(0.15) + 0.05, rr(0.15), 16, 0.32, 0.1, leafTint(), leafTint(), 0.95, true, 0.02, 0.92, rr(0.2), false);
        }
    }

    // ================= 파이논: 새벽과 태양의 심판 =================
    private static final int GOLDC = 0xFFD76A, SKYC = 0x7FC8FF, ROSE = 0xFF5A78, CRIM = 0xB0001C;

    private static void phainon(FxPacket m, int sub) {
        switch (sub) {
            case 0 -> dawnSlash(m.x, m.y, m.z, m.vx, m.vy, m.vz, m.a);
            case 1 -> chainOrb(m.x, m.y, m.z, m.a, m.vx < 0.5f);
            case 2 -> dawnCircle(m.x, m.y, m.z, m.a);
            case 3 -> swordFrame(m.x, m.y, m.z, m.vx, m.vy, m.vz, m.a, false);
            case 4 -> swordImpact(m.x, m.y, m.z, m.a, m.vx > 0.5f);
            case 5 -> swordFrame(m.x, m.y, m.z, m.vx, m.vy, m.vz, m.a, true);
            case 6 -> judgmentCast(m.x, m.y, m.z, m.a);
            case 7 -> eSlash(m.x, m.y, m.z, m.vx, m.vy, m.vz, Math.round(m.a));
            default -> { }
        }
    }

    /**
     * 횡베기: 참고 이미지로 만든 소용돌이 검기. 스프라이트는 원 중심이 이미지 중심이고 터진 쪽이 아래다.
     * 바닥에 눕혀서 터진 쪽이 시전자를 향하게(호의 볼록한 쪽이 전방) 두고, 전방으로 살짝 떨어진 지점을 중심으로 크게 휘두른다. scale = 크기 배율
     */
    private static void dawnSlash(double ex, double ey, double ez, double lx, double ly, double lz, double scale) {
        double hl = Math.sqrt(lx * lx + lz * lz);
        double hx = hl < 1e-4 ? 0 : lx / hl, hz = hl < 1e-4 ? 1 : lz / hl;
        double sx = -hz, sz = hx;                       // 오른쪽 방향
        double size = 7.0 * scale;                      // 스프라이트 반폭. 고리 반지름은 이것의 0.70
        double ringR = size * 0.70;
        double ahead = 2.6 * scale;
        double cx = ex + hx * ahead, cy = ey - 0.95, cz = ez + hz * ahead;
        float fwd = (float) Math.atan2(-hx, hz);        // 스프라이트의 위쪽(+v)이 전방을 향하는 roll
        emitRoll("dawn_slash", cx, cy, cz, 0, 0, 0, 8, size * 0.62, size, WHITE, WHITE, 1.0, true, 0, 1, -0.24, true, fwd + 1.1f);
        emitRoll("dawn_slash", cx, cy + 0.02, cz, 0, 0, 0, 10, size * 0.70, size * 1.18, WHITE, SKYC, 0.55, true, 0, 1, -0.19, true, fwd + 0.95f);
        emitRoll("dawn_slash", cx, cy + 0.04, cz, 0, 0, 0, 12, size * 0.80, size * 1.36, GOLDC, WHITE, 0.32, true, 0, 1, -0.14, true, fwd + 0.8f);
        emit("glow", cx + hx * ringR * 0.9, cy + 0.3, cz + hz * ringR * 0.9, 0, 0, 0, 7, ringR * 0.3, ringR * 1.1, 0xFFF1C0, SKYC, 0.45, true, 0, 1, 0, false);
        int n = Math.max(8, cnt(24));
        for (int k = 0; k < n; k++) {
            double a = -1.5 + 3.0 * k / (n - 1);             // 전방을 중심으로 좌우 호
            double rad = ringR * (0.9 + ru() * 0.3);
            double px = cx + (hx * Math.cos(a) + sx * Math.sin(a)) * rad;
            double pz = cz + (hz * Math.cos(a) + sz * Math.sin(a)) * rad;
            int c = rnd.nextInt(3) == 0 ? SKYC : (rnd.nextBoolean() ? GOLDC : WHITE);
            emit(k % 3 == 0 ? "star4" : "spark", px, cy + 0.2 + rr(0.3), pz, -sx * 0.05 * Math.sin(a) + hx * 0.03, 0.02 + ru() * 0.03, -sz * 0.05 * Math.sin(a) + hz * 0.03,
                    14, 0.25 + ru() * 0.2, 0.04, c, c, 0.95, true, 0, 0.94, rr(0.1), false);
        }
    }

    /** 세운 면(시전자 쪽을 보는 평면)에 roll/spin 이 적용되는 파티클 */
    private static void emitUprightRoll(String tex, double x, double y, double z, int life, double s0, double s1, int c0, int c1,
                                        double a, double spin, double yawRad, float roll) {
        FxParticle p = emitP(tex, x, y, z, 0, 0, 0, life, s0, s1, c0, c1, a, true, 0, 1, spin, true, roll);
        if (p != null) p.vertical((float) yawRad);
    }

    /**
     * 파이논 E 의 리본 횡베기. code = type * 100 + k.
     * type 0: 1타, 정면 수평 베기(바닥에 눕힌 리본 호가 시전자를 중심으로 오른쪽에서 왼쪽으로 휘둘러진다).
     * type 1: 2타, 대각 베기(세운 리본 호가 오른쪽 아래에서 왼쪽 위로) + 바닥의 더 넓은 수평 잔상.
     * k = 0 은 본체(스프라이트가 회전하며 휘둘러짐), k >= 1 은 휘두른 궤적(그 시점 각도에 남는 잔상).
     */
    private static void eSlash(double ex, double ey, double ez, double lx, double ly, double lz, int code) {
        int type = code / 100, k = code % 100;
        double hl = Math.sqrt(lx * lx + lz * lz);
        double hx = hl < 1e-4 ? 0 : lx / hl, hz = hl < 1e-4 ? 1 : lz / hl;
        float fwd = (float) Math.atan2(-hx, hz);          // 스프라이트의 위쪽이 전방을 향하는 roll
        final int steps = 6;
        if (type == 0) {
            double size = 6.7;                            // 반폭 (호 반지름은 0.72 배 = 약 4.8칸)
            double cx = ex + hx * 0.4, cy = ey - 1.05, cz = ez + hz * 0.4;
            float r0 = fwd + 0.95f, sweep = -1.9f;
            float roll = r0 + sweep * k / steps;
            if (k == 0) {
                emitRoll("dawn_ribbon", cx, cy, cz, 0, 0, 0, steps, size * 0.85, size * 1.05, WHITE, WHITE, 1.0, true, 0, 1, sweep / steps, true, r0);
                emitRoll("dawn_ribbon", cx, cy + 0.03, cz, 0, 0, 0, steps + 1, size * 1.0, size * 1.22, GOLDC, WHITE, 0.55, true, 0, 1, sweep / steps, true, r0 + 0.12f);
                emit("glow", cx + hx * 3.4, cy + 0.4, cz + hz * 3.4, 0, 0, 0, 7, 1.2, 5.2, 0xFFF1C0, GOLDC, 0.4, true, 0, 1, 0, false);
                for (int i = 0; i < cnt(26); i++) {
                    double a = fwd + 0.95 - ru() * 1.9 + (ru() - 0.5) * 0.5;
                    double rad = size * 0.72 * (0.9 + ru() * 0.3);
                    double px = cx - Math.sin(a) * rad, pz = cz + Math.cos(a) * rad;
                    int c = rnd.nextInt(3) == 0 ? SKYC : (rnd.nextBoolean() ? GOLDC : WHITE);
                    emit(i % 3 == 0 ? "star4" : "spark", px, cy + 0.3 + rr(0.4), pz, -Math.cos(a) * 0.04, 0.02 + ru() * 0.03, -Math.sin(a) * 0.04,
                            16, 0.25 + ru() * 0.25, 0.04, c, c, 0.95, true, 0, 0.95, rr(0.1), false);
                }
            } else {
                double fade = 1.0 - (double) k / (steps + 1);
                emitRoll("dawn_ribbon", cx, cy - 0.02 * k, cz, 0, 0, 0, 16, size * 1.0, size * 1.08, GOLDC, WHITE, 0.55 * fade + 0.1, true, 0, 1, 0, true, roll);
            }
            return;
        }
        // type 1: 대각
        double size = 7.4;                                // 호 반지름 약 5.3칸
        double cx = ex + hx * 3.6, cy = ey + 0.2, cz = ez + hz * 3.6;
        float r0 = 2.3f, sweep = -2.9f;                   // 오른쪽 아래에서 왼쪽 위로
        float roll = r0 + sweep * k / steps;
        if (k == 0) {
            emitUprightRoll("dawn_ribbon", cx, cy, cz, steps, size * 0.85, size * 1.05, WHITE, WHITE, 1.0, sweep / steps, fwd, r0);
            emitUprightRoll("dawn_ribbon", cx + hx * 0.1, cy, cz + hz * 0.1, steps + 1, size * 1.0, size * 1.22, GOLDC, WHITE, 0.55, sweep / steps, fwd, r0 + 0.12f);
            // 정면을 더 넓게 훑는 수평 잔상 (바닥)
            double w = 9.5, fy = ey - 1.2;
            emitRoll("dawn_ribbon", ex + hx * 0.6, fy, ez + hz * 0.6, 0, 0, 0, steps + 2, w * 0.85, w * 1.05, GOLDC, WHITE, 0.5, true, 0, 1, -2.6f / steps, true, fwd + 1.3f);
            emit("glow", cx, cy, cz, 0, 0, 0, 8, 1.5, 6.5, 0xFFF1C0, GOLDC, 0.4, true, 0, 1, 0, false);
            double sx = -hz, sz = hx;
            for (int i = 0; i < cnt(30); i++) {
                double a = r0 + sweep * ru();
                double rad = size * 0.72 * (0.9 + ru() * 0.3);
                // 세운 면 위의 점: 오른쪽 방향(sx,sz) * sin(a) * rad, 위 * cos(a) * rad
                double px = cx + sx * Math.sin(a) * rad, pz = cz + sz * Math.sin(a) * rad, py = cy + Math.cos(a) * rad;
                int c = rnd.nextInt(3) == 0 ? SKYC : (rnd.nextBoolean() ? GOLDC : WHITE);
                emit(i % 3 == 0 ? "star4" : "spark", px, py, pz, rr(0.03), -0.02 - ru() * 0.03, rr(0.03), 18, 0.25 + ru() * 0.25, 0.04, c, c, 0.95, true, 0, 0.95, rr(0.1), false);
            }
        } else {
            double fade = 1.0 - (double) k / (steps + 1);
            emitUprightRoll("dawn_ribbon", cx, cy, cz, 16, size * 1.0, size * 1.08, GOLDC, WHITE, 0.55 * fade + 0.1, 0, fwd, roll);
        }
    }

    /** 가시 사슬 + 블랙홀 구체. fresh = 첫 펄스(사슬이 하늘에서 떨어진다) */
    private static void chainOrb(double x, double y, double z, double sz, boolean fresh) {
        double piece = 4.0;                                   // 사슬 조각 하나의 반높이 (8칸)
        double base = y + sz * 0.8 + piece;                   // 아래 조각의 중심 (아래 끝이 구체 윗부분에 닿는다)
        for (int ch = 0; ch < 2; ch++) {
            double ox = ch == 0 ? 0.55 : -0.55, oz = ch == 0 ? -0.2 : 0.2;
            for (int j = 0; j < 3; j++) {
                double cy = base + j * piece * 2;
                if (fresh) {
                    emit("chain_spike", x + ox, cy + 12, z + oz, 0, -1.2, 0, 12, piece, piece, WHITE, WHITE, 1.0, false, 0, 1, 0, false);
                } else {
                    emit("chain_spike", x + ox, cy, z + oz, 0, 0, 0, 6, piece, piece, WHITE, WHITE, 1.0, false, 0, 1, 0, false);
                }
            }
        }
        int ol = fresh ? 12 : 6;                              // 첫 펄스는 다음 유지 펄스(12틱 뒤)까지 이어지게 오래 남긴다
        emit("glow", x, y + 5.0, z, 0, 0, 0, ol, 0.8, 1.0, CRIM, 0x400008, 0.14, true, 0, 1, 0, false);
        // 블랙홀 구체: 사용자가 준 블랙홀 사진(검은 구멍 + 방사 파편)을 느리게 돌리고, 가산 테두리를 얹는다
        double os = sz * 1.5;
        emit("blackhole_orb", x, y, z, 0, 0, 0, ol, os, os * 1.04, WHITE, WHITE, 0.88, false, 0, 1, 0.045, false);
        emit("orb_rim", x, y, z, 0, 0, 0, ol, os * 0.55, os * 0.6, WHITE, WHITE, 0.7, true, 0, 1, -0.12, false);
        emit("glow", x, y, z, 0, 0, 0, ol, os * 1.3, os * 1.1, ROSE, CRIM, 0.22, true, 0, 1, 0, false);
        emit("vortex_disc", x, y - sz * 0.5 - 0.1, z, 0, 0, 0, ol, sz * 1.8, sz * 1.8, 0xFF5060, 0xA00018, 0.6, true, 0, 1, 0.25, true);
        for (int i = 0; i < cnt(3); i++) {
            double a = ru() * 6.2832, b = (ru() - 0.5) * 2.0;
            double rr0 = os * 0.75;
            emit("spark", x + Math.cos(a) * rr0, y + b * os * 0.6, z + Math.sin(a) * rr0, -Math.sin(a) * 0.05, 0, Math.cos(a) * 0.05, 8, 0.25, 0.05, ROSE, CRIM, 0.95, true, 0, 0.95, 0, false);
        }
    }

    /** 시전 순간: 바닥에 번지는 검붉은 소용돌이와 파문 */
    private static void judgmentCast(double x, double y, double z, double r) {
        emit("vortex_disc", x, y + 0.08, z, 0, 0, 0, 30, r * 0.5, r * 1.05, 0xFF6070, 0x700012, 0.8, true, 0, 1, 0.12, true);
        emit("vortex_disc", x, y + 0.10, z, 0, 0, 0, 24, r * 0.3, r * 0.8, 0xFFB0A0, 0xB00020, 0.6, true, 0, 1, -0.15, true);
        emit("glow", x, y + 0.5, z, 0, 0, 0, 10, 1.0, r * 0.9, ROSE, CRIM, 0.5, true, 0, 1, 0, true);
        for (int i = 0; i < cnt(30); i++) {
            double a = ru() * 6.2832, sp = 0.2 + ru() * 0.5;
            emit("spark", x, y + 0.5, z, Math.cos(a) * sp, 0.1 + ru() * 0.2, Math.sin(a) * sp, 20, 0.3, 0.05, ROSE, CRIM, 0.95, true, 0.02, 0.94, 0, false);
        }
    }

    /** 하늘의 마법진 한 프레임 (태양 광선 + 새벽 꽃잎). 반복 호출하면 이어진다 */
    private static void dawnCircle(double x, double y, double z, double r) {
        emit("dawn_circle", x, y, z, 0, 0, 0, 8, r * 0.97, r, WHITE, WHITE, 0.95, true, 0, 1, 0.012, true);
        emit("dawn_circle", x, y - 0.05, z, 0, 0, 0, 8, r * 0.64, r * 0.66, WHITE, 0xCFE8FF, 0.55, true, 0, 1, -0.03, true);
        emit("dawn_circle", x, y - 0.10, z, 0, 0, 0, 8, r * 1.18, r * 1.2, 0xFFE9A8, 0xBFE0FF, 0.22, true, 0, 1, -0.006, true);
        emit("glow", x, y - 0.15, z, 0, 0, 0, 8, r * 0.95, r * 1.1, 0xFFE6A0, 0x8FD0FF, 0.22, true, 0, 1, 0, true);
        for (int i = 0; i < cnt(4); i++) {
            double a = ru() * 6.2832, d = r * (0.2 + 0.8 * ru());
            int c = rnd.nextBoolean() ? GOLDC : SKYC;
            emit("star4", x + Math.cos(a) * d, y - 0.3, z + Math.sin(a) * d, rr(0.01), -0.06 - ru() * 0.06, rr(0.01), 30, 0.3 + ru() * 0.3, 0.05, c, WHITE, 0.95, true, 0, 0.99, 0.05, false);
        }
    }

    /** 대각선으로 떨어지는 검 한 프레임. prog 0~1 (제곱으로 가속). 칼끝이 (x,y,z) 에 닿는다 */
    private static void swordFrame(double x, double y, double z, double prog, double hxv, double hzv, double size, boolean giant) {
        double hl = Math.sqrt(hxv * hxv + hzv * hzv);
        double hx = hl < 1e-4 ? 1 : hxv / hl, hz = hl < 1e-4 ? 0 : hzv / hl;
        double dist = giant ? 28.0 : 14.0;
        double e = Math.min(1.0, prog);
        double k = 1.0 - e * e;                      // 남은 거리 비율 (가속)
        double dprog = giant ? 1.0 / 12.0 : 1.0 / 9.0;
        double dk = -2.0 * e * dprog;                // 틱당 k 변화 (부드러운 보간용)
        double tipX = x + hx * 0.545 * dist * k, tipY = y + 0.839 * dist * k, tipZ = z + hz * 0.545 * dist * k;
        double worldLen = size * 2.55;   // 흩날리는 빛이 퍼지는 범위 기준
        // PNG 검: 일반 알파 블렌딩(어두운 날이 보이게). 스프라이트 중심에서 칼끝까지의 거리가 (0.38, 0.59) * size 이다.
        double tx0 = 0.38 * size, ty0 = 0.59 * size;
        FxParticle sw = emitP("giant_sword", tipX + hx * tx0, tipY + ty0, tipZ + hz * tx0, 0, 0, 0, 3, size, size, WHITE, WHITE, 1.0, false, 0, 1, 0, true, 0f);
        if (sw != null) sw.vertical((float) Math.atan2(hz, hx));
        // 칼끝 쪽 광채와 흩날리는 빛 (검 몸통은 칼끝에서 낙하 반대 방향으로 뻗어 있다)
        emit("glow", tipX, tipY, tipZ, 0, 0, 0, 3, size * 0.5, size * 0.4, 0xFFF1C0, SKYC, 0.6, true, 0, 1, 0, false);
        double bx = hx * 0.545, by = 0.839, bz = hz * 0.545;
        for (int i = 0; i < cnt(giant ? 8 : 3); i++) {
            double t = ru() * worldLen * 0.6;
            int c = rnd.nextBoolean() ? GOLDC : SKYC;
            emit(i % 3 == 0 ? "star4" : "spark", tipX + bx * t + rr(size * 0.5), tipY + by * t + rr(size * 0.3), tipZ + bz * t + rr(size * 0.5), 0, 0.05, 0, 10, 0.3, 0.05, c, WHITE, 0.9, true, 0, 0.95, 0, false);
        }
    }

    /** 검 착탄: 땅의 마법진, 빛기둥, 충격파, 금빛/하늘빛 파편. big = 거대 검 */
    private static void swordImpact(double x, double y, double z, double r, boolean big) {
        double s = big ? r : r;
        emit("dawn_circle", x, y + 0.08, z, 0, 0, 0, big ? 22 : 12, s * 0.3, s * (big ? 1.1 : 1.0), WHITE, WHITE, 0.95, true, 0, 1, big ? 0.05 : 0.1, true);
        emit("glow", x, y + 0.6, z, 0, 0, 0, big ? 12 : 7, s * 0.4, s * (big ? 1.3 : 1.2), 0xFFF3C8, SKYC, 0.8, true, 0, 1, 0, false);
        flatRing(x, y, z, 0.3, s * 1.2, big ? 14 : 9, 0.8);
        emit("dawn_slash", x, y + 0.12, z, 0, 0, 0, 10, s * 0.5, s * 1.4, WHITE, WHITE, 0.6, true, 0, 1, 0.3, true);
        int n = cnt(big ? 90 : 28);
        for (int i = 0; i < n; i++) {
            double a = ru() * 6.2832, sp = (big ? 0.25 : 0.12) + ru() * (big ? 0.7 : 0.3);
            int c = i % 3 == 0 ? SKYC : (i % 3 == 1 ? GOLDC : WHITE);
            emit(i % 4 == 0 ? "star4" : "spark", x, y + 0.4, z, Math.cos(a) * sp, 0.12 + ru() * (big ? 0.6 : 0.3), Math.sin(a) * sp, 24, 0.35, 0.05, c, c, 0.95, true, 0.03, 0.94, rr(0.1), false);
        }
        // 빛기둥
        double h = big ? 16 : 6;
        for (double yy = 0; yy < h; yy += 0.6 / Math.max(0.3, dens)) {
            emit("glow", x + rr(0.2), y + yy, z + rr(0.2), 0, 0.02, 0, big ? 12 : 7, big ? 1.6 : 0.8, 0.3, 0xFFEFC0, SKYC, 0.5, true, 0, 1, 0, false);
        }
        if (big) {
            for (int i = 0; i < cnt(8); i++) {
                emit("smoke", x + rr(r * 0.5), y + 0.5, z + rr(r * 0.5), rr(0.2), 0.05, rr(0.2), 26, 1.5, 4.0, 0xFFF0C8, 0x9FC8FF, 0.35, false, 0, 0.96, 0, false);
            }
        }
    }

    // ================= 조류 연출 (푸리나) =================
    private static final int[] WT = {0x7FE8FF, 0xB9A4FF, 0xFFFFFF};

    private static void waterHoops(double x, double y, double z, double r, int n, double h, int life) {
        for (int i = 0; i < n; i++) {
            double a = i * Math.PI * 2 / n + ru() * 0.2;
            emitUpright(i % 2 == 0 ? "water_ring" : "water_ring_b", x + Math.cos(a) * r, y + h + rr(0.4), z + Math.sin(a) * r,
                    life, 0.4, 1.8 + ru() * 0.6, 0.9, 0, a + Math.PI / 2);
        }
    }

    /** 천칭 마법진 한 프레임 (바닥). 반복 호출하면 이어진다 */
    private static void libra(double x, double y, double z, double r) {
        emit("libra_circle", x, y + 0.07, z, 0, 0, 0, 12, r * 1.0, r * 1.02, WHITE, WHITE, 0.95, true, 0, 1, 0.004, true);
        emit("libra_circle", x, y + 0.09, z, 0, 0, 0, 12, r * 0.60, r * 0.61, 0xBFE8FF, WHITE, 0.45, true, 0, 1, -0.012, true);
        emit("glow", x, y + 0.05, z, 0, 0, 0, 12, r * 0.95, r * 1.05, 0x59B8FF, 0x2060FF, 0.22, true, 0, 1, 0, true);
    }

    /** 범람: 거품 낀 물결 고리가 바깥으로 밀려나가고, 가장자리에서 물이 솟구친다 */
    private static void flood(double x, double y, double z, double r) {
        emit("flood_wave", x, y + 0.10, z, 0, 0, 0, 18, r * 0.12, r * 1.18, WHITE, WHITE, 0.95, true, 0, 1, 0.02, true);
        emit("flood_wave", x, y + 0.12, z, 0, 0, 0, 26, r * 0.08, r * 1.05, 0xBFEFFF, WHITE, 0.6, true, 0, 1, -0.03, true);
        emit("water_ring", x, y + 0.14, z, 0, 0, 0, 22, r * 0.2, r * 1.1, WHITE, WHITE, 0.8, true, 0, 1, 0.05, true);
        for (int i = 0; i < cnt(46); i++) {
            double a = ru() * 6.2832, rad = r * (0.5 + 0.5 * ru());
            double sp = 0.18 + ru() * 0.3;
            emit(i % 3 == 0 ? "hydro_bubble" : "hydro_drop", x + Math.cos(a) * rad, y + 0.3, z + Math.sin(a) * rad,
                    Math.cos(a) * 0.06, sp, Math.sin(a) * 0.06, 28, 0.4, 0.15, WT[rnd.nextInt(3)], WT[rnd.nextInt(3)], 0.95, i % 3 != 0, 0.03, 0.95, 0.04, false);
        }
        for (int i = 0; i < cnt(10); i++) {
            double a = ru() * 6.2832, rad = r * (0.6 + 0.4 * ru());
            emit("smoke", x + Math.cos(a) * rad, y + 0.4, z + Math.sin(a) * rad, Math.cos(a) * 0.05, 0.05, Math.sin(a) * 0.05, 30, 1.2, 3.2, 0xEAF8FF, 0xA9D8FF, 0.32, false, 0, 0.96, 0, false);
        }
        waterHoops(x, y, z, r * 0.9, 12, 1.2, 20);
    }

    /**
     * 푸리나 Q. phase 0 = 시전(바닥 충격 + 첫 천칭 마법진), 1 = 유지 펄스(마법진 + 잔물결),
     * 2 = 주기적 범람(마법진 + 범람 물결 + 고래 떼가 솟아올라 하늘로 오른다)
     */
    private static void tide(double x, double y, double z, double r, int phase) {
        r = Math.max(2.0, r);
        libra(x, y, z, r);
        if (phase == 1) {
            emit("water_ring", x, y + 0.11, z, 0, 0, 0, 10, r * 0.55, r * 0.75, WHITE, WHITE, 0.4, true, 0, 1, 0.05, true);
            for (int i = 0; i < cnt(8); i++) {
                double b = ru() * 6.2832, d = r * Math.sqrt(ru());
                emit(i % 2 == 0 ? "hydro_bubble" : "hydro_drop", x + Math.cos(b) * d, y + 0.2, z + Math.sin(b) * d,
                        rr(0.02), 0.08 + ru() * 0.08, rr(0.02), 26, 0.3, 0.2, WHITE, WHITE, 0.85, i % 2 == 1, -0.002, 0.99, 0.02, false);
            }
            return;
        }
        if (phase == 2) {
            flood(x, y, z, r);
            WhaleRenderer.spawn(x, y, z, r, 3);
            return;
        }
        // 시전: 퍼져 나가는 유리 물고리와 세운 물 고리, 물보라
        emit("water_ring", x, y + 0.08, z, 0, 0, 0, 14, r * 0.2, r * 1.15, WHITE, WHITE, 0.95, true, 0, 1, 0.05, true);
        emit("water_ring_b", x, y + 0.10, z, 0, 0, 0, 20, r * 0.1, r * 0.9, WHITE, WHITE, 0.85, true, 0, 1, -0.06, true);
        flatRing(x, y, z, 0.3, r * 1.2, 12, 0.7);
        waterHoops(x, y, z, r * 0.55, 8, 1.4, 18);
        waterHoops(x, y, z, r * 0.85, 10, 2.4, 22);
        for (int i = 0; i < cnt(40); i++) {
            double b = ru() * 6.2832, sp = 0.1 + ru() * 0.35;
            emit(i % 3 == 0 ? "hydro_bubble" : "hydro_drop", x, y + 0.4, z, Math.cos(b) * sp, 0.15 + ru() * 0.3, Math.sin(b) * sp,
                    26, 0.35, 0.15, WT[rnd.nextInt(3)], WT[rnd.nextInt(3)], 0.95, i % 3 != 0, 0.02, 0.95, 0.04, false);
        }
    }

    // ================= 선율과 특이점 연출 (벤티) =================
    private static final int[] TT = {0x5CF2D6, 0xA98CFF};   // 투톤: 청록 / 보랏빛
    private static final String[] NOTES = {"note_a", "note_b", "note_c"};

    private static int tone() {
        return TT[rnd.nextInt(2)];
    }

    /** 선율의 마법진: 투톤 음표 마법진, 떠오르는 음표, 바깥으로 흐르는 선율 리본 */
    private static void melody(double x, double y, double z, double r, int idx) {
        emit("music_circle", x, y + 0.06, z, 0, 0, 0, 10, r * 0.97, r, WHITE, WHITE, 0.8, true, 0, 1, 0.02, true);
        emit("vortex_disc", x, y + 0.09, z, 0, 0, 0, 10, r * 0.9, r * 0.95, WHITE, WHITE, 0.35, true, 0, 1, -0.05, true);
        if (idx == 0) {
            flatRing(x, y, z, r * 0.2, r * 1.1, 16, 0.8);
            for (int i = 0; i < cnt(24); i++) {
                double a = ru() * 6.2832;
                emit(NOTES[rnd.nextInt(3)], x, y + 0.5, z, Math.cos(a) * 0.35, 0.05 + ru() * 0.1, Math.sin(a) * 0.35, 18, 0.5, 0.2, tone(), tone(), 0.95, true, 0, 0.9, 0.05, false);
            }
        }
        // 떠오르는 음표
        int n = cnt(6);
        for (int i = 0; i < n; i++) {
            double a = ru() * 6.2832, d = r * Math.sqrt(ru());
            emit(NOTES[rnd.nextInt(3)], x + Math.cos(a) * d, y + 0.3, z + Math.sin(a) * d, rr(0.01), 0.07 + ru() * 0.06, rr(0.01), 30,
                    0.55, 0.3, tone(), tone(), 0.95, true, 0, 0.99, rr(0.04), false);
        }
        // 선율 리본: 나선을 그리며 바깥으로 흐르는 빛줄기 4개
        for (int k = 0; k < 4; k++) {
            double a0 = idx * 0.4 + k * Math.PI / 2;
            int segs = Math.max(4, cnt(10));
            for (int j = 0; j < segs; j++) {
                double rj = r * (0.15 + 0.85 * j / (double) segs);
                double aj = a0 + j * 0.3;
                double py = y + 0.4 + j * 0.16 + Math.sin(j * 0.9 + idx) * 0.3;
                double tx = -Math.sin(aj) * 0.06, tz = Math.cos(aj) * 0.06;
                emit("anemo_spark", x + Math.cos(aj) * rj, py, z + Math.sin(aj) * rj, tx, 0.02, tz, 12, 0.32, 0.1, tone(), tone(), 0.9, true, 0, 0.95, 0, false);
            }
        }
        for (int i = 0; i < cnt(3); i++) {
            double a = ru() * 6.2832, d = r * ru();
            emit("anemo_swirl", x + Math.cos(a) * d, y + 0.4, z + Math.sin(a) * d, -Math.sin(a) * 0.05, 0.08, Math.cos(a) * 0.05, 18, 0.7, 1.4, 0xBFFFF0, 0xE0D4FF, 0.35, true, 0, 0.97, 0.06, false);
        }
    }

    /** 특이점: 검은 핵 + 투톤 강착원반 + 한 점으로 빨려드는 바람/음표/잎. phase 1=시작, 2=붕괴 */
    private static void blackhole(double x, double y, double z, double r, int phase) {
        double hc = y + 1.8;
        if (phase == 2) {   // 붕괴: 충격파와 음표 폭발
            flatRing(x, y, z, r * 0.15, r * 1.15, 16, 0.9);
            flatRing(x, y, z, r * 0.1, r * 0.8, 12, 0.8);
            emit("vortex_disc", x, hc, z, 0, 0, 0, 12, r * 0.25, r * 0.9, WHITE, WHITE, 0.9, true, 0, 1, 0.2, true);
            emit("glow", x, hc, z, 0, 0, 0, 8, r * 0.3, r * 0.9, 0xE8FFFA, 0xA98CFF, 0.9, true, 0, 1, 0, false);
            for (int i = 0; i < cnt(60); i++) {
                double a = ru() * 6.2832, up = (ru() - 0.3) * 0.5, sp = 0.35 + ru() * 0.5;
                emit(i % 3 == 0 ? NOTES[rnd.nextInt(3)] : "anemo_spark", x, hc, z, Math.cos(a) * sp, up, Math.sin(a) * sp, 22, 0.55, 0.15, tone(), tone(), 0.95, true, 0, 0.93, 0.05, false);
            }
            for (int i = 0; i < cnt(10); i++) {
                emit("smoke", x + rr(1.0), hc + rr(0.6), z + rr(1.0), rr(0.25), rr(0.1), rr(0.25), 24, 1.2, 3.0, 0x1A0A2A, 0x050008, 0.6, false, 0, 0.92, 0.01, false);
            }
            return;
        }
        if (phase == 1) {   // 시작: 바깥에서 안쪽으로 조여드는 고리
            emit("music_circle", x, y + 0.1, z, 0, 0, 0, 24, r * 1.0, r * 0.35, WHITE, WHITE, 0.85, true, 0, 1, 0.08, true);
            flatRing(x, y, z, r * 1.1, r * 0.2, 20, 0.9);
        }
        // 검은 핵 (가산이 아닌 어두운 연기를 겹쳐 빛을 먹는 것처럼 보이게)
        for (int i = 0; i < 3; i++) {
            emit("smoke", x + rr(0.15), hc + rr(0.15), z + rr(0.15), 0, 0, 0, 7, 1.7, 1.8, 0x0A0014, 0x050008, 0.97, false, 0, 1, 0.02, false);
        }
        // 강착원반 (핵 둘레 수평) + 바닥 소용돌이
        emit("vortex_disc", x, hc, z, 0, 0, 0, 7, r * 0.26, r * 0.28, WHITE, WHITE, 0.95, true, 0, 1, 0.3, true);
        emit("vortex_disc", x, hc - 0.05, z, 0, 0, 0, 7, r * 0.14, r * 0.15, WHITE, WHITE, 0.9, true, 0, 1, -0.4, true);
        emit("vortex_disc", x, y + 0.08, z, 0, 0, 0, 8, r, r * 0.95, WHITE, WHITE, 0.55, true, 0, 1, 0.1, true);
        emit("music_circle", x, y + 0.12, z, 0, 0, 0, 8, r * 0.55, r * 0.52, WHITE, WHITE, 0.45, true, 0, 1, -0.04, true);
        emit("glow", x, hc, z, 0, 0, 0, 7, 2.6, 2.2, 0x9AFFEE, 0xB090FF, 0.35, true, 0, 1, 0, false);
        // 빨려드는 입자: 각 입자가 수명이 끝날 때 핵에 닿도록 속도를 계산한다
        int n = cnt(26);
        for (int i = 0; i < n; i++) {
            double a = ru() * 6.2832, rad = r * (0.3 + 0.7 * ru()), h = ru() * r * 0.45;
            double px = x + Math.cos(a) * rad, py = y + 0.3 + h, pz = z + Math.sin(a) * rad;
            int life = 16;
            double tx = -Math.sin(a) * 0.1, tz = Math.cos(a) * 0.1;   // 나선으로 감기게 접선 속도 추가
            double vx = (x - px) / life + tx, vy = (hc - py) / life, vz = (z - pz) / life + tz;
            int k = rnd.nextInt(5);
            String tex = k == 0 ? "anemo_swirl" : (k == 1 ? "leaf_wind" : (k == 2 ? "anemo_spark" : NOTES[rnd.nextInt(3)]));
            emit(tex, px, py, pz, vx, vy, vz, life, k == 0 ? 1.0 : 0.55, 0.1, tone(), tone(), 0.9, true, 0, 1, rr(0.08), false);
        }
    }

    // ================= 아즈텍 태양석 연출 (마비카) =================

    /** 등 뒤에 세워진 후광(마비카 E). 시전자를 따라다니며 천천히 돈다. yaw = 시전자가 바라보는 방향(라디안, 마인크래프트 yaw) */
    private static void sunHalo(double x, double y, double z, double r, int life, double yaw) {
        double face = yaw;   // (cos yaw, sin yaw) = 바라보는 방향(-sin yaw, cos yaw)에 수직인 가로축
        if (el == 3) {
            emitUpright("moon_circle", x, y, z, life, r * 0.96, r, 0.8, 0.012, face);
            emitUpright("star_glyph", x, y, z, life, r * 0.55, r * 0.58, 0.45, -0.03, face);
        } else {
            emitUpright("sun_stone", x, y, z, life, r * 0.96, r, 0.85, 0.012, face);
            emitUpright("sun_glyph", x, y, z, life, r * 0.58, r * 0.62, 0.5, -0.035, face);
        }
        emitUpright("glow", x, y, z, life, r * 1.05, r * 1.2, 0.22, 0, face);
        int n = cnt(2);
        for (int i = 0; i < n; i++) {
            double a = ru() * 6.2832, d = r * (0.6 + 0.4 * ru());
            double ox = Math.cos(face) * Math.cos(a) * d, oz = Math.sin(face) * Math.cos(a) * d, oy = Math.sin(a) * d;
            emit("ember", x + ox, y + oy, z + oz, rr(0.01), 0.03 + ru() * 0.03, rr(0.01), 20, 0.18, 0.04, WHITE, CORE[el], 0.9, true, 0, 0.98, 0, false);
        }
    }

    /** 하늘에 뜬 태양석 마법진. 반복 호출하면 끊김 없이 이어진다. */
    private static void sunStone(double x, double y, double z, double r, int life) {
        if (el == 3) {   // 얼음: 달과 별자리 마법진 + 은은한 극광빛
            emit("moon_circle", x, y, z, 0, 0, 0, life, r * 0.96, r, WHITE, WHITE, 0.72, true, 0, 1, 0.008, true);
            emit("star_glyph", x, y - 0.03, z, 0, 0, 0, life, r * 0.56, r * 0.6, WHITE, WHITE, 0.4, true, 0, 1, -0.02, true);
            emit("glow", x, y - 0.06, z, 0, 0, 0, life, r * 0.95, r * 1.05, 0x30FFB8, 0xD845FF, 0.24, true, 0, 1, 0, true);
            int ns = cnt(3);
            for (int i = 0; i < ns; i++) {
                double a = ru() * 6.2832, d = r * (0.3 + 0.75 * ru());
                emit("star4", x + Math.cos(a) * d, y - 0.3, z + Math.sin(a) * d, rr(0.01), -0.03 - ru() * 0.03, rr(0.01), 34,
                        0.12 + ru() * 0.16, 0.02, WHITE, WHITE, 0.95, true, 0, 0.99, 0.04, false);
            }
            for (int i = 0; i < cnt(3); i++) {
                double a = ru() * 6.2832, d = r * (0.2 + 0.8 * ru());
                emit(t("flake"), x + Math.cos(a) * d, y - 0.3, z + Math.sin(a) * d, rr(0.02), -0.06 - ru() * 0.05, rr(0.02), 28,
                        0.2, 0.08, WHITE, WHITE, 0.85, true, 0, 0.99, 0.03, false);
            }
            return;
        }
        emit("sun_stone", x, y, z, 0, 0, 0, life, r * 0.96, r, WHITE, WHITE, 0.7, true, 0, 1, 0.010, true);
        emit("sun_glyph", x, y - 0.03, z, 0, 0, 0, life, r * 0.6, r * 0.64, WHITE, WHITE, 0.4, true, 0, 1, -0.028, true);
        emit("glow", x, y - 0.06, z, 0, 0, 0, life, r * 0.95, r * 1.05, 0xFFD040, 0xFF3A08, 0.26, true, 0, 1, 0, true);
        int n = cnt(4);
        for (int i = 0; i < n; i++) {
            double a = ru() * 6.2832, d = r * (0.25 + 0.75 * ru());
            emit("ember", x + Math.cos(a) * d, y - 0.2, z + Math.sin(a) * d, rr(0.01), -0.05 - ru() * 0.06, rr(0.01), 26,
                    0.22, 0.04, WHITE, CORE[el], 0.9, true, 0, 0.99, 0, false);
        }
    }

    /** 땅에 깔리는 태양 문양 */
    private static void sunGlyph(double x, double y, double z, double r) {
        if (el == 3) {
            emit("star_glyph", x, y + 0.05, z, 0, 0, 0, 26, r * 0.5, r, WHITE, WHITE, 0.9, true, 0, 1, 0.05, true);
            emit("frost_band", x, y + 0.08, z, 0, 0, 0, 26, r * 0.55, r * 1.05, WHITE, WHITE, 0.7, true, 0, 1, -0.04, true);
            flatRing(x, y, z, r * 0.4, r * 1.2, 18, 0.7);
            for (int i = 0; i < cnt(8); i++) {
                double a = ru() * 6.2832, d = r * ru();
                emit(t("flake"), x + Math.cos(a) * d, y + 0.2, z + Math.sin(a) * d, rr(0.02), 0.05 + ru() * 0.05, rr(0.02), 24, 0.2, 0.06, WHITE, WHITE, 0.9, true, 0, 0.98, 0.04, false);
            }
            return;
        }
        emit("sun_glyph", x, y + 0.05, z, 0, 0, 0, 26, r * 0.5, r, WHITE, WHITE, 0.9, true, 0, 1, 0.05, true);
        emit("sun_band", x, y + 0.08, z, 0, 0, 0, 26, r * 0.55, r * 1.05, WHITE, WHITE, 0.7, true, 0, 1, -0.04, true);
        flatRing(x, y, z, r * 0.4, r * 1.2, 18, 0.7);
    }

    /** 태양기둥. 예고(땅 문양)와 착탄(계단 띠가 감긴 불기둥)을 나눠 그린다. */
    private static void sunPillar(double x, double y, double z, double r, boolean strike) {
        if (el == 3) {
            // 얼음: 별빛 화살이 하늘에서 꽂히는 극광 기둥
            if (!strike) {
                emit("star_glyph", x, y + 0.06, z, 0, 0, 0, 12, r * 1.5, r * 1.1, WHITE, WHITE, 0.85, true, 0, 1, 0.06, true);
                flatRing(x, y, z, r * 1.7, r * 0.8, 12, 0.7);
                emit("star4", x, y + 0.5, z, 0, 0.02, 0, 12, r * 0.9, r * 0.4, WHITE, WHITE, 0.9, true, 0, 1, 0.1, false);
                return;
            }
            emit("star_glyph", x, y + 0.06, z, 0, 0, 0, 14, r * 1.2, r * 1.8, WHITE, WHITE, 0.9, true, 0, 1, 0.04, true);
            flatRing(x, y, z, r * 0.6, r * 2.4, 10, 0.9);
            flash(x, y + 0.4, z, 5, r * 1.4, r * 0.7, 0.95);
            final double height = 18.0;
            int band = 0;
            for (double h = 0; h < height; h += 0.7) {
                double w = 0.28 + r * 0.16 * (1.0 - h / height);
                double k = h / height;
                int col = k < 0.35 ? 0x40FFC0 : (k < 0.7 ? 0x4C9CFF : 0xE050FF);   // 극광: 아래 청록, 중간 파랑, 위 분홍보라
                emit(t("glow"), x, y + h, z, 0, 0, 0, 9, w * 2.6, w * 1.6, WHITE, col, 0.9, true, 0, 1, 0, false);
                if (((int) (h / 0.7)) % 4 == 0) {
                    emit("frost_band", x, y + h + 0.1, z, 0, 0, 0, 10, r * 0.95, r * 0.55, WHITE, WHITE, 0.9, true, 0, 1, (band++ % 2 == 0) ? 0.1 : -0.1, true);
                }
            }
            for (int i = 0; i < cnt(10); i++) {
                emit(t("crystal"), x + rr(r * 0.5), y + 0.3, z + rr(r * 0.5), rr(0.18), 0.12 + ru() * 0.16, rr(0.18), 16, 0.3, 0.08, WHITE, WHITE, 0.95, true, 0.05, 0.93, 0.15, false);
            }
            for (int i = 0; i < cnt(8); i++) {
                double a = ru() * 6.2832, up = ru() * 10;
                emit("star4", x + Math.cos(a) * 0.9, y + up, z + Math.sin(a) * 0.9, -Math.sin(a) * 0.05, 0.12, Math.cos(a) * 0.05, 18, 0.3, 0.05, WHITE, WHITE, 0.95, true, 0, 0.97, 0.15, false);
            }
            emit("star4", x, y + height, z, 0, -0.5, 0, 6, 1.2, 0.5, WHITE, WHITE, 0.9, true, 0, 1, 0.1, false);   // 꼭대기에서 떨어지는 별
            return;
        }
        if (!strike) {
            emit("sun_glyph", x, y + 0.06, z, 0, 0, 0, 12, r * 1.5, r * 1.1, WHITE, WHITE, 0.85, true, 0, 1, 0.06, true);
            flatRing(x, y, z, r * 1.7, r * 0.8, 12, 0.7);
            glowE(x, y + 0.3, z, 0, 0.02, 0, 12, r * 0.9, r * 0.5, 0.5);
            return;
        }
        emit("sun_glyph", x, y + 0.06, z, 0, 0, 0, 14, r * 1.2, r * 1.8, WHITE, WHITE, 0.9, true, 0, 1, 0.04, true);
        flatRing(x, y, z, r * 0.6, r * 2.4, 10, 0.9);
        flash(x, y + 0.4, z, 5, r * 1.6, r * 0.8, 0.95);
        final double height = 16.0;
        int band = 0;
        for (double h = 0; h < height; h += 0.8) {
            double w = r * (0.55 - 0.18 * h / height) + 0.25;
            emit(t("glow"), x, y + h, z, 0, 0, 0, 9, w * 2.2, w * 1.4, 0xFFF0A0, 0xFF4A08, 0.95, true, 0, 1, 0, false);
            if (((int) (h / 0.8)) % 2 == 0) {
                emit("pyro_flame", x + rr(w * 0.4), y + h, z + rr(w * 0.4), 0, 0.22, 0, 10, w * 1.4, w * 0.6, 0xFFF4B0, 0xFF3010, 0.95, true, 0, 0.95, 0, false);
            }
            if (((int) (h / 0.8)) % 3 == 0) {
                emit("sun_band", x, y + h + 0.1, z, 0, 0, 0, 10, r * 1.15, r * 0.65, WHITE, WHITE, 0.9, true, 0, 1, (band++ % 2 == 0) ? 0.09 : -0.09, true);
            }
        }
        int e = cnt(14);
        for (int i = 0; i < e; i++) {
            emit("ember", x + rr(r * 0.8), y + ru() * 2, z + rr(r * 0.8), rr(0.05), 0.25 + ru() * 0.2, rr(0.05), 18,
                    0.22, 0.05, WHITE, CORE[el], 0.95, true, 0, 0.97, 0, false);
        }
        for (int i = 0; i < cnt(2); i++) {
            emit("smoke", x + rr(r * 0.6), y + 0.3, z + rr(r * 0.6), 0, 0.05, 0, 18, r * 0.7, r * 1.6, 0x444444, 0x1A1A1A, 0.45, false, 0, 0.98, 0.01, false);
        }
    }

    /** 창 찌르기: 얼음 원소는 결정이 전방으로 뻗고 끝에 별이 반짝인다. */
    private static void thrust(double ex, double ey, double ez, double lx, double ly, double lz) {
        double len = Math.sqrt(lx * lx + ly * ly + lz * lz);
        if (len < 1e-4) return;
        double dx = lx / len, dy = ly / len, dz = lz / len;
        double sx = ex + dx * 0.9, sy = ey - 0.35 + dy * 0.9, sz = ez + dz * 0.9;
        int n = Math.max(6, cnt(16));
        for (int i = 0; i < n; i++) {
            double d = 0.4 + i * 0.45;
            double px = sx + dx * d, py = sy + dy * d, pz = sz + dz * d;
            emit(el == 3 ? "cryo_glow" : t("glow"), px, py, pz, dx * 0.2, dy * 0.2, dz * 0.2, 6, 0.55, 0.15, WHITE, EDGE[el], 0.85, true, 0, 0.85, 0, false);
            if (i % 2 == 0) emit(t("crystal"), px, py, pz, dx * 0.12 + rr(0.03), dy * 0.12 + rr(0.03), dz * 0.12 + rr(0.03), 9, 0.3, 0.06, WHITE, WHITE, 0.95, true, 0, 0.9, 0.1, false);
        }
        double tx = sx + dx * (0.4 + n * 0.45), ty = sy + dy * (0.4 + n * 0.45), tz = sz + dz * (0.4 + n * 0.45);
        emit("star4", tx, ty, tz, 0, 0, 0, 8, 1.1, 0.3, WHITE, WHITE, 1.0, true, 0, 1, 0.12, false);
        flash(tx, ty, tz, 4, 0.8, 0.2, 0.8);
    }

    /** 대검격: 불 원소는 사용자가 준 초승달 불꽃 이미지를 눕혀서 전방을 휩쓸고, 그 외 원소는 큰 호를 그린다. */
    private static void wideSlash(double ex, double ey, double ez, double lx, double ly, double lz) {
        double hl = Math.sqrt(lx * lx + lz * lz);
        double hx = hl < 1e-4 ? 0 : lx / hl, hz = hl < 1e-4 ? 1 : lz / hl;
        double sx = -hz, sz = hx;   // 오른쪽 방향
        if (el == 0) {
            double cx = ex + hx * 1.9, cy = ey - 0.55, cz = ez + hz * 1.9;
            float base = (float) Math.atan2(-hz, -hx);   // 초승달의 볼록한 쪽이 앞을 향하도록
            emitRoll("fire_slash", cx, cy, cz, hx * 0.08, 0, hz * 0.08, 7, 2.7, 4.1, WHITE, WHITE, 1.0, true, 0, 0.9, -0.2, true, base + 1.0f);
            emitRoll("fire_slash", cx, cy - 0.05, cz, hx * 0.05, 0, hz * 0.05, 9, 3.4, 5.0, WHITE, 0xFFB040, 0.55, true, 0, 0.9, -0.16, true, base + 0.9f);
            int n = Math.max(4, cnt(12));
            for (int k = 0; k < n; k++) {
                double a = -1.2 + 2.4 * k / (n - 1);
                double px = ex + hx * 2.5 * Math.cos(a) + sx * 2.7 * Math.sin(a);
                double pz = ez + hz * 2.5 * Math.cos(a) + sz * 2.7 * Math.sin(a);
                emit("ember", px, cy, pz, sx * -0.05 * Math.cos(a) + rr(0.02), 0.03 + ru() * 0.03, sz * -0.05 * Math.cos(a) + rr(0.02),
                        14, 0.24, 0.05, WHITE, CORE[el], 0.95, true, 0, 0.94, 0, false);
                if (k % 3 == 0) accent(px, cy, pz, 0, 0.02, 0, 10, 0.5, 0.15, 0.9);
            }
            flash(ex + hx * 3.4, cy, ez + hz * 3.4, 4, 1.1, 0.3, 0.8);
            return;
        }
        int n = Math.max(6, cnt(22));
        for (int k = 0; k < n; k++) {
            double a = -1.5 + 3.0 * k / (n - 1);
            double px = ex + hx * 3.0 * Math.cos(a) + sx * 3.4 * Math.sin(a);
            double pz = ez + hz * 3.0 * Math.cos(a) + sz * 3.4 * Math.sin(a);
            emit("glow", px, ey - 0.5, pz, sx * 0.1 * Math.cos(a), 0.01, sz * 0.1 * Math.cos(a), 7, 0.5, 0.12, WHITE, EDGE[el], 0.9, true, 0, 0.9, 0, false);
            if (k % 3 == 0) accent(px, ey - 0.5, pz, 0, 0.02, 0, 10, 0.4, 0.12, 0.9);
        }
    }

    private static void meteor(double x, double y, double z, double h) {
        double py = y + h;
        flash(x, py, z, 3, 1.4, 1.2, 0.9);
        emit(t("glow"), x, py, z, 0, 0, 0, 4, 2.2, 2.0, WHITE, WHITE, 0.4, true, 0, 1, 0, false);
        int a = cnt(4);
        for (int i = 0; i < a; i++) accent(x + rr(0.5), py + rr(0.5) + 0.5, z + rr(0.5), rr(0.05), 0.08, rr(0.05), 12, 0.5, 0.15, 0.9);
        int sm = cnt(3);
        for (int i = 0; i < sm; i++) {
            emit("smoke", x + rr(0.4), py + 0.8, z + rr(0.4), 0, 0.05, 0, 14, 0.8, 1.6, 0x555555, 0x222222, 0.5, false, 0, 0.98, 0.01, false);
        }
    }
}
