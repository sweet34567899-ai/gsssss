package com.example.elementalgaze.client;

import com.example.elementalgaze.ElementalGaze;
import com.example.elementalgaze.FxPacket;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.client.Minecraft;
import net.minecraft.client.ParticleStatus;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.texture.MissingTextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;

/**
 * 클라이언트 연출 레시피. 서버가 보낸 신호(FxPacket)를 원소별 파티클 묶음으로 바꿔서 그린다.
 * 텍스처: assets/elementalgaze/textures/particle/<원소>_glow|ring|spark|sigil 및 원소별 모양, 공용 글로우/연기 등.
 * 파티클 설정(전체/감소/최소)에 따라 개수가 자동으로 줄어든다.
 */
public final class FxClient {
    private FxClient() {}

    private static final String[] ELN = {"pyro", "hydro", "electro", "cryo", "anemo", "geo", "dendro"};
    private static final int[] CORE = {0xFFE9A0, 0xC8EEFF, 0xF0DCFF, 0xEAFFFF, 0xE6FFF4, 0xFFF3C0, 0xE9FFC8};
    private static final int[] EDGE = {0xFF5A1E, 0x2F7CFF, 0xA55CFF, 0x74C8FF, 0x5BE0B0, 0xE8A82C, 0x62BC3C};
    /** 원소별 대표 모양. "~"로 시작하면 흰색 공용 텍스처를 원소 색으로 물들여 쓴다. */
    private static final String[][] ACC = {
            {"pyro_flame", "~flame_a", "~flame_b"},
            {"hydro_drop", "hydro_bubble"},
            {"electro_bolt", "electro_static"},
            {"cryo_crystal", "cryo_flake"},
            {"anemo_swirl", "anemo_puff", "~leaf_wind"},
            {"geo_shard", "geo_gem", "~rock"},
            {"dendro_leaf", "dendro_spore", "~petal"}};
    /** 원소별 움직임: {중력(음수=떠오름), 감속, 회전} */
    private static final double[][] PHYS = {
            {-0.15, 0.96, 0.03}, {0.35, 0.97, 0.05}, {0.0, 0.80, 0.0}, {0.05, 0.95, 0.08},
            {-0.02, 0.94, 0.12}, {0.50, 0.97, 0.15}, {0.06, 0.95, 0.10}};
    private static final boolean[] ADD_ACC = {true, false, true, false, false, false, false};
    private static final int WHITE = 0xFFFFFF;
    private static final Map<String, ResourceLocation> RL = new HashMap<>();
    private static final Set<String> WARNED = new HashSet<>();

    // 한 번의 handle 동안만 쓰는 상태 (클라이언트 스레드 전용)
    private static Minecraft mc;
    private static ClientLevel lvl;
    private static RandomSource rnd;
    private static TextureAtlas atlas;
    private static float dens;
    private static int el;

    public static void handle(FxPacket m) {
        mc = Minecraft.getInstance();
        lvl = mc.level;
        if (lvl == null || mc.player == null) return;
        if (m.el < 0 || m.el >= ELN.length) return;
        if (mc.player.distanceToSqr(m.x, m.y, m.z) > 80.0 * 80.0) return;
        el = m.el;
        rnd = lvl.random;
        atlas = (TextureAtlas) mc.getTextureManager().getTexture(TextureAtlas.LOCATION_PARTICLES);
        ParticleStatus st = mc.options.particles().get();
        dens = st == ParticleStatus.ALL ? 1f : (st == ParticleStatus.DECREASED ? 0.5f : 0.2f);
        switch (m.kind) {
            case FxPacket.BURST -> burst(m.x, m.y, m.z, m.a);
            case FxPacket.RING -> ring(m.x, m.y, m.z, m.a);
            case FxPacket.SPIRAL -> spiral(m.x, m.y, m.z, m.a, m.b, m.vx, m.vy);
            case FxPacket.COLUMN -> column(m.x, m.y, m.z, m.a);
            case FxPacket.LINE -> {
                if (el == 2) bolt(m.x, m.y, m.z, m.vx, m.vy, m.vz, 0.35, 0.3);
                else beam(m.x, m.y, m.z, m.vx, m.vy, m.vz);
            }
            case FxPacket.STRIKE -> strike(m.x, m.y, m.z, m.a);
            case FxPacket.HIT -> hit(m.x, m.y, m.z);
            case FxPacket.STREAM -> stream(m.x, m.y, m.z);
            case FxPacket.ORBIT -> orbit(m.x, m.y, m.z);
            case FxPacket.SUMMON -> summon(m);
            case FxPacket.WALL -> wall(m.x, m.y, m.z, m.vx, m.vz);
            case FxPacket.SLASH -> {
                if (m.b > 0.5f) wideSlash(m.x, m.y, m.z, m.vx, m.vy, m.vz);
                else slash(m.x, m.y, m.z, m.vx, m.vy, m.vz);
            }
            case FxPacket.METEOR -> meteor(m.x, m.y, m.z, m.a);
            case FxPacket.SIGIL -> {
                if (m.b > 0.5f) sunGlyph(m.x, m.y, m.z, m.a);
                else sigil(m.x, m.y, m.z, m.a, 18, 0.85);
            }
            case FxPacket.SUNSTONE -> sunStone(m.x, m.y, m.z, m.a, Math.round(m.b));
            case FxPacket.SUNPILLAR -> sunPillar(m.x, m.y, m.z, m.a, m.b > 0.5f);
            default -> { }
        }
    }

    // ================= 도구 =================
    private static double rr(double a) { return (rnd.nextDouble() - 0.5) * 2.0 * a; }

    private static double ru() { return rnd.nextDouble(); }

    private static int cnt(double c) { return Math.max(1, Math.round((float) (c * dens))); }

    private static String t(String kind) { return ELN[el] + "_" + kind; }

    private static ResourceLocation rl(String name) {
        return RL.computeIfAbsent(name, k -> new ResourceLocation(ElementalGaze.MODID, k));   // 파티클 아틀라스는 접두어 없이 등록된다
    }

    private static void emit(String tex, double x, double y, double z, double vx, double vy, double vz, int life,
                             double s0, double s1, int c0, int c1, double a, boolean add,
                             double g, double drag, double spin, boolean flat) {
        emitRoll(tex, x, y, z, vx, vy, vz, life, s0, s1, c0, c1, a, add, g, drag, spin, flat, rnd.nextFloat() * 6.2832f);
    }

    /** emit 과 같지만 시작 회전각(roll)을 직접 정한다. 바닥에 눕는 검기/문양의 방향을 맞출 때 쓴다. */
    private static void emitRoll(String tex, double x, double y, double z, double vx, double vy, double vz, int life,
                                 double s0, double s1, int c0, int c1, double a, boolean add,
                                 double g, double drag, double spin, boolean flat, float roll) {
        TextureAtlasSprite sp = atlas.getSprite(rl(tex));
        if (sp == atlas.getSprite(MissingTextureAtlasSprite.getLocation())) {
            if (WARNED.add(tex)) ElementalGaze.LOGGER.warn("Missing particle sprite: {}", rl(tex));
            return;
        }
        mc.particleEngine.add(new FxParticle(lvl, x, y, z, vx, vy, vz, life, (float) s0, (float) s1, c0, c1, (float) a, add,
                (float) g, (float) drag, (float) spin, roll, flat, sp));
    }

    /** 원소 색이 입혀진 글로우 */
    private static void glowE(double x, double y, double z, double vx, double vy, double vz, int life, double s0, double s1, double a) {
        emit(t("glow"), x, y, z, vx, vy, vz, life, s0, s1, WHITE, WHITE, a, true, 0, 1, 0, false);
    }

    private static void sparkE(double x, double y, double z, double vx, double vy, double vz, int life, double s0, double s1, double a) {
        emit(t("spark"), x, y, z, vx, vy, vz, life, s0, s1, WHITE, WHITE, a, true, 0.1, 0.88, 0, false);
    }

    /** 백열 섬광: 흰색에서 원소 색으로 */
    private static void flash(double x, double y, double z, int life, double s0, double s1, double a) {
        emit("glow", x, y, z, 0, 0, 0, life, s0, s1, WHITE, CORE[el], a, true, 0, 1, 0, false);
    }

    private static void flatRing(double x, double y, double z, double r0, double r1, int life, double a) {
        emit(t("ring"), x, y + 0.06, z, 0, 0, 0, life, r0, r1, WHITE, WHITE, a, true, 0, 1, 0, true);
    }

    private static void sigil(double x, double y, double z, double r, int life, double a) {
        emit(t("sigil"), x, y + 0.05, z, 0, 0, 0, life, r * 0.55, r, WHITE, WHITE, a, true, 0, 1, 0.03, true);
    }

    /** 원소별 대표 모양 한 개 (원소마다 물리와 합성 방식이 다르다) */
    private static void accent(double x, double y, double z, double vx, double vy, double vz, int life, double s0, double s1, double a) {
        String[] list = ACC[el];
        String tex = list[rnd.nextInt(list.length)];
        boolean tinted = tex.startsWith("~");
        if (tinted) tex = tex.substring(1);
        double[] ph = PHYS[el];
        emit(tex, x, y, z, vx, vy, vz, life, s0, s1, tinted ? CORE[el] : WHITE, tinted ? EDGE[el] : WHITE, a,
                ADD_ACC[el], ph[0], ph[1], rr(ph[2]), false);
    }

    // ================= 폭발 =================
    private static void burst(double x, double y, double z, double r) {
        r = Math.max(1.0, r);
        flash(x, y + 0.8, z, 7, 0.6, r * 1.3, 0.9);
        glowE(x, y + 0.5, z, 0, 0.02, 0, 12, 0.4, r * 0.9, 0.7);
        flatRing(x, y, z, 0.3, r * 1.1, 10, 0.95);
        flatRing(x, y, z, 0.2, r * 0.8, 14, 0.6);
        if (r >= 2.5) sigil(x, y, z, r * 0.9, 20, 0.8);
        switch (el) {
            case 0 -> burstPyro(x, y, z, r);
            case 1 -> burstHydro(x, y, z, r);
            case 2 -> burstElectro(x, y, z, r);
            case 3 -> burstCryo(x, y, z, r);
            case 4 -> burstAnemo(x, y, z, r);
            case 5 -> burstGeo(x, y, z, r);
            default -> burstDendro(x, y, z, r);
        }
    }

    private static void burstPyro(double x, double y, double z, double r) {
        int fl = cnt(8 + r * 6);
        for (int i = 0; i < fl; i++) {
            double a = ru() * Math.PI * 2, d = Math.sqrt(ru()) * r * 0.8;
            accent(x + Math.cos(a) * d, y + 0.1, z + Math.sin(a) * d, rr(0.02), 0.08 + ru() * 0.12, rr(0.02),
                    16 + rnd.nextInt(10), 0.5 + ru() * 0.4, 0.1, 0.95);
        }
        int em = cnt(6 + r * 4);
        for (int i = 0; i < em; i++) {
            emit("pyro_ember", x, y + 0.4, z, rr(0.25), 0.15 + ru() * 0.25, rr(0.25), 24 + rnd.nextInt(14),
                    0.16, 0.05, WHITE, WHITE, 1.0, true, 0.5, 0.97, 0, false);
        }
        int sm = cnt(r * 1.5);
        for (int i = 0; i < sm; i++) {
            emit("smoke", x + rr(r * 0.4), y + 0.5, z + rr(r * 0.4), 0, 0.04, 0, 30, 0.6, 1.6, 0x444444, 0x111111, 0.45,
                    false, -0.02, 0.98, 0.01, false);
        }
    }

    private static void burstHydro(double x, double y, double z, double r) {
        int dr = cnt(10 + r * 6);
        for (int i = 0; i < dr; i++) {
            accent(x + rr(r * 0.5), y + 0.3, z + rr(r * 0.5), rr(0.15), 0.25 + ru() * 0.3, rr(0.15), 22, 0.28, 0.1, 0.95);
        }
        int bub = cnt(6 + r * 2);
        for (int i = 0; i < bub; i++) {
            emit("hydro_bubble", x + rr(r * 0.5), y + 0.3, z + rr(r * 0.5), rr(0.03), 0.04 + ru() * 0.04, rr(0.03), 28,
                    0.25, 0.35, WHITE, WHITE, 0.8, false, -0.03, 0.97, 0.02, false);
        }
        int ms = cnt(r * 2);
        for (int i = 0; i < ms; i++) {
            emit("smoke", x + rr(r * 0.5), y + 0.4, z + rr(r * 0.5), 0, 0.03, 0, 24, 0.6, 1.4, 0xDFF4FF, 0xA9D8FF, 0.3,
                    false, -0.01, 0.98, 0, false);
        }
    }

    private static void burstElectro(double x, double y, double z, double r) {
        int b = cnt(8 + r * 3);
        for (int i = 0; i < b; i++) {
            double a = ru() * Math.PI * 2, sp = 0.3 + ru() * 0.15;
            accent(x, y + 0.8 + rr(0.4), z, Math.cos(a) * sp, rr(0.08), Math.sin(a) * sp, 6 + rnd.nextInt(3), 0.9, 0.5, 1.0);
        }
        int s = cnt(12 + r * 5);
        for (int i = 0; i < s; i++) {
            sparkE(x, y + 0.8, z, rr(0.35), rr(0.3) + 0.05, rr(0.35), 8 + rnd.nextInt(7), 0.3, 0.05, 1.0);
        }
        int arcs = cnt(2 + r * 0.5);
        for (int i = 0; i < arcs; i++) {
            double a = ru() * Math.PI * 2, d = r * (0.5 + ru() * 0.5);
            bolt(x, y + 1.0, z, x + Math.cos(a) * d, y + 0.3, z + Math.sin(a) * d, 0.5, 0.2);
        }
    }

    private static void burstCryo(double x, double y, double z, double r) {
        int s = cnt(10 + r * 5);
        for (int i = 0; i < s; i++) {
            accent(x + rr(r * 0.5), y + 0.8 + ru(), z + rr(r * 0.5), rr(0.06), 0.02 + ru() * 0.05, rr(0.06),
                    26 + rnd.nextInt(14), 0.35, 0.15, 0.9);
        }
        int sh = cnt(6 + r * 3);
        for (int i = 0; i < sh; i++) {
            accent(x, y + 0.5, z, rr(0.3), 0.1 + ru() * 0.25, rr(0.3), 20, 0.4, 0.2, 0.95);
        }
        int ms = cnt(r * 2);
        for (int i = 0; i < ms; i++) {
            emit("smoke", x + rr(r * 0.5), y + 0.4, z + rr(r * 0.5), 0, 0.02, 0, 30, 0.7, 1.5, 0xDDF6FF, 0xA8E4FF, 0.35,
                    false, -0.01, 0.98, 0, false);
        }
    }

    private static void burstAnemo(double x, double y, double z, double r) {
        int sw = cnt(8 + r * 3);
        for (int i = 0; i < sw; i++) {
            double a = ru() * Math.PI * 2, d = ru() * r * 0.6, cs = Math.cos(a), sn = Math.sin(a);
            emit("anemo_swirl", x + cs * d, y + 0.3 + ru() * 0.8, z + sn * d, -sn * 0.18 + cs * 0.05, 0.05, cs * 0.18 + sn * 0.05,
                    16, 0.6, 0.9, WHITE, WHITE, 0.8, true, 0, 0.95, 0.15, false);
        }
        int lf = cnt(6 + r * 2);
        for (int i = 0; i < lf; i++) {
            accent(x + rr(r * 0.4), y + 0.3, z + rr(r * 0.4), rr(0.12), 0.1 + ru() * 0.1, rr(0.12), 28, 0.3, 0.25, 0.9);
        }
        int ms = cnt(r * 2);
        for (int i = 0; i < ms; i++) {
            emit("smoke", x + rr(r * 0.5), y + 0.4, z + rr(r * 0.5), rr(0.05), 0.03, rr(0.05), 22, 0.6, 1.4, 0xFFFFFF, 0xDFFFF4,
                    0.3, false, -0.01, 0.97, 0, false);
        }
    }

    private static void burstGeo(double x, double y, double z, double r) {
        int rk = cnt(8 + r * 5);
        for (int i = 0; i < rk; i++) {
            accent(x + rr(r * 0.3), y + 0.2, z + rr(r * 0.3), rr(0.2), 0.3 + ru() * 0.3, rr(0.2), 26, 0.3, 0.2, 1.0);
        }
        int gm = cnt(4 + r * 2);
        for (int i = 0; i < gm; i++) {
            emit("geo_gem", x + rr(r * 0.3), y + 0.5, z + rr(r * 0.3), rr(0.15), 0.2 + ru() * 0.2, rr(0.15), 22,
                    0.25, 0.2, WHITE, WHITE, 1.0, true, 0.4, 0.97, rr(0.2), false);
        }
        int ds = cnt(r * 3);
        for (int i = 0; i < ds; i++) {
            emit("smoke", x + rr(r * 0.5), y + 0.3, z + rr(r * 0.5), rr(0.04), 0.03, rr(0.04), 26, 0.7, 1.7, 0xB8975A, 0x6B5530,
                    0.5, false, -0.01, 0.98, 0.01, false);
        }
    }

    private static void burstDendro(double x, double y, double z, double r) {
        int lf = cnt(10 + r * 5);
        for (int i = 0; i < lf; i++) {
            accent(x + rr(r * 0.5), y + 1 + ru() * 1.5, z + rr(r * 0.5), rr(0.05), -0.01, rr(0.05), 34, 0.35, 0.25, 1.0);
        }
        int gl = cnt(10);
        for (int i = 0; i < gl; i++) {
            sparkE(x + rr(r * 0.5), y + 0.5 + ru() * 1.2, z + rr(r * 0.5), 0, 0.03, 0, 14, 0.25, 0.05, 0.9);
        }
    }

    // ================= 도형 =================
    private static void ring(double x, double y, double z, double r) {
        flatRing(x, y, z, r * 0.92, r, 8, 0.55);
        if (r >= 2.0) sigil(x, y, z, r, 12, 0.3);   // 필드가 반복 호출하면 회전하는 마법진이 이어져 보인다
    }

    private static void spiral(double x, double y, double z, double radius, double height, double turns, double phase) {
        int n = cnt(18);
        for (int i = 0; i < n; i++) {
            double tt = (double) i / n;
            double a = phase + tt * turns * Math.PI * 2;
            double rad = radius * (0.35 + 0.65 * tt);
            double cs = Math.cos(a), sn = Math.sin(a);
            double px = x + cs * rad, py = y + tt * height, pz = z + sn * rad;
            glowE(px, py, pz, -sn * 0.1, 0.03, cs * 0.1, 14, 0.28, 0.1, 0.85);
            if (i % 3 == 0) accent(px, py, pz, -sn * 0.08, 0.04, cs * 0.08, 16, 0.45, 0.2, 0.9);
        }
    }

    private static void column(double x, double y, double z, double h) {
        for (double yy = 0; yy <= h; yy += 0.5 / Math.max(0.3, dens)) {
            glowE(x + rr(0.12), y + yy, z + rr(0.12), 0, 0.05, 0, 14, 0.5, 0.2, 0.55);
        }
        int a = cnt(h);
        for (int i = 0; i < a; i++) {
            accent(x + rr(0.25), y + ru() * h * 0.3, z + rr(0.25), 0, 0.12 + ru() * 0.1, 0, 18, 0.4, 0.15, 0.9);
        }
        flash(x, y + 0.3, z, 10, 0.8, 1.6, 0.7);
        sigil(x, y, z, 1.4, 12, 0.5);
    }

    private static void beam(double ax, double ay, double az, double bx, double by, double bz) {
        double dx = bx - ax, dy = by - ay, dz = bz - az;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 0.1) return;
        double ux = dx / len, uy = dy / len, uz = dz / len;
        double stepLen = 0.6 / Math.max(0.3, dens);
        int steps = (int) (len / stepLen);
        for (int i = 0; i <= steps; i++) {
            double tt = steps == 0 ? 0 : (double) i / steps;
            double px = ax + dx * tt, py = ay + dy * tt, pz = az + dz * tt;
            glowE(px, py, pz, ux * 0.04, uy * 0.04, uz * 0.04, 9, 0.3, 0.12, 0.9);
            if (i % 3 == 0) accent(px, py, pz, ux * 0.05, uy * 0.05, uz * 0.05, 10, 0.4, 0.15, 0.9);
        }
        flash(bx, by, bz, 4, 0.4, 0.8, 0.8);
    }

    /** 지그재그 번개. 밝은 흰 심지 + 보랏빛 번짐 */
    private static void bolt(double ax, double ay, double az, double bx, double by, double bz, double jitter, double size) {
        double dx = bx - ax, dy = by - ay, dz = bz - az;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 0.1) return;
        int segs = Math.max(2, (int) (len / 1.1));
        double px = ax, py = ay, pz = az;
        for (int i = 1; i <= segs; i++) {
            double tt = (double) i / segs;
            boolean last = i == segs;
            double nx = ax + dx * tt + (last ? 0 : rr(jitter));
            double ny = ay + dy * tt + (last ? 0 : rr(jitter * 0.4));
            double nz = az + dz * tt + (last ? 0 : rr(jitter));
            for (int k = 0; k <= 3; k++) {
                double u = k / 3.0;
                double sx = px + (nx - px) * u, sy = py + (ny - py) * u, sz = pz + (nz - pz) * u;
                emit("glow", sx, sy, sz, 0, 0, 0, 5, size, size * 0.5, WHITE, CORE[2], 0.95, true, 0, 1, 0, false);
                emit(t("glow"), sx, sy, sz, 0, 0, 0, 7, size * 2.4, size, WHITE, WHITE, 0.45, true, 0, 1, 0, false);
            }
            sparkE(nx, ny, nz, rr(0.05), rr(0.05), rr(0.05), 7, size * 1.6, 0.1, 1.0);
            px = nx;
            py = ny;
            pz = nz;
        }
    }

    // ================= 일격 / 타격 =================
    private static void strike(double x, double y, double z, double r) {
        switch (el) {
            case 2 -> {
                bolt(x + rr(0.4), y + 9, z + rr(0.4), x, y, z, 0.9, 0.38);
                int br = cnt(2);
                for (int i = 0; i < br; i++) {
                    double by = y + 2 + ru() * 5;
                    bolt(x, by, z, x + rr(2.5), by - 1.5 - ru() * 2, z + rr(2.5), 0.5, 0.2);
                }
            }
            case 5 -> {
                int n = cnt(12);
                for (int i = 0; i < n; i++) {
                    double px = x + rr(r * 0.6), py = y + 4 + ru() * 5, pz = z + rr(r * 0.6);
                    if (ru() < 0.5) {
                        emit("geo_gem", px, py, pz, 0, -0.5, 0, 10, 0.34, 0.3, WHITE, WHITE, 1.0, false, 0.2, 1.0, rr(0.2), false);
                    } else {
                        emit("rock", px, py, pz, 0, -0.5, 0, 10, 0.34, 0.3, 0xE9C46A, 0x8C6A28, 1.0, false, 0.2, 1.0, rr(0.2), false);
                    }
                }
                column(x, y, z, 5.0);
            }
            case 1 -> {
                int n = cnt(14);
                for (int i = 0; i < n; i++) {
                    emit("streak", x + rr(0.5), y + 4 + ru() * 5, z + rr(0.5), 0, -0.6, 0, 8, 0.5, 0.5, WHITE, EDGE[1], 0.8,
                            true, 0, 1, 0, false);
                }
                column(x, y, z, 4.0);
            }
            default -> column(x, y, z, 5.0);
        }
        burst(x, y, z, r);
    }

    private static void hit(double x, double y, double z) {
        flash(x, y, z, 4, 0.5, 0.9, 0.8);
        int s = cnt(4);
        for (int i = 0; i < s; i++) sparkE(x, y, z, rr(0.2), rr(0.2) + 0.05, rr(0.2), 8, 0.28, 0.04, 1.0);
        int a = cnt(2);
        for (int i = 0; i < a; i++) accent(x, y, z, rr(0.15), rr(0.15) + 0.05, rr(0.15), 12, 0.25, 0.1, 0.95);
    }

    private static void stream(double x, double y, double z) {
        accent(x, y, z, rr(0.04), rr(0.04), rr(0.04), 10, 0.3, 0.1, 0.8);
        glowE(x, y, z, 0, 0, 0, 6, 0.25, 0.1, 0.6);
    }

    private static void orbit(double x, double y, double z) {
        glowE(x, y, z, 0, 0, 0, 6, 0.28, 0.1, 0.9);
        accent(x, y, z, rr(0.02), rr(0.02), rr(0.02), 9, 0.2, 0.08, 0.9);
        emit("ember", x, y, z, rr(0.02), rr(0.02), rr(0.02), 8, 0.12, 0.03, WHITE, CORE[el], 0.9, true, 0, 0.95, 0, false);
    }

    private static void summon(FxPacket m) {
        double x = m.x, y = m.y, z = m.z;
        int kind = Math.round(m.a);
        if (kind > 0) {
            // 모델 소환체: 모델은 SummonRenderer 가 그리고, 여기서는 은은한 빛만 더한다
            int state = Math.round(m.b);
            SummonRenderer.update(kind, Math.round(m.vx), x, y, z, m.vy, state);
            if (kind == com.example.elementalgaze.SummonKinds.MOUNT) {
                // 탑승 드래곤: 발밑에서 불씨와 불꽃이 흩날린다
                for (int i = 0; i < 4; i++) {
                    double ox = rr(0.9), oz = rr(0.9);
                    glowE(x + ox, y + 0.25, z + oz, rr(0.01), 0.03, rr(0.01), 10, 0.7, 0.2, 0.3);
                    emit("ember", x + ox, y + 0.2, z + oz, rr(0.02), 0.05, rr(0.02), 14, 0.14, 0.03, WHITE, CORE[el], 0.9, true, 0, 1, 0.05, false);
                }
                if (state == 1) accent(x, y + 0.5, z, rr(0.03), 0.04, rr(0.03), 10, 0.35, 0.1, 0.9);
                return;
            }
            glowE(x, y - 0.1, z, 0, 0, 0, 6, 0.9, 0.5, 0.2);
            if (state == 1) accent(x, y, z, rr(0.03), rr(0.03), rr(0.03), 9, 0.25, 0.1, 0.9);
            return;
        }
        flash(x, y, z, 6, 0.55, 0.45, 0.8);
        glowE(x, y, z, 0, 0, 0, 6, 0.7, 0.55, 0.5);
        emit("spark", x, y, z, 0, 0, 0, 6, 0.4, 0.2, WHITE, CORE[el], 0.9, true, 0, 1, 0.12, false);
        accent(x + rr(0.2), y + rr(0.2), z + rr(0.2), rr(0.02), rr(0.02), rr(0.02), 8, 0.25, 0.1, 0.9);
        if (el == 2) bolt(x + rr(0.4), y + rr(0.4), z + rr(0.4), x + rr(0.4), y + rr(0.4), z + rr(0.4), 0.1, 0.07);
    }

    private static void wall(double cx, double cy, double cz, double sx, double sz) {
        for (int xi = -2; xi <= 2; xi++) {
            for (int yi = 0; yi < 3; yi++) {
                double px = cx + sx * xi, py = cy + 0.3 + yi * 0.9, pz = cz + sz * xi;
                glowE(px, py, pz, 0, 0, 0, 12, 0.6, 0.6, 0.3);
                if (((xi + yi) & 1) == 0) accent(px, py, pz, 0, 0, 0, 12, 0.4, 0.4, 0.7);
            }
        }
    }

    private static void slash(double ex, double ey, double ez, double lx, double ly, double lz) {
        double sx = -lz, sz = lx;
        double sl = Math.sqrt(sx * sx + sz * sz);
        if (sl < 1e-4) {
            sx = 1;
            sz = 0;
        } else {
            sx /= sl;
            sz /= sl;
        }
        int n = Math.max(3, cnt(14));
        for (int k = 0; k < n; k++) {
            double a = -1.2 + 2.4 * k / (n - 1);
            double px = ex + lx * (1.3 + 0.4 * Math.cos(a)) + sx * 1.3 * Math.sin(a);
            double py = ey - 0.2 + ly * 1.3;
            double pz = ez + lz * (1.3 + 0.4 * Math.cos(a)) + sz * 1.3 * Math.sin(a);
            double vx = sx * Math.cos(a) * 0.12, vz = sz * Math.cos(a) * 0.12;
            emit("glow", px, py, pz, vx, 0.01, vz, 6, 0.38, 0.1, WHITE, EDGE[el], 0.9, true, 0, 0.9, 0, false);
            if (k % 3 == 0) accent(px, py, pz, vx, 0.02, vz, 10, 0.35, 0.12, 0.9);
        }
        emit("spark", ex + lx * 1.7, ey + ly * 1.7 - 0.1, ez + lz * 1.7, 0, 0, 0, 5, 0.9, 0.2, WHITE, CORE[el], 0.9, true, 0, 1, 0, false);
    }

    // ================= 아즈텍 태양석 연출 (마비카) =================

    /** 하늘에 뜬 태양석 마법진. 반복 호출하면 끊김 없이 이어진다. */
    private static void sunStone(double x, double y, double z, double r, int life) {
        emit("sun_stone", x, y, z, 0, 0, 0, life, r * 0.96, r, WHITE, WHITE, 0.7, true, 0, 1, 0.010, true);
        emit("sun_glyph", x, y - 0.03, z, 0, 0, 0, life, r * 0.6, r * 0.64, WHITE, WHITE, 0.4, true, 0, 1, -0.028, true);
        emit("glow", x, y - 0.06, z, 0, 0, 0, life, r * 0.95, r * 1.05, 0xFFB040, 0xFF6A20, 0.2, true, 0, 1, 0, true);
        int n = cnt(4);
        for (int i = 0; i < n; i++) {
            double a = ru() * 6.2832, d = r * (0.25 + 0.75 * ru());
            emit("ember", x + Math.cos(a) * d, y - 0.2, z + Math.sin(a) * d, rr(0.01), -0.05 - ru() * 0.06, rr(0.01), 26,
                    0.22, 0.04, WHITE, CORE[el], 0.9, true, 0, 0.99, 0, false);
        }
    }

    /** 땅에 깔리는 태양 문양 */
    private static void sunGlyph(double x, double y, double z, double r) {
        emit("sun_glyph", x, y + 0.05, z, 0, 0, 0, 26, r * 0.5, r, WHITE, WHITE, 0.9, true, 0, 1, 0.05, true);
        emit("sun_band", x, y + 0.08, z, 0, 0, 0, 26, r * 0.55, r * 1.05, WHITE, WHITE, 0.7, true, 0, 1, -0.04, true);
        flatRing(x, y, z, r * 0.4, r * 1.2, 18, 0.7);
    }

    /** 태양기둥. 예고(땅 문양)와 착탄(계단 띠가 감긴 불기둥)을 나눠 그린다. */
    private static void sunPillar(double x, double y, double z, double r, boolean strike) {
        if (!strike) {
            emit("sun_glyph", x, y + 0.06, z, 0, 0, 0, 12, r * 1.5, r * 1.1, WHITE, WHITE, 0.85, true, 0, 1, 0.06, true);
            flatRing(x, y, z, r * 1.7, r * 0.8, 12, 0.7);
            glowE(x, y + 0.3, z, 0, 0.02, 0, 12, r * 0.9, r * 0.5, 0.5);
            return;
        }
        emit("sun_glyph", x, y + 0.06, z, 0, 0, 0, 14, r * 1.2, r * 1.8, WHITE, WHITE, 0.9, true, 0, 1, 0.04, true);
        flatRing(x, y, z, r * 0.6, r * 2.4, 10, 0.9);
        flash(x, y + 0.4, z, 5, r * 1.6, r * 0.8, 0.95);
        final double height = 16.0;
        int band = 0;
        for (double h = 0; h < height; h += 0.8) {
            double w = r * (0.55 - 0.18 * h / height) + 0.25;
            emit(t("glow"), x, y + h, z, 0, 0, 0, 9, w * 2.2, w * 1.4, WHITE, 0xFFC050, 0.85, true, 0, 1, 0, false);
            if (((int) (h / 0.8)) % 2 == 0) {
                emit("pyro_flame", x + rr(w * 0.4), y + h, z + rr(w * 0.4), 0, 0.22, 0, 10, w * 1.4, w * 0.6, WHITE, 0xFF5A1E, 0.9, true, 0, 0.95, 0, false);
            }
            if (((int) (h / 0.8)) % 3 == 0) {
                emit("sun_band", x, y + h + 0.1, z, 0, 0, 0, 10, r * 1.15, r * 0.65, WHITE, WHITE, 0.9, true, 0, 1, (band++ % 2 == 0) ? 0.09 : -0.09, true);
            }
        }
        int e = cnt(14);
        for (int i = 0; i < e; i++) {
            emit("ember", x + rr(r * 0.8), y + ru() * 2, z + rr(r * 0.8), rr(0.05), 0.25 + ru() * 0.2, rr(0.05), 18,
                    0.22, 0.05, WHITE, CORE[el], 0.95, true, 0, 0.97, 0, false);
        }
        for (int i = 0; i < cnt(2); i++) {
            emit("smoke", x + rr(r * 0.6), y + 0.3, z + rr(r * 0.6), 0, 0.05, 0, 18, r * 0.7, r * 1.6, 0x444444, 0x1A1A1A, 0.45, false, 0, 0.98, 0.01, false);
        }
    }

    /** 대검격: 불 원소는 사용자가 준 초승달 불꽃 이미지를 눕혀서 전방을 휩쓸고, 그 외 원소는 큰 호를 그린다. */
    private static void wideSlash(double ex, double ey, double ez, double lx, double ly, double lz) {
        double hl = Math.sqrt(lx * lx + lz * lz);
        double hx = hl < 1e-4 ? 0 : lx / hl, hz = hl < 1e-4 ? 1 : lz / hl;
        double sx = -hz, sz = hx;   // 오른쪽 방향
        if (el == 0) {
            double cx = ex + hx * 1.9, cy = ey - 0.55, cz = ez + hz * 1.9;
            float base = (float) Math.atan2(-hz, -hx);   // 초승달의 볼록한 쪽이 앞을 향하도록
            emitRoll("fire_slash", cx, cy, cz, hx * 0.08, 0, hz * 0.08, 7, 2.7, 4.1, WHITE, WHITE, 1.0, true, 0, 0.9, -0.2, true, base + 1.0f);
            emitRoll("fire_slash", cx, cy - 0.05, cz, hx * 0.05, 0, hz * 0.05, 9, 3.4, 5.0, WHITE, 0xFFB040, 0.55, true, 0, 0.9, -0.16, true, base + 0.9f);
            int n = Math.max(4, cnt(12));
            for (int k = 0; k < n; k++) {
                double a = -1.2 + 2.4 * k / (n - 1);
                double px = ex + hx * 2.5 * Math.cos(a) + sx * 2.7 * Math.sin(a);
                double pz = ez + hz * 2.5 * Math.cos(a) + sz * 2.7 * Math.sin(a);
                emit("ember", px, cy, pz, sx * -0.05 * Math.cos(a) + rr(0.02), 0.03 + ru() * 0.03, sz * -0.05 * Math.cos(a) + rr(0.02),
                        14, 0.24, 0.05, WHITE, CORE[el], 0.95, true, 0, 0.94, 0, false);
                if (k % 3 == 0) accent(px, cy, pz, 0, 0.02, 0, 10, 0.5, 0.15, 0.9);
            }
            flash(ex + hx * 3.4, cy, ez + hz * 3.4, 4, 1.1, 0.3, 0.8);
            return;
        }
        int n = Math.max(6, cnt(22));
        for (int k = 0; k < n; k++) {
            double a = -1.5 + 3.0 * k / (n - 1);
            double px = ex + hx * 3.0 * Math.cos(a) + sx * 3.4 * Math.sin(a);
            double pz = ez + hz * 3.0 * Math.cos(a) + sz * 3.4 * Math.sin(a);
            emit("glow", px, ey - 0.5, pz, sx * 0.1 * Math.cos(a), 0.01, sz * 0.1 * Math.cos(a), 7, 0.5, 0.12, WHITE, EDGE[el], 0.9, true, 0, 0.9, 0, false);
            if (k % 3 == 0) accent(px, ey - 0.5, pz, 0, 0.02, 0, 10, 0.4, 0.12, 0.9);
        }
    }

    private static void meteor(double x, double y, double z, double h) {
        double py = y + h;
        flash(x, py, z, 3, 1.4, 1.2, 0.9);
        emit(t("glow"), x, py, z, 0, 0, 0, 4, 2.2, 2.0, WHITE, WHITE, 0.4, true, 0, 1, 0, false);
        int a = cnt(4);
        for (int i = 0; i < a; i++) accent(x + rr(0.5), py + rr(0.5) + 0.5, z + rr(0.5), rr(0.05), 0.08, rr(0.05), 12, 0.5, 0.15, 0.9);
        int sm = cnt(3);
        for (int i = 0; i < sm; i++) {
            emit("smoke", x + rr(0.4), py + 0.8, z + rr(0.4), 0, 0.05, 0, 14, 0.8, 1.6, 0x555555, 0x222222, 0.5, false, 0, 0.98, 0.01, false);
        }
    }
}
