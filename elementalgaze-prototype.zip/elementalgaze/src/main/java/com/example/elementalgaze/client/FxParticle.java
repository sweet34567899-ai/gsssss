package com.example.elementalgaze.client;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.BufferBuilder;
import com.mojang.blaze3d.vertex.DefaultVertexFormat;
import com.mojang.blaze3d.vertex.Tesselator;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.Camera;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.particle.ParticleRenderType;
import net.minecraft.client.particle.TextureSheetParticle;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.renderer.texture.TextureManager;
import net.minecraft.util.Mth;
import net.minecraft.world.phys.Vec3;

/**
 * 범용 연출 파티클: 수명 동안 크기/색/투명도가 변하고, 가산 합성(빛 번짐)과 바닥에 눕는 평면 렌더링(마법진, 충격파 링)을 지원한다.
 * 충돌 계산을 하지 않아 가볍다.
 */
public class FxParticle extends TextureSheetParticle {
    /** 빛이 겹칠수록 밝아지는 가산 합성 */
    public static final ParticleRenderType ADDITIVE = new ParticleRenderType() {
        @Override
        public void begin(BufferBuilder buf, TextureManager tm) {
            RenderSystem.depthMask(false);
            RenderSystem.setShader(GameRenderer::getParticleShader);
            RenderSystem.setShaderTexture(0, TextureAtlas.LOCATION_PARTICLES);
            RenderSystem.enableBlend();
            RenderSystem.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
            buf.begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.PARTICLE);
        }

        @Override
        public void end(Tesselator tess) {
            tess.end();
            RenderSystem.depthMask(true);
            RenderSystem.defaultBlendFunc();
        }

        @Override
        public String toString() {
            return "ELEMENTALGAZE_ADDITIVE";
        }
    };

    private final float s0, s1, a0, drag, spin;
    private final int r0, g0, b0, r1, g1, b1;
    private final boolean additive, flat;

    public FxParticle(ClientLevel level, double x, double y, double z, double vx, double vy, double vz, int life,
                      float s0, float s1, int c0, int c1, float a0, boolean additive,
                      float gravity, float drag, float spin, float roll, boolean flat, TextureAtlasSprite sprite) {
        super(level, x, y, z);
        this.xd = vx;
        this.yd = vy;
        this.zd = vz;
        this.lifetime = Math.max(1, life);
        this.gravity = gravity;
        this.hasPhysics = false;
        this.s0 = s0;
        this.s1 = s1;
        this.a0 = a0;
        this.drag = drag;
        this.spin = spin;
        this.additive = additive;
        this.flat = flat;
        this.r0 = (c0 >> 16) & 255;
        this.g0 = (c0 >> 8) & 255;
        this.b0 = c0 & 255;
        this.r1 = (c1 >> 16) & 255;
        this.g1 = (c1 >> 8) & 255;
        this.b1 = c1 & 255;
        this.roll = roll;
        this.oRoll = roll;
        this.quadSize = s0;
        this.alpha = 0f;
        this.setColor(r0 / 255f, g0 / 255f, b0 / 255f);
        this.setSprite(sprite);
    }

    @Override
    public ParticleRenderType getRenderType() {
        return additive ? ADDITIVE : ParticleRenderType.PARTICLE_SHEET_TRANSLUCENT;
    }

    @Override
    public float getQuadSize(float partialTicks) {
        return this.quadSize;
    }

    @Override
    protected int getLightColor(float partialTick) {
        return 0xF000F0;   // 항상 밝게
    }

    @Override
    public void tick() {
        this.xo = this.x;
        this.yo = this.y;
        this.zo = this.z;
        if (this.age++ >= this.lifetime) {
            this.remove();
            return;
        }
        this.yd -= 0.04 * this.gravity;
        this.xd *= drag;
        this.yd *= drag;
        this.zd *= drag;
        this.setPos(this.x + this.xd, this.y + this.yd, this.z + this.zd);
        this.oRoll = this.roll;
        this.roll += spin;

        float t = (float) this.age / (float) this.lifetime;
        float ease = 1f - (1f - t) * (1f - t);
        this.quadSize = s0 + (s1 - s0) * ease;
        this.alpha = a0 * Math.min(1f, t * 10f) * (1f - t * t);
        this.setColor((r0 + (r1 - r0) * t) / 255f, (g0 + (g1 - g0) * t) / 255f, (b0 + (b1 - b0) * t) / 255f);
    }

    @Override
    public void render(VertexConsumer buf, Camera camera, float pt) {
        if (!flat) {
            super.render(buf, camera, pt);
            return;
        }
        // 바닥에 눕는 평면 렌더링 (마법진/충격파). 양면을 모두 그린다.
        Vec3 cam = camera.getPosition();
        float px = (float) (Mth.lerp((double) pt, this.xo, this.x) - cam.x());
        float py = (float) (Mth.lerp((double) pt, this.yo, this.y) - cam.y());
        float pz = (float) (Mth.lerp((double) pt, this.zo, this.z) - cam.z());
        float size = this.getQuadSize(pt);
        float rot = Mth.lerp(pt, this.oRoll, this.roll);
        float cs = Mth.cos(rot), sn = Mth.sin(rot);
        float u0 = this.getU0(), u1 = this.getU1(), v0 = this.getV0(), v1 = this.getV1();
        int light = this.getLightColor(pt);
        float[][] c = {{-1, -1}, {-1, 1}, {1, 1}, {1, -1}};
        float[] us = {u1, u1, u0, u0};
        float[] vs = {v1, v0, v0, v1};
        for (int pass = 0; pass < 2; pass++) {
            for (int k = 0; k < 4; k++) {
                int i = pass == 0 ? k : 3 - k;
                float lx = c[i][0] * size, lz = c[i][1] * size;
                buf.vertex(px + lx * cs - lz * sn, py, pz + lx * sn + lz * cs)
                        .uv(us[i], vs[i])
                        .color(this.rCol, this.gCol, this.bCol, this.alpha)
                        .uv2(light)
                        .endVertex();
            }
        }
    }
}
