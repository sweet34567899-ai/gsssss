package com.example.elementalgaze.client;

import com.example.elementalgaze.ElementalGaze;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;
import javax.annotation.Nullable;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.GsonHelper;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Blockbench 모델을 변환한 JSON(assets/elementalgaze/summon_models/*.json)을 읽어서 그리는 모델.
 * 본 계층 + 샘플링된 애니메이션을 지원한다. 쿼드는 이미 모델 공간 좌표(픽셀 단위)로 구워져 있다.
 * 렌더 스레드에서만 사용한다.
 */
final class SummonModel {
    static final class Bone {
        final String name;
        final int parent;
        final float ox, oy, oz, rx, ry, rz;
        final float[][] quads;

        Bone(String name, int parent, float[] o, float[] r, float[][] quads) {
            this.name = name;
            this.parent = parent;
            this.ox = o[0];
            this.oy = o[1];
            this.oz = o[2];
            this.rx = r[0];
            this.ry = r[1];
            this.rz = r[2];
            this.quads = quads;
        }
    }

    static final class Anim {
        final float len;
        final float[][][] rot, pos, scl;   // [본][샘플][시간,x,y,z], 트랙이 없으면 null

        Anim(float len, int bones) {
            this.len = len;
            this.rot = new float[bones][][];
            this.pos = new float[bones][][];
            this.scl = new float[bones][][];
        }
    }

    final Bone[] bones;
    final Map<String, Anim> anims = new HashMap<>();
    final float cx, cy, cz;
    float sizeY;
    final ResourceLocation texture;

    private final Matrix4f[] mats;
    private final Matrix4f local = new Matrix4f();
    private final Vector3f v = new Vector3f();
    private final Vector3f n = new Vector3f();
    private final float[] tmpR = new float[3], tmpP = new float[3], tmpS = new float[3];

    private SummonModel(String name, Bone[] bones, float[] center) {
        this.bones = bones;
        this.cx = center[0];
        this.cy = center[1];
        this.cz = center[2];
        this.texture = new ResourceLocation(ElementalGaze.MODID, "textures/entity/summon/" + name + ".png");
        this.mats = new Matrix4f[bones.length];
        for (int i = 0; i < mats.length; i++) mats[i] = new Matrix4f();
    }

    @Nullable
    static SummonModel load(String name) {
        ResourceLocation rl = new ResourceLocation(ElementalGaze.MODID, "summon_models/" + name + ".json");
        try (Reader r = Minecraft.getInstance().getResourceManager().openAsReader(rl)) {
            JsonObject o = GsonHelper.parse(r);
            JsonArray ba = GsonHelper.getAsJsonArray(o, "bones");
            Bone[] bones = new Bone[ba.size()];
            Map<String, Integer> index = new HashMap<>();
            for (int i = 0; i < bones.length; i++) {
                JsonObject b = ba.get(i).getAsJsonObject();
                JsonArray qa = b.getAsJsonArray("q");
                float[][] quads = new float[qa.size()][];
                for (int k = 0; k < quads.length; k++) quads[k] = floats(qa.get(k).getAsJsonArray());
                String bn = b.get("n").getAsString();
                bones[i] = new Bone(bn, b.get("p").getAsInt(), floats(b.getAsJsonArray("o")), floats(b.getAsJsonArray("r")), quads);
                index.put(bn, i);
            }
            SummonModel m = new SummonModel(name, bones, floats(o.getAsJsonArray("center")));
            m.sizeY = o.has("size") ? floats(o.getAsJsonArray("size"))[1] : 0f;
            JsonObject anims = GsonHelper.getAsJsonObject(o, "anims", new JsonObject());
            for (Map.Entry<String, JsonElement> en : anims.entrySet()) {
                JsonObject ao = en.getValue().getAsJsonObject();
                Anim a = new Anim(ao.get("len").getAsFloat(), bones.length);
                for (Map.Entry<String, JsonElement> te : ao.getAsJsonObject("tracks").entrySet()) {
                    Integer bi = index.get(te.getKey());
                    if (bi == null) continue;
                    JsonObject t = te.getValue().getAsJsonObject();
                    if (t.has("r")) a.rot[bi] = samples(t.getAsJsonArray("r"));
                    if (t.has("p")) a.pos[bi] = samples(t.getAsJsonArray("p"));
                    if (t.has("s")) a.scl[bi] = samples(t.getAsJsonArray("s"));
                }
                m.anims.put(en.getKey(), a);
            }
            return m;
        } catch (Exception e) {
            ElementalGaze.LOGGER.error("Failed to load summon model {}: {}", rl, e.toString());
            return null;
        }
    }

    private static float[] floats(JsonArray a) {
        float[] f = new float[a.size()];
        for (int i = 0; i < f.length; i++) f[i] = a.get(i).getAsFloat();
        return f;
    }

    private static float[][] samples(JsonArray a) {
        float[][] s = new float[a.size()][];
        for (int i = 0; i < s.length; i++) s[i] = floats(a.get(i).getAsJsonArray());
        return s;
    }

    /** 시간 t 의 값을 out[0..2] 에 보간해서 넣는다. */
    private static void sample(float[][] s, float t, float[] out) {
        if (s.length == 1 || t <= s[0][0]) {
            out[0] = s[0][1]; out[1] = s[0][2]; out[2] = s[0][3];
            return;
        }
        int last = s.length - 1;
        if (t >= s[last][0]) {
            out[0] = s[last][1]; out[1] = s[last][2]; out[2] = s[last][3];
            return;
        }
        int lo = 0, hi = last;
        while (hi - lo > 1) {
            int mid = (lo + hi) >>> 1;
            if (s[mid][0] <= t) lo = mid; else hi = mid;
        }
        float span = s[hi][0] - s[lo][0];
        float a = span <= 1e-6f ? 0f : (t - s[lo][0]) / span;
        for (int k = 0; k < 3; k++) out[k] = s[lo][k + 1] + (s[hi][k + 1] - s[lo][k + 1]) * a;
    }

    /** 각 본의 최종 변환 행렬을 계산한다. 회전은 정적 회전에 애니메이션 값을 더하고, 순서는 Blockbench 와 같은 Z*Y*X. */
    private void pose(@Nullable Anim a, float timeSec) {
        float t = (a != null && a.len > 0f) ? timeSec % a.len : 0f;
        for (int i = 0; i < bones.length; i++) {
            Bone b = bones[i];
            float rx = b.rx, ry = b.ry, rz = b.rz;
            float px = 0f, py = 0f, pz = 0f, sx = 1f, sy = 1f, sz = 1f;
            if (a != null) {
                if (a.rot[i] != null) { sample(a.rot[i], t, tmpR); rx += tmpR[0]; ry += tmpR[1]; rz += tmpR[2]; }
                if (a.pos[i] != null) { sample(a.pos[i], t, tmpP); px = tmpP[0]; py = tmpP[1]; pz = tmpP[2]; }
                if (a.scl[i] != null) { sample(a.scl[i], t, tmpS); sx = tmpS[0]; sy = tmpS[1]; sz = tmpS[2]; }
            }
            local.identity()
                    .translate(b.ox + px, b.oy + py, b.oz + pz)
                    .rotateZYX((float) Math.toRadians(rz), (float) Math.toRadians(ry), (float) Math.toRadians(rx))
                    .scale(sx, sy, sz)
                    .translate(-b.ox, -b.oy, -b.oz);
            if (b.parent >= 0) mats[i].set(mats[b.parent]).mul(local);
            else mats[i].set(local);
        }
    }

    /** ps 는 이미 위치/회전/크기가 적용된 상태여야 한다(모델 픽셀 좌표 -> 월드). */
    void render(PoseStack ps, VertexConsumer vc, @Nullable Anim a, float timeSec, float alpha, int light) {
        pose(a, timeSec);
        Matrix4f pm = ps.last().pose();
        Matrix3f nm = ps.last().normal();
        for (int i = 0; i < bones.length; i++) {
            Matrix4f m = mats[i];
            for (float[] q : bones[i].quads) {
                float qa = (q.length > 23 ? q[23] : 1f) * alpha;
                if (qa <= 0.01f) continue;
                n.set(q[20], q[21], q[22]);
                m.transformDirection(n);
                for (int k = 0; k < 4; k++) {
                    v.set(q[k * 5], q[k * 5 + 1], q[k * 5 + 2]);
                    m.transformPosition(v);
                    vc.vertex(pm, v.x, v.y, v.z)
                            .color(1f, 1f, 1f, qa)
                            .uv(q[k * 5 + 3], q[k * 5 + 4])
                            .overlayCoords(OverlayTexture.NO_OVERLAY)
                            .uv2(light)
                            .normal(nm, n.x, n.y, n.z)
                            .endVertex();
                }
            }
        }
    }
}
