package com.example.elementalgaze;

/** 소환체 종류 번호. 서버가 어떤 소환수인지 클라이언트에 알려 줄 때 쓴다 (0 = 모델 없음). */
public final class SummonKinds {
    public static final int NONE = 0, USHER = 1, CHEVALMARIN = 2, CRAB = 3;

    private SummonKinds() {}

    public static int of(String id) {
        return switch (id) {
            case "usher" -> USHER;
            case "chevalmarin" -> CHEVALMARIN;
            case "crab" -> CRAB;
            default -> NONE;
        };
    }
}
