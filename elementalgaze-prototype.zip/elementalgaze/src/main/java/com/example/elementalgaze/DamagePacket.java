package com.example.elementalgaze;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/** 서버 -> 공격한 플레이어: 이번 틱에 스킬/평타로 넣은 피해 합계. (HUD의 누적 피해/DPS/피해 숫자에 쓴다) */
public final class DamagePacket {
    public final float total;
    public final byte hits, el;
    public final boolean crit;

    public DamagePacket(float total, byte hits, byte el, boolean crit) {
        this.total = total;
        this.hits = hits;
        this.el = el;
        this.crit = crit;
    }

    public static void encode(DamagePacket m, FriendlyByteBuf b) {
        b.writeFloat(m.total);
        b.writeByte(m.hits);
        b.writeByte(m.el);
        b.writeBoolean(m.crit);
    }

    public static DamagePacket decode(FriendlyByteBuf b) {
        return new DamagePacket(b.readFloat(), b.readByte(), b.readByte(), b.readBoolean());
    }

    public static void handle(DamagePacket m, Supplier<NetworkEvent.Context> s) {
        NetworkEvent.Context ctx = s.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT,
                () -> () -> com.example.elementalgaze.client.ClientDamage.onPacket(m.total, m.hits, m.el, m.crit)));
        ctx.setPacketHandled(true);
    }
}
