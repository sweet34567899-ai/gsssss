package com.example.elementalgaze.client;

import com.example.elementalgaze.ElementalGaze;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderLevelStageEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * 푸리나 Q 의 별빛 고래. 엔티티 없이 클라이언트에서만, 사진 한 장을 가로로 잘게 나눈 메시에 입혀서 그린다.
 * 꼬리 쪽으로 갈수록 커지는 물결(머리 -> 꼬리로 전파)로 위아래 일렁이게 해서 헤엄치는 모션을 만들고,
 * 범람한 물 위에서 솟아 나선을 그리며 하늘로 올라간다(승천).
 */
@Mod.EventBusSubscriber(modid = ElementalGaze.MODID, value = Dist.CLIENT)
public final class WhaleRenderer {
    private WhaleRenderer() {}

    private static final ResourceLocation TEX = new ResourceLocation(ElementalGaze.MODID, "textures/entity/whale_swim.png");
    private static final float ASPECT = 0.5f;     // 텍스처 높이 / 너비 (512 x 256)
    private static final int COLS = 28;           // 몸을 가로로 나눈 칸 수

    private static final class Whale {
        double cx, cz, y0, r0, th0, dir, len, hgt;
        long born;
        int delay, life;
        float phase;
    }

    private static final List<Whale> LIST = new ArrayList<>();
    private static final java.util.Random RND = new java.util.Random();

    /** (cx, y0, cz) 를 중심으로, 반경 r 의 나선을 그리며 오르는 고래 count 마리를 일정 간격으로 띄운다 */
    public static void spawn(double cx, double y0, double cz, double r, int count) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        double dir = RND.nextBoolean() ? 1 : -1;
        double base = RND.nextDouble() * Math.PI * 2;
        for (int k = 0; k < count; k++) {
            Whale w = new Whale();
            w.cx = cx; w.cz = cz; w.y0 = y0 + 0.3;
            w.r0 = r * (0.55 + RND.nextDouble() * 0.25);
            w.th0 = base + k * Math.PI * 2 / count;
            w.dir = dir;
            w.len = r * (0.80 + RND.nextDouble() * 0.30);
            w.hgt = r * (1.9 + RND.nextDouble() * 0.5);
            w.born = mc.level.getGameTime();
            w.delay = k * 7;
            w.life = 96;
            w.phase = RND.nextFloat() * 6.28f;
            LIST.add(w);
        }
    }

    private static void pos(Whale w, double t, double[] out) {
        double th = w.th0 + w.dir * (0.5 + 2.7 * t);
        double rad = w.r0 * (1.0 - 0.55 * t);
        out[0] = w.cx + Math.cos(th) * rad;
        out[1] = w.y0 + w.hgt * Math.pow(t, 1.15);
        out[2] = w.cz + Math.sin(th) * rad;
    }

    private static double progress(Whale w, long now, float pt) {
        return (now - w.born - w.delay + pt) / w.life;
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || LIST.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) {
            LIST.clear();
            return;
        }
        long now = mc.level.getGameTime();
        double[] p = new double[3];
        Iterator<Whale> it = LIST.iterator();
        while (it.hasNext()) {
            Whale w = it.next();
            double t = progress(w, now, 0f);
            if (t > 1.0) {
                it.remove();
                continue;
            }
            if (t < 0) continue;
            pos(w, t, p);
            FxClient.whaleTrail(p[0], p[1], p[2], w.len, (float) t);
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        LIST.clear();
    }

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent e) {
        if (e.getStage() != RenderLevelStageEvent.Stage.AFTER_PARTICLES || LIST.isEmpty()) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        PoseStack ps = e.getPoseStack();
        Vec3 cam = e.getCamera().getPosition();
        float pt = e.getPartialTick();
        long now = mc.level.getGameTime();
        MultiBufferSource.BufferSource bs = mc.renderBuffers().bufferSource();
        RenderType rt = RenderType.entityTranslucent(TEX);
        VertexConsumer vc = bs.getBuffer(rt);
        Matrix4f pm = ps.last().pose();
        Matrix3f nm = ps.last().normal();
        double[] p0 = new double[3], p1 = new double[3];
        double[][] top = new double[COLS + 1][3], bot = new double[COLS + 1][3];
        boolean any = false;
        for (Whale w : LIST) {
            double t = progress(w, now, pt);
            if (t < 0 || t > 1) continue;
            pos(w, t, p0);
            pos(w, Math.min(1.0, t + 0.02), p1);
            double dx = p1[0] - p0[0], dy = p1[1] - p0[1], dz = p1[2] - p0[2];
            double hl = Math.sqrt(dx * dx + dz * dz);
            if (hl < 1e-6) continue;
            double hx = dx / hl, hz = dz / hl;
            double pitch = Math.max(0.25, Math.min(1.1, Math.atan2(dy, hl)));
            double cp = Math.cos(pitch), sp = Math.sin(pitch);
            double fx = cp * hx, fy = sp, fz = cp * hz;                  // 머리 방향
            double ux = -sp * hx, uy = cp, uz = -sp * hz;                // 위쪽
            // 솟아오를 때는 크게, 사라질 때는 투명하게
            double scale = 0.55 + 0.45 * Math.min(1.0, t * 5.0);
            double half = w.len * 0.5 * scale;
            double halfH = half * ASPECT;
            float alpha = (float) (Math.min(1.0, t / 0.08) * Math.min(1.0, (1.0 - t) / 0.18)) * 0.97f;
            if (alpha <= 0.01f) continue;
            double time = (now + pt) * 0.30 + w.phase;
            double amp = half * 0.30;
            for (int i = 0; i <= COLS; i++) {
                double ui = (double) i / COLS;                           // 0 = 꼬리, 1 = 머리
                double ud = 1.0 - ui;                                    // 머리에서의 거리 (0..1)
                double off = amp * Math.pow(ud, 1.5) * Math.sin(time - 4.4 * ud);
                double along = (ui * 2 - 1) * half;
                double bx = p0[0] + fx * along + ux * off - cam.x;
                double by = p0[1] + fy * along + uy * off - cam.y;
                double bz = p0[2] + fz * along + uz * off - cam.z;
                // 머리는 위로 살짝 들리고 꼬리는 처지는 곡선 (헤엄칠 때 몸이 휘는 느낌)
                double bend = Math.sin(time * 0.5 + 1.0) * 0.04 * half * (1 - ui);
                top[i][0] = bx + ux * (halfH + bend); top[i][1] = by + uy * (halfH + bend); top[i][2] = bz + uz * (halfH + bend);
                bot[i][0] = bx - ux * (halfH - bend); bot[i][1] = by - uy * (halfH - bend); bot[i][2] = bz - uz * (halfH - bend);
            }
            for (int i = 0; i < COLS; i++) {
                float u0 = (float) i / COLS, u1 = (float) (i + 1) / COLS;
                vertex(vc, pm, nm, top[i], u0, 0f, alpha);
                vertex(vc, pm, nm, bot[i], u0, 1f, alpha);
                vertex(vc, pm, nm, bot[i + 1], u1, 1f, alpha);
                vertex(vc, pm, nm, top[i + 1], u1, 0f, alpha);
                // 뒷면도 그린다 (컬링 여부와 관계없이 양쪽에서 보이게)
                vertex(vc, pm, nm, top[i + 1], u1, 0f, alpha);
                vertex(vc, pm, nm, bot[i + 1], u1, 1f, alpha);
                vertex(vc, pm, nm, bot[i], u0, 1f, alpha);
                vertex(vc, pm, nm, top[i], u0, 0f, alpha);
            }
            any = true;
        }
        if (any) bs.endBatch(rt);
    }

    private static void vertex(VertexConsumer vc, Matrix4f pm, Matrix3f nm, double[] p, float u, float v, float a) {
        vc.vertex(pm, (float) p[0], (float) p[1], (float) p[2])
                .color(1f, 1f, 1f, a)
                .uv(u, v)
                .overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(LightTexture.FULL_BRIGHT)
                .normal(nm, 0f, 1f, 0f)
                .endVertex();
    }
}
