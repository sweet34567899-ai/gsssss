package com.example.elementalgaze;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Nullable;
import net.minecraft.util.GsonHelper;

/**
 * type: melee/ranged(일반공격) | aoe, dash, cone, strikes, field, orbit, summon, barrier, boomerang,
 *       delayed_burst, composite(여러 동작 묶음), stance(일반공격 강화 상태), lift(자신 상승)
 * 필드 의미는 SkillExecutor 의 각 동작 주석 참고.
 */
public final class SkillDef {
    public final String type, style;
    public final float mult, range, radius, aoe, pull, cone, energyCost, energyGain;
    public final float launch, selfLift, absorb;
    public final int cooldown, interval, duration, tick, waves, hits, arms, delay, stun;
    public final boolean follow, progressive;
    public final List<SkillDef> parts;
    @Nullable
    public final SkillDef stance;

    public SkillDef(JsonObject o) {
        this.type = GsonHelper.getAsString(o, "type", "aoe");
        this.style = GsonHelper.getAsString(o, "style", "");
        this.mult = GsonHelper.getAsFloat(o, "multiplier", 1f);
        this.range = GsonHelper.getAsFloat(o, "range", 0f);
        this.radius = GsonHelper.getAsFloat(o, "radius", 3f);
        this.aoe = GsonHelper.getAsFloat(o, "aoe", 3f);
        this.pull = GsonHelper.getAsFloat(o, "pull", 0f);
        this.cone = GsonHelper.getAsFloat(o, "cone", 0.5f);
        this.launch = GsonHelper.getAsFloat(o, "launch", 0f);
        this.selfLift = GsonHelper.getAsFloat(o, "selfLift", 0f);
        this.absorb = GsonHelper.getAsFloat(o, "absorb", 0f);
        this.energyCost = GsonHelper.getAsFloat(o, "energy_cost", 60f);
        this.energyGain = GsonHelper.getAsFloat(o, "energy_gain", 0f);
        this.cooldown = GsonHelper.getAsInt(o, "cooldown", 100);
        this.interval = GsonHelper.getAsInt(o, "interval", 10);
        this.duration = GsonHelper.getAsInt(o, "duration", 0);
        this.tick = GsonHelper.getAsInt(o, "tick", 10);
        this.waves = GsonHelper.getAsInt(o, "waves", 1);
        this.hits = GsonHelper.getAsInt(o, "hits", 16);
        this.arms = GsonHelper.getAsInt(o, "arms", 3);
        this.delay = GsonHelper.getAsInt(o, "delay", 20);
        this.stun = GsonHelper.getAsInt(o, "stun", 0);
        this.follow = GsonHelper.getAsBoolean(o, "follow", false);
        this.progressive = GsonHelper.getAsBoolean(o, "progressive", false);
        List<SkillDef> ps = new ArrayList<>();
        if (o.has("parts")) {
            for (JsonElement je : GsonHelper.getAsJsonArray(o, "parts")) {
                ps.add(new SkillDef(GsonHelper.convertToJsonObject(je, "part")));
            }
        }
        this.parts = ps;
        this.stance = o.has("stance") ? new SkillDef(GsonHelper.getAsJsonObject(o, "stance")) : null;
    }
}
