package com.example.elementalgaze.client;

import com.example.elementalgaze.ClientConfig;
import com.example.elementalgaze.Element;
import com.example.elementalgaze.ElementalGaze;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.ClientPlayerNetworkEvent;
import net.minecraftforge.client.event.RenderLivingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/** 원소가 묻은 몹의 머리(이름표) 위에 원소 아이콘을 띄운다. 남은 시간이 얼마 안 남으면 깜빡인다. */
@Mod.EventBusSubscriber(modid = ElementalGaze.MODID, value = Dist.CLIENT)
public final class ElementMarkRenderer {
    private static final ResourceLocation[] TEX = new ResourceLocation[Element.VALUES.length];

    static {
        for (Element e : Element.VALUES) {
            TEX[e.ordinal()] = new ResourceLocation(ElementalGaze.MODID, "textures/gui/rune_" + e.id + ".png");
        }
    }

    private ElementMarkRenderer() {}

    @SubscribeEvent
    public static void onRender(RenderLivingEvent.Post<?, ?> e) {
        if (!ClientConfig.SHOW_MARKS.get()) return;
        LivingEntity ent = e.getEntity();
        if (ent instanceof Player) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        long now = mc.level.getGameTime();
        long[] mark = ClientMarks.get(ent.getId(), now);
        if (mark == null) return;
        int el = (int) mark[0];
        if (el < 0 || el >= TEX.length) return;

        float time = now + e.getPartialTick();
        float alpha = 1f;
        if (mark[1] < 30) alpha = 0.45f + 0.55f * (0.5f + 0.5f * (float) Math.sin(time * 0.7f));   // 곧 사라짐: 깜빡임
        float bob = (float) Math.sin(time * 0.12f) * 0.04f;
        float half = 0.26f;

        PoseStack ps = e.getPoseStack();
        ps.pushPose();
        ps.translate(0.0, ent.getBbHeight() + 0.95 + bob, 0.0);   // 이름표(몸높이+0.5) 바로 위
        ps.mulPose(mc.getEntityRenderDispatcher().cameraOrientation());
        PoseStack.Pose pose = ps.last();
        Matrix4f mat = pose.pose();
        Matrix3f nrm = pose.normal();
        VertexConsumer vc = e.getMultiBufferSource().getBuffer(RenderType.entityTranslucent(TEX[el]));
        int light = 0xF000F0;
        // 파티클과 같은 정점/UV 배치(카메라 방향 회전이 좌우를 뒤집기 때문)
        vertex(vc, mat, nrm, -half, -half, 1f, 1f, alpha, light);
        vertex(vc, mat, nrm, -half, half, 1f, 0f, alpha, light);
        vertex(vc, mat, nrm, half, half, 0f, 0f, alpha, light);
        vertex(vc, mat, nrm, half, -half, 0f, 1f, alpha, light);
        ps.popPose();
    }

    private static void vertex(VertexConsumer vc, Matrix4f mat, Matrix3f nrm, float x, float y, float u, float v, float a, int light) {
        vc.vertex(mat, x, y, 0f).color(1f, 1f, 1f, a).uv(u, v).overlayCoords(OverlayTexture.NO_OVERLAY)
                .uv2(light).normal(nrm, 0f, 0f, 1f).endVertex();
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut e) {
        ClientMarks.clear();
    }
}
