package com.example.elementalgaze;

import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

/**
 * 서버 -> 근처 클라이언트: "이 위치에서 이 연출을 해라". 파티클 하나하나가 아니라 연출 종류와 파라미터만 보낸다(34바이트).
 * 실제 파티클 생성은 클라이언트(FxClient)가 하므로 서버/네트워크 부담이 작다.
 */
public final class FxPacket {
    public static final byte BURST = 0, RING = 1, SPIRAL = 2, COLUMN = 3, LINE = 4, STRIKE = 5, HIT = 6, STREAM = 7,
            ORBIT = 8, SUMMON = 9, WALL = 10, SLASH = 11, METEOR = 12, SIGIL = 13;

    public final byte kind, el;
    public final float x, y, z, vx, vy, vz, a, b;

    public FxPacket(byte kind, byte el, float x, float y, float z, float vx, float vy, float vz, float a, float b) {
        this.kind = kind; this.el = el;
        this.x = x; this.y = y; this.z = z;
        this.vx = vx; this.vy = vy; this.vz = vz;
        this.a = a; this.b = b;
    }

    public static void encode(FxPacket m, FriendlyByteBuf buf) {
        buf.writeByte(m.kind);
        buf.writeByte(m.el);
        buf.writeFloat(m.x); buf.writeFloat(m.y); buf.writeFloat(m.z);
        buf.writeFloat(m.vx); buf.writeFloat(m.vy); buf.writeFloat(m.vz);
        buf.writeFloat(m.a); buf.writeFloat(m.b);
    }

    public static FxPacket decode(FriendlyByteBuf buf) {
        return new FxPacket(buf.readByte(), buf.readByte(), buf.readFloat(), buf.readFloat(), buf.readFloat(),
                buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat(), buf.readFloat());
    }

    public static void handle(FxPacket m, Supplier<NetworkEvent.Context> s) {
        NetworkEvent.Context ctx = s.get();
        ctx.enqueueWork(() -> DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> com.example.elementalgaze.client.FxClient.handle(m)));
        ctx.setPacketHandled(true);
    }
}
