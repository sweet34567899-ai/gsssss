package com.example.elementalgaze;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.server.ServerStoppedEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.network.PacketDistributor;

/**
 * 한 틱 안에 여러 몹을 때려도 패킷은 플레이어당 1개만 보내도록 피해를 모아 두었다가 틱 끝에 전송한다.
 */
@Mod.EventBusSubscriber(modid = ElementalGaze.MODID)
public final class DamageTally {
    private static final class Acc {
        float total;
        int hits;
        boolean crit;
        float top;
        int el;
    }

    private static final Map<UUID, Acc> PENDING = new HashMap<>();

    private DamageTally() {}

    public static void add(ServerPlayer p, float dmg, Element el, boolean crit) {
        if (dmg <= 0f) return;
        Acc a = PENDING.computeIfAbsent(p.getUUID(), k -> new Acc());
        a.total += dmg;
        a.hits++;
        a.crit |= crit;
        if (dmg >= a.top) {
            a.top = dmg;
            a.el = el.ordinal();
        }
    }

    @SubscribeEvent
    public static void onTick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || PENDING.isEmpty()) return;
        Iterator<Map.Entry<UUID, Acc>> it = PENDING.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Acc> en = it.next();
            it.remove();
            ServerPlayer sp = e.getServer().getPlayerList().getPlayer(en.getKey());
            if (sp == null) continue;
            Acc a = en.getValue();
            Net.CH.send(PacketDistributor.PLAYER.with(() -> sp),
                    new DamagePacket(a.total, (byte) Math.min(100, a.hits), (byte) a.el, a.crit));
        }
    }

    @SubscribeEvent
    public static void onStop(ServerStoppedEvent e) {
        PENDING.clear();
    }
}
