package com.example.elementalgaze.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.Minecraft;

/** 클라이언트가 알고 있는 "어떤 몹에 어떤 원소가 묻어 있는지" 목록. 만료 시각만 저장하고 틱마다 갱신하지 않는다. */
public final class ClientMarks {
    private static final Map<Integer, long[]> MAP = new HashMap<>();   // 몹 id -> {원소, 만료 게임시각}

    private ClientMarks() {}

    public static void onPacket(int id, int el, int ticks) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.level == null) return;
        long now = mc.level.getGameTime();
        if (el < 0 || ticks <= 0) {
            MAP.remove(id);
            return;
        }
        MAP.put(id, new long[]{el, now + ticks});
        if (MAP.size() > 256) MAP.values().removeIf(v -> v[1] <= now);
    }

    /** 만료되지 않은 표시만 반환. 없으면 null. {원소, 남은 틱} */
    public static long[] get(int id, long now) {
        long[] v = MAP.get(id);
        if (v == null) return null;
        if (v[1] <= now) {
            MAP.remove(id);
            return null;
        }
        return new long[]{v[0], v[1] - now};
    }

    public static void clear() {
        MAP.clear();
    }
}
